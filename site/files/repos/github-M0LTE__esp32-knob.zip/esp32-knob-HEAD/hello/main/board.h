// Pin map and board bring-up for the Guition JC3636K718 knob display.
// See docs/hardware.md for sources.
#pragma once

#include "driver/gpio.h"
#include "driver/i2c_master.h"
#include "lvgl.h"

#define LCD_H_RES 360
#define LCD_V_RES 360

#define PIN_LCD_SCK   GPIO_NUM_11
#define PIN_LCD_CS    GPIO_NUM_12
#define PIN_LCD_D0    GPIO_NUM_13
#define PIN_LCD_D1    GPIO_NUM_14
#define PIN_LCD_D2    GPIO_NUM_15
#define PIN_LCD_D3    GPIO_NUM_16
#define PIN_LCD_RST   GPIO_NUM_17
#define PIN_LCD_TE    GPIO_NUM_18
#define PIN_LCD_BLK   GPIO_NUM_21

#define PIN_I2C_SDA   GPIO_NUM_9
#define PIN_I2C_SCL   GPIO_NUM_10
#define PIN_TP_INT    GPIO_NUM_7
#define PIN_TP_RST    GPIO_NUM_8

#define PIN_KNOB_A    GPIO_NUM_2
#define PIN_KNOB_B    GPIO_NUM_1

#define PIN_I2S_BCK   GPIO_NUM_3
#define PIN_I2S_WS    GPIO_NUM_45
#define PIN_I2S_DO    GPIO_NUM_42
#define PIN_PA_CTRL   GPIO_NUM_46   // high enables the speaker amp

#define PIN_MIC_CLK   GPIO_NUM_5
#define PIN_MIC_DATA  GPIO_NUM_4

#define PIN_BAT_ADC   GPIO_NUM_6
#define PIN_RGB_DATA  GPIO_NUM_0    // shared with the BOOT strap
#define RGB_LED_COUNT 12

typedef void (*knob_step_cb_t)(int delta);

void board_init(void);
lv_display_t *board_display(void);
i2c_master_bus_handle_t board_i2c(void);
void board_set_knob_cb(knob_step_cb_t cb);
void board_backlight(uint8_t percent);

void leds_set(int i, uint8_t r, uint8_t g, uint8_t b);
void leds_show(void);
float board_battery_volts(void);
