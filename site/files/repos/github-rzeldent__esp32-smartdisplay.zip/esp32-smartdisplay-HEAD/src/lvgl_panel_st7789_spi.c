#ifdef DISPLAY_ST7789_SPI

#include <esp32_smartdisplay.h>
#include <driver/spi_master.h>
#include <esp_lcd_panel_io.h>
#include <esp_lcd_panel_vendor.h>
#include <esp_lcd_panel_ops.h>
#include <lvgl_panel_common.h>

lv_display_t *lvgl_lcd_init(uint32_t hor_res, uint32_t ver_res)
{
    lv_display_t *display = lvgl_create_display();
    log_v("display: %p", display);

    // Create SPI bus
    const spi_bus_config_t spi_bus_config = {
        .mosi_io_num = ST7789_SPI_BUS_MOSI,
        .miso_io_num = ST7789_SPI_BUS_MISO,
        .sclk_io_num = ST7789_SPI_BUS_SCLK,
        .quadwp_io_num = ST7789_SPI_BUS_QUADWP,
        .quadhd_io_num = ST7789_SPI_BUS_QUADHD,
        .max_transfer_sz = ST7789_SPI_BUS_MAX_TRANSFER_SZ,
        .flags = ST7789_SPI_BUS_FLAGS,
        .intr_flags = ST7789_SPI_BUS_INTR_FLAGS};
    log_d("spi_bus_config: mosi_io_num: %d, miso_io_num: %d, sclk_io_num: %d, quadwp_io_num: %d, quadhd_io_num: %d, max_transfer_sz: %d, flags: %p, intr_flags:0x%04x", spi_bus_config.mosi_io_num, spi_bus_config.miso_io_num, spi_bus_config.sclk_io_num, spi_bus_config.quadwp_io_num, spi_bus_config.quadhd_io_num, spi_bus_config.max_transfer_sz, spi_bus_config.flags, spi_bus_config.intr_flags);
    ESP_ERROR_CHECK_WITHOUT_ABORT(spi_bus_initialize(ST7789_SPI_HOST, &spi_bus_config, SPI_DMA_CH_AUTO));

    // Attach the LCD controller to the SPI bus
    const esp_lcd_panel_io_spi_config_t io_spi_config = {
        .cs_gpio_num = ST7789_SPI_CONFIG_CS,
        .dc_gpio_num = ST7789_SPI_CONFIG_DC,
        .spi_mode = ST7789_SPI_CONFIG_SPI_MODE,
        .pclk_hz = ST7789_SPI_CONFIG_PCLK_HZ,
        .on_color_trans_done = lvgl_panel_color_trans_done,
        .user_ctx = display,
        .trans_queue_depth = ST7789_SPI_CONFIG_TRANS_QUEUE_DEPTH,
        .lcd_cmd_bits = ST7789_SPI_CONFIG_LCD_CMD_BITS,
        .lcd_param_bits = ST7789_SPI_CONFIG_LCD_PARAM_BITS,
        .flags = {
            .dc_low_on_data = ST7789_SPI_CONFIG_FLAGS_DC_LOW_ON_DATA,
            .octal_mode = ST7789_SPI_CONFIG_FLAGS_OCTAL_MODE,
            .lsb_first = ST7789_SPI_CONFIG_FLAGS_LSB_FIRST}};
    log_d("io_spi_config: cs_gpio_num: %d, dc_gpio_num: %d, spi_mode: %d, pclk_hz: %d, trans_queue_depth: %d, user_ctx: %p, on_color_trans_done: %p, lcd_cmd_bits: %d, lcd_param_bits: %d, flags:{dc_low_on_data: %d, octal_mode: %d, lsb_first: %d}", io_spi_config.cs_gpio_num, io_spi_config.dc_gpio_num, io_spi_config.spi_mode, io_spi_config.pclk_hz, io_spi_config.trans_queue_depth, io_spi_config.user_ctx, io_spi_config.on_color_trans_done, io_spi_config.lcd_cmd_bits, io_spi_config.lcd_param_bits, io_spi_config.flags.dc_low_on_data, io_spi_config.flags.octal_mode, io_spi_config.flags.lsb_first);
    esp_lcd_panel_io_handle_t io_handle;
    ESP_ERROR_CHECK(esp_lcd_new_panel_io_spi((esp_lcd_spi_bus_handle_t)ST7789_SPI_HOST, &io_spi_config, &io_handle));

    // Create st7789 panel handle
    const esp_lcd_panel_dev_config_t panel_dev_config = {
        .reset_gpio_num = ST7789_DEV_CONFIG_RESET,
        .color_space = ST7789_DEV_CONFIG_COLOR_SPACE,
        .bits_per_pixel = ST7789_DEV_CONFIG_BITS_PER_PIXEL,
        .flags = {
            .reset_active_high = ST7789_DEV_CONFIG_FLAGS_RESET_ACTIVE_HIGH},
        .vendor_config = ST7789_DEV_CONFIG_VENDOR_CONFIG};
    log_d("panel_dev_config: reset_gpio_num: %d, color_space: %d, bits_per_pixel: %d, flags:{reset_active_high: %d}, vendor_config: %p", panel_dev_config.reset_gpio_num, panel_dev_config.color_space, panel_dev_config.bits_per_pixel, panel_dev_config.flags.reset_active_high, panel_dev_config.vendor_config);
    esp_lcd_panel_handle_t panel_handle;
    ESP_ERROR_CHECK(esp_lcd_new_panel_st7789(io_handle, &panel_dev_config, &panel_handle));

    lvgl_setup_panel(panel_handle);
    display->user_data = panel_handle;
    display->flush_cb = lv_flush_hardware;
    return display;
}

#endif