'use strict';

var app = {info:null,sensors:[],selectedKeys:[],live:{},dirty:false,device:null,maxMetrics:20};
// Fallback only. Firmware 1.3 and later report face_name, which covers every
// face; this table cannot name the ones that have no legacy style value.
var styleNames = ['','Big numbers','Tiles + sparklines','Hero + list','Strips','Duo','Pulse','Aero glass tiles','Liquid glass duo'];
var toastTimer = 0;
var aliasTimer = 0;

function $(id){return document.getElementById(id)}
function qa(selector,root){return Array.from((root||document).querySelectorAll(selector))}
function esc(value){return String(value==null?'':value).replace(/[&<>"']/g,function(ch){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]})}
function setText(id,value){var el=$(id);if(el)el.textContent=value==null?'-':String(value)}
function showToast(message,error){var el=$('toast');el.textContent=message;el.classList.toggle('err',!!error);el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(function(){el.classList.remove('show')},3200)}
async function api(url,options){var response=await fetch(url,options);var data=await response.json();if(!response.ok||data.success===false)throw new Error(data.message||('Request failed: '+response.status));return data}
function formBody(form){return new URLSearchParams(new FormData(form))}
/* Pairing with the device for control (see pc_control.py). */
function showPaired(paired){$('pairTag').textContent=paired?'paired':'not paired';$('pairForgetBtn').classList.toggle('hidden',!paired);$('pairStartBtn').lastChild.textContent=paired?'Pair again':'Pair for control';}
function pairCodeBox(open){$('pairCodeBox').classList.toggle('hidden',!open);$('pairIdle').classList.toggle('hidden',open);if(open){$('pairCode').value='';$('pairCode').focus();}}
function pairWaitBox(open){$('pairWaitBox').classList.toggle('hidden',!open);$('pairIdle').classList.toggle('hidden',open);}
/* Tap pairing: the companion collects the key once Allow is tapped; follow it here. */
async function pairWatch(){for(;;){await new Promise(function(r){setTimeout(r,1000)});var s;try{s=await api('/api/pair/status')}catch(error){continue}
  if(s.state==='waiting')continue;pairWaitBox(false);if(s.message)showToast(s.message,s.state!=='paired');if(s.state==='paired')showPaired(true);return;}}
$('pairStartBtn').addEventListener('click',async function(){try{var d=await api('/api/pair/start',{method:'POST'});showToast(d.message);if(d.tap){pairWaitBox(true);pairWatch()}else pairCodeBox(true)}catch(error){showToast(error.message,true)}});
$('pairWaitCancel').addEventListener('click',async function(){try{await api('/api/pair/cancel',{method:'POST'})}catch(error){}});
$('pairConfirmBtn').addEventListener('click',async function(){try{var d=await api('/api/pair/confirm',{method:'POST',body:new URLSearchParams({code:$('pairCode').value})});showToast(d.message);pairCodeBox(false);showPaired(true)}catch(error){showToast(error.message,true)}});
$('pairCancelBtn').addEventListener('click',function(){pairCodeBox(false)});
$('pairForgetBtn').addEventListener('click',async function(){try{var d=await api('/api/pair/forget',{method:'POST'});showToast(d.message);showPaired(false)}catch(error){showToast(error.message,true)}});
function setDirty(on){app.dirty=!!on;var meta=$('saveMeta');meta.classList.toggle('clean',!app.dirty);meta.querySelector('.txt').textContent=app.dirty?'Unsaved sensor changes':'All sensor changes saved'}

function setMode(mode){document.documentElement.dataset.mode=mode;localStorage.setItem('sn_mode',mode);qa('[data-mode]').forEach(function(button){button.classList.toggle('on',button.dataset.mode===mode)})}
function setAccent(accent){document.documentElement.dataset.accent=accent;localStorage.setItem('sn_accent',accent);qa('[data-acc]').forEach(function(button){button.classList.toggle('on',button.dataset.acc===accent)})}
qa('[data-mode]').forEach(function(button){button.addEventListener('click',function(){setMode(button.dataset.mode)})});
qa('[data-acc]').forEach(function(button){button.addEventListener('click',function(){setAccent(button.dataset.acc)})});
setMode(document.documentElement.dataset.mode||'dark');setAccent(document.documentElement.dataset.accent||'green');

function showPage(name){qa('.page').forEach(function(page){page.classList.toggle('active',page.dataset.page===name)});qa('.nav-item').forEach(function(button){button.classList.toggle('active',button.dataset.nav===name)});var active=document.querySelector('.nav-item[data-nav="'+name+'"]');setText('crumb',active?active.textContent.trim():name);document.documentElement.classList.remove('nav-open');$('navToggle').setAttribute('aria-expanded','false');if(name==='device'){refreshDevice(true);refreshPreview()}if(name==='walls'){loadWallDeck();pollWallJob()}}
qa('.nav-item').forEach(function(button){button.addEventListener('click',function(){showPage(button.dataset.nav)})});
$('navToggle').addEventListener('click',function(){var open=document.documentElement.classList.toggle('nav-open');this.setAttribute('aria-expanded',String(open))});
$('navScrim').addEventListener('click',function(){document.documentElement.classList.remove('nav-open');$('navToggle').setAttribute('aria-expanded','false')});

function renderSerialStatus(info){var link=info.serial_link||{};setText('serialStatus',link.connected?'Connected on '+link.port:info.serial_port==='off'?'Off: the USB port is free, for example for the web flasher':'Not connected')}
// Saved on change, not with Save connection: Off has to free the port for flashing.
async function saveSerial(){try{renderSerialStatus(await api('/api/serial',{method:'POST',body:new URLSearchParams({serial_port:$('serial_port').value})}));showToast('USB cable setting saved.')}catch(error){showToast(error.message,true)}}
async function refreshSerialStatus(){try{renderSerialStatus(await api('/api/info'))}catch(error){}}
function setSerialPort(value){var select=$('serial_port');qa('option[data-custom]',select).forEach(function(option){option.remove()});if(value!=='auto'&&value!=='off'){var option=new Option(value,value);option.dataset.custom='1';select.add(option)}select.value=value}

async function loadInfo(){var info=await api('/api/info');app.info=info;setSerialPort(info.serial_port||'auto');renderSerialStatus(info);app.maxMetrics=info.max_metrics||20;setText('topVersion',info.version);setText('aboutVersion',info.version);$('esp32_ip').value=info.ip||'';$('udp_port').value=info.udp_port||4210;$('update_interval').value=info.update_interval||3;$('pc_name').value=info.pc_name||'';showPaired(!!info.paired);setText('cmdPort',info.cmd_port||4211);$('sourceField').classList.toggle('hidden',!info.source_select);$('sensor_source').value=info.sensor_source||'auto';setText('srDevice',info.ip||'-')}

function selectedSensors(){var byKey={};app.sensors.forEach(function(sensor){byKey[sensor.key]=sensor});return app.selectedKeys.map(function(key){return byKey[key]}).filter(Boolean)}
function valueText(sensor){var live=app.live[sensor.metric_id];var value=live&&live.value!=null?live.value:sensor.current_value;return value==null?'-':String(value)+' '+(sensor.unit||'')}
function renderSelected(){var sensors=selectedSensors();setText('sensorCount',sensors.length+' / '+app.maxMetrics);setText('srCount',sensors.length+' metric'+(sensors.length===1?'':'s'));if(!sensors.length){$('selectedTray').innerHTML='<span class="chip-empty">No sensors selected.</span>';return}$('selectedTray').innerHTML=sensors.map(function(sensor){var label=sensor.custom_label||sensor.name;return '<span class="chip selected-chip"><span class="cn">'+esc(label)+'</span><span class="cb">ID '+esc(sensor.metric_id)+' · '+esc(valueText(sensor))+'</span><button type="button" data-remove="'+esc(sensor.key)+'" aria-label="Remove '+esc(label)+'">×</button></span>'}).join('')}
var nicBadges={primary:{text:'active',cls:'is-primary',hint:'Carries the default route'},up:{text:'connected',cls:'is-up',hint:'Has an address but is not the default route'},idle:{text:'no address',cls:'is-idle',hint:'Interface is up without a usable address'},down:{text:'down',cls:'is-down',hint:'Interface is disconnected'},unknown:{text:'not detected',cls:'is-unknown',hint:'Windows does not report this interface any more'}};
function hardwareHtml(sensor){var badge=nicBadges[sensor.nic_state];var parts='';if(sensor.hardware)parts+='<span class="hw-name">'+esc(sensor.hardware)+'</span>';if(badge)parts+='<span class="nic-badge '+badge.cls+'" title="'+esc(badge.hint)+'">'+esc(badge.text)+'</span>';if(sensor.hardware_detail)parts+='<span class="hw-detail">'+esc(sensor.hardware_detail)+'</span>';return parts?'<span class="sensor-hw">'+parts+'</span>':''}
function renderSensors(){var query=$('sensorSearch').value.trim().toLowerCase();var html='';var category='';app.sensors.forEach(function(sensor){var hay=(sensor.display_name+' '+sensor.name+' '+sensor.type+' '+sensor.source+' '+(sensor.hardware||'')+' '+(sensor.hardware_detail||'')+' '+(sensor.nic_state||'')).toLowerCase();if(query&&hay.indexOf(query)<0)return;if(sensor.category!==category){category=sensor.category;html+='<div class="sensor-cat">'+esc(category)+'</div>'}var checked=app.selectedKeys.indexOf(sensor.key)>=0;var title=sensor.sensor_name||sensor.display_name||sensor.name;var full=sensor.display_name||title;html+='<div class="sensor-row'+(checked?' selected':'')+(sensor.nic_state==='primary'?' nic-primary':'')+'"><label class="check-row standalone sensor-toggle"><input type="checkbox" data-sensor-key="'+esc(sensor.key)+'" aria-label="Send '+esc(full)+'"'+(checked?' checked':'')+'><span class="check-box"></span></label><span class="sensor-copy"><span class="sensor-name"><strong title="'+esc(full)+'">'+esc(title)+'</strong><span class="sensor-reading">'+esc(valueText(sensor))+'</span>'+(checked?'<code>ID '+esc(sensor.metric_id)+'</code>':'')+'</span>'+hardwareHtml(sensor)+'<span class="sensor-meta">'+esc(sensor.type||sensor.source||'Sensor')+(sensor.unit?' · '+esc(sensor.unit):'')+'</span>'+(checked?'<span class="sensor-alias"><input type="text" maxlength="15" data-alias-key="'+esc(sensor.key)+'" value="'+esc(sensor.custom_label||'')+'" placeholder="Optional stream alias" aria-label="Stream alias for '+esc(full)+'"></span>':'')+'</span></div>'});$('sensorList').innerHTML=html||'<span class="chip-empty">No sensors match this filter.</span>';renderSelected()}

async function loadSensors(rescan){var data=await api('/api/sensors'+(rescan?'?rescan=1':''));app.sensors=data.sensors||[];app.maxMetrics=data.max||20;app.selectedKeys=app.sensors.filter(function(sensor){return sensor.selected}).sort(function(a,b){return Number(a.metric_id)-Number(b.metric_id)}).map(function(sensor){return sensor.key});setText('srSource',data.source||'-');var banner=data.banner||{};$('sourceBanner').className='note'+(banner.level==='warn'?' warn':'');$('sourceBanner').innerHTML='<span class="note-k">Source</span><span>'+esc(banner.text||'Sensors ready.')+'</span>';renderSensors()}
async function updateSelection(){await api('/api/select',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({keys:app.selectedKeys})});setDirty(true);await loadSensors(false)}
async function syncAliases(){clearTimeout(aliasTimer);var labels={};qa('[data-alias-key]',$('sensorList')).forEach(function(input){labels[input.dataset.aliasKey]=input.value});if(!Object.keys(labels).length)return;await api('/api/labels',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({labels:labels})})}

$('sensorList').addEventListener('input',function(event){var input=event.target.closest('[data-alias-key]');if(!input)return;var sensor=app.sensors.find(function(item){return item.key===input.dataset.aliasKey});if(sensor)sensor.custom_label=input.value;setDirty(true);renderSelected();clearTimeout(aliasTimer);aliasTimer=setTimeout(function(){syncAliases().catch(function(error){showToast(error.message,true)})},350)});
$('sensorList').addEventListener('change',async function(event){var box=event.target.closest('[data-sensor-key]');if(box){var key=box.dataset.sensorKey;if(box.checked){if(app.selectedKeys.length>=app.maxMetrics){box.checked=false;showToast('Select at most '+app.maxMetrics+' sensors.',true);return}if(app.selectedKeys.indexOf(key)<0)app.selectedKeys.push(key)}else{app.selectedKeys=app.selectedKeys.filter(function(item){return item!==key})}try{await updateSelection()}catch(error){showToast(error.message,true);await loadSensors(false)}return}if(event.target.closest('[data-alias-key]')){try{await syncAliases()}catch(error){showToast(error.message,true)}}});
$('selectedTray').addEventListener('click',async function(event){var button=event.target.closest('[data-remove]');if(!button)return;app.selectedKeys=app.selectedKeys.filter(function(key){return key!==button.dataset.remove});try{await updateSelection()}catch(error){showToast(error.message,true)}});
$('sensorSearch').addEventListener('input',renderSensors);
$('rescanBtn').addEventListener('click',async function(){this.disabled=true;try{await loadSensors(true);showToast('Sensor list refreshed.')}catch(error){showToast(error.message,true)}finally{this.disabled=false}});

async function saveConnection(){try{var data=await api('/api/connection',{method:'POST',body:formBody($('connectionForm'))});app.info.ip=data.esp32_ip;setText('srDevice',data.esp32_ip);showToast('Connection settings saved.');await refreshSerialStatus();await refreshDevice(true)}catch(error){showToast(error.message,true)}}
$('saveConnBtn').addEventListener('click',saveConnection);
$('serial_port').addEventListener('change',saveSerial);
$('testConnBtn').addEventListener('click',async function(){this.disabled=true;var result=$('connResult');try{var data=await api('/api/test',{method:'POST',body:formBody($('connectionForm'))});result.classList.remove('hidden');result.classList.toggle('warn',!data.compatible);result.innerHTML='<span class="note-k">Test</span><span>'+esc(data.message)+'</span>';renderDevice(data)}catch(error){result.classList.remove('hidden');result.classList.add('warn');result.innerHTML='<span class="note-k">Test</span><span>'+esc(error.message)+'</span>'}finally{this.disabled=false}});

function formatUptime(seconds){seconds=Number(seconds||0);var days=Math.floor(seconds/86400),hours=Math.floor(seconds%86400/3600),mins=Math.floor(seconds%3600/60);return (days?days+'d ':'')+hours+'h '+mins+'m'}
function renderDevice(data){app.device=data;var online=!!data.reachable,compatible=!!data.compatible;$('srLed').classList.toggle('online',online);$('srLed').classList.toggle('offline',!online);setText('srTitle',online?(compatible?'Device online':'Unexpected device'):'Device offline');setText('deviceStateTag',online?(compatible?'online':'mismatch'):'offline');setText('devProduct',data.product||'-');setText('devVersion',data.version||'-');setText('devBoard',data.board||'-');setText('devAddress',data.address||app.info&&app.info.ip||'-');setText('devStream',data.pc_online?'online':'waiting');setText('devMetrics',data.metric_count==null?'-':data.metric_count);setText('devStyle',data.face_name||(data.style==null?'-':(styleNames[data.style]||('Style '+data.style))));setText('devRssi',data.rssi==null?'-':data.rssi+' dBm');setText('devBacklight',data.backlight==null?'-':data.backlight+(data.night_active?' (night)':''));setText('devUptime',data.uptime_seconds==null?'-':formatUptime(data.uptime_seconds));$('deviceMessage').className='note device-note'+(compatible?'':' warn');$('deviceMessage').innerHTML='<span class="note-k">Device</span><span>'+esc(data.message||'Status updated.')+'</span>';if(!online){$('devicePreview').classList.add('offline');$('previewEmpty').classList.remove('hidden');setText('previewTag','offline')}}
async function refreshDevice(force){try{var data=await api('/api/device/status'+(force?'?t='+Date.now():''));renderDevice(data);return data}catch(error){renderDevice({reachable:false,compatible:false,message:error.message,address:app.info&&app.info.ip});return null}}
function refreshPreview(){var image=$('devicePreview');setText('previewTag','loading');image.onload=function(){image.classList.remove('offline');$('previewEmpty').classList.add('hidden');setText('previewTag',image.naturalWidth+'×'+image.naturalHeight)};image.onerror=function(){image.classList.add('offline');$('previewEmpty').classList.remove('hidden');setText('previewTag','unavailable')};image.src='/api/device/screen?t='+Date.now()}
$('refreshDeviceBtn').addEventListener('click',async function(){this.disabled=true;await refreshDevice(true);this.disabled=false});
$('refreshPreviewBtn').addEventListener('click',refreshPreview);
$('openDeviceBtn').addEventListener('click',async function(){var address=$('esp32_ip').value.trim()||(app.info&&app.info.ip)||'';if(!address){showToast('Set the device address first.',true);return}address=address.replace(/^https?:\/\//,'').replace(/\/$/,'');var url='http://'+address+'/';try{if(window.pywebview&&window.pywebview.api&&window.pywebview.api.open_url){await window.pywebview.api.open_url(url)}else{window.open(url,'_blank')}}catch(error){showToast(error.message,true)}});

function showAudio(s){var chk=$('audioChk');chk.checked=!!s.audioEnabled;chk.disabled=!s.audioAvailable;var tag=!s.audioAvailable?'unavailable':!s.audioEnabled?'off':s.audioError?'error':s.audioSending?'streaming':'starting';setText('audioState',tag);setText('audioHint',!s.audioAvailable?'Needs the numpy and soundcard Python packages ('+(s.audioReason||'not installed')+').':s.audioError?s.audioError:'Feeds the Visualizer tiles on the deck (bars or scope) over WiFi, about 9 KB/s while on.')}
async function refreshLocalStatus(){try{var status=await api('/api/status');showAudio(status);setText('srSource',status.source||'-');setText('srCount',status.metricCount+' metric'+(status.metricCount===1?'':'s')+(status.monitoring?' sending':' idle'))}catch(error){}}
async function refreshLive(){try{var data=await api('/api/live');app.live={};(data.metrics||[]).forEach(function(metric){app.live[metric.id]=metric});renderSelected()}catch(error){}}

$('saveBtn').addEventListener('click',async function(){this.disabled=true;try{await syncAliases();await api('/api/save',{method:'POST'});setDirty(false);showToast('Sensor stream saved.')}catch(error){showToast(error.message,true)}finally{this.disabled=false}});
$('revertBtn').addEventListener('click',async function(){try{await api('/api/revert',{method:'POST'});await Promise.all([loadInfo(),loadSensors(false)]);setDirty(false);showToast('Unsaved sensor changes reverted.')}catch(error){showToast(error.message,true)}});

var panelPairAddress='';
var panelsLoading=false;
function panelCodeBox(address){panelPairAddress=address;$('panelCodeBox').classList.toggle('hidden',!address);setText('panelPairAddress',address);if(address){$('panelCode').value='';$('panelCode').focus()}}
async function panelAction(action,address,code){return api('/api/panels/'+action,{method:'POST',body:new URLSearchParams({address:address,code:code||''})})}
async function loadPanels(){
  if(panelsLoading)return;
  panelsLoading=true;
  try{
    var data=await api('/api/panels');
    setText('panelCount',data.panels.length+' / '+data.max);
    $('panelAddBtn').disabled=data.panels.length>=data.max;
    $('panelList').innerHTML=data.panels.map(function(panel){
      var status=panel.reachable?(panel.compatible?'online / compatible':'online / incompatible'):'offline / compatibility unknown';
      return '<div class="field"><strong>'+esc(panel.address)+'</strong> <span class="tag">'+status+'</span> <span class="tag">'+(panel.paired?'paired':'not paired')+'</span><div class="page-actions" data-panel="'+esc(panel.address)+'"><button type="button" class="btn btn-accent" data-panel-action="pair/start">Pair</button>'+(panel.paired?'<button type="button" class="btn" data-panel-action="pair/forget">Forget pairing</button>':'')+'<button type="button" class="btn" data-panel-action="remove">Remove</button></div></div>';
    }).join('')||'<p class="field-hint">No extra panels added.</p>';
    if(panelPairAddress&&!data.panels.some(function(panel){return panel.address===panelPairAddress}))panelCodeBox('');
  }finally{panelsLoading=false}
}
$('panelAddForm').addEventListener('submit',async function(event){event.preventDefault();try{var data=await panelAction('add',$('panelAddress').value);$('panelAddress').value='';showToast(data.message);await loadPanels()}catch(error){showToast(error.message,true)}});
$('panelList').addEventListener('click',async function(event){
  var button=event.target.closest('[data-panel-action]');
  if(!button)return;
  var address=button.parentElement.dataset.panel;var action=button.dataset.panelAction;
  button.disabled=true;
  try{
    if(action==='pair/start'&&panelPairAddress)await panelAction('pair/cancel',panelPairAddress);
    var data=await panelAction(action,address);showToast(data.message);
    if(action==='pair/start')panelCodeBox(address);else if(panelPairAddress===address)panelCodeBox('');
    await loadPanels();
  }catch(error){showToast(error.message,true)}finally{button.disabled=false}
});
$('panelConfirmBtn').addEventListener('click',async function(){this.disabled=true;try{var data=await panelAction('pair/confirm',panelPairAddress,$('panelCode').value);panelCodeBox('');showToast(data.message);await loadPanels()}catch(error){showToast(error.message,true)}finally{this.disabled=false}});
$('panelCancelBtn').addEventListener('click',async function(){this.disabled=true;try{var data=await panelAction('pair/cancel',panelPairAddress);panelCodeBox('');showToast(data.message)}catch(error){showToast(error.message,true)}finally{this.disabled=false}});

async function loadAutostart(){try{var data=await api('/api/autostart');$('autostartChk').checked=!!data.enabled;setText('autostartState',data.enabled?'enabled':'disabled')}catch(error){setText('autostartState','unavailable')}}
$('audioChk').addEventListener('change',async function(){try{var body=new URLSearchParams({enable:this.checked?'1':'0'});showAudio(await api('/api/audio',{method:'POST',body:body}))}catch(error){showToast(error.message,true);await refreshLocalStatus()}});
$('autostartChk').addEventListener('change',async function(){try{var body=new URLSearchParams({enable:this.checked?'1':'0'});var data=await api('/api/autostart',{method:'POST',body:body});this.checked=!!data.enabled;setText('autostartState',data.enabled?'enabled':'disabled')}catch(error){showToast(error.message,true);await loadAutostart()}});

function downloadJson(data){var blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'});var url=URL.createObjectURL(blob);var link=document.createElement('a');link.href=url;link.download='touchdeck-companion.json';link.click();setTimeout(function(){URL.revokeObjectURL(url)},1000)}
$('exportBtn').addEventListener('click',async function(){try{var data=await api('/api/export');var text=JSON.stringify(data,null,2);if(window.pywebview&&window.pywebview.api&&window.pywebview.api.save_text){await window.pywebview.api.save_text(text,'touchdeck-companion.json')}else{downloadJson(data)}}catch(error){showToast(error.message,true)}});
async function importText(text){var parsed=JSON.parse(text);var data=await api('/api/import',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(parsed)});await Promise.all([loadInfo(),loadSensors(false)]);setDirty(false);showToast(data.message||'Configuration imported.')}
$('importBtn').addEventListener('click',async function(){try{if(window.pywebview&&window.pywebview.api&&window.pywebview.api.open_text){var result=await window.pywebview.api.open_text();if(result&&result.ok)await importText(result.text)}else{$('importFile').click()}}catch(error){showToast(error.message,true)}});
$('importFile').addEventListener('change',async function(){if(!this.files.length)return;try{await importText(await this.files[0].text())}catch(error){showToast(error.message,true)}this.value=''});

/* Wallpapers: the companion converts and uploads in a background job (walls.py). */
var wallSources=['My pictures','Daily pictures','Both'];
var wallPoll=0;
function wallPair(l,p){return l+' landscape, '+p+' portrait'}
async function loadWallDeck(){try{var d=await api('/api/walls/deck');var c=d.counts;setText('wallDeckTag','online');setText('wallStorage',d.sd_mounted?'microSD card':(d.sd_enabled?'internal flash (no card found)':'internal flash'));setText('wallShows',wallSources[d.source]||'-');setText('wallOwn',wallPair(c.ml,c.mp));setText('wallDaily',wallPair(c.dl,c.dp))}catch(error){setText('wallDeckTag','offline');['wallStorage','wallShows','wallOwn','wallDaily'].forEach(function(id){setText(id,'-')})}}
function renderWallJob(s){var card=$('wallJobCard');if(!s.kind){card.classList.add('hidden');return}card.classList.remove('hidden');qa('.wall-start').forEach(function(b){b.disabled=s.running});$('wallCancelBtn').classList.toggle('hidden',!s.running);setText('wallJobTag',s.running?'running':(s.error?'stopped':'done'));$('wallJobBar').style.width=(s.total?Math.min(100,100*s.done/s.total):0)+'%';setText('wallJobCounts',s.done+' / '+s.total+' · '+s.added+' added · '+s.skipped+' already there · '+s.failed+' failed');setText('wallJobMsg',s.message);$('wallJobNote').className='note '+(s.error?'warn':'plain');$('wallJobLog').classList.toggle('hidden',!s.log.length);setText('wallJobLog',s.log.join('\n'))}
async function pollWallJob(){clearTimeout(wallPoll);try{var s=await api('/api/walls/job');renderWallJob(s);if(s.running){wallPoll=setTimeout(pollWallJob,1000);return}if(s.kind)loadWallDeck()}catch(error){}}
async function startWallJob(kind,body){try{renderWallJob(await api('/api/walls/'+kind,{method:'POST',body:body}));pollWallJob()}catch(error){showToast(error.message,true)}}
$('wallDownloadBtn').addEventListener('click',function(){startWallJob('download',formBody($('wallDownloadForm')))});
$('wallFolderBtn').addEventListener('click',function(){var body=formBody($('wallFolderForm'));body.set('recursive',$('wallRecursive').checked?'1':'0');startWallJob('folder',body)});
$('wallCancelBtn').addEventListener('click',async function(){try{showToast((await api('/api/walls/cancel',{method:'POST'})).message)}catch(error){showToast(error.message,true)}});
$('wallRefreshBtn').addEventListener('click',loadWallDeck);
$('wallBrowseBtn').addEventListener('click',async function(){try{var r=await window.pywebview.api.pick_folder();if(r&&r.ok)$('wallFolder').value=r.path;else if(r&&r.error)showToast(r.error,true)}catch(error){showToast(error.message,true)}});
/* The folder dialog exists only in the native window; pywebview injects its API after load. */
function wallBrowseSync(){$('wallBrowseBtn').classList.toggle('hidden',!(window.pywebview&&window.pywebview.api&&window.pywebview.api.pick_folder))}
window.addEventListener('pywebviewready',wallBrowseSync);wallBrowseSync();

async function start(){try{await loadInfo();await Promise.all([loadSensors(false),loadAutostart(),loadPanels(),refreshLocalStatus(),refreshDevice(false),refreshLive()]);setDirty(false)}catch(error){showToast(error.message,true)}setInterval(refreshLocalStatus,3000);setInterval(refreshSerialStatus,3000);setInterval(refreshLive,3000);setInterval(function(){refreshDevice(false);if(document.querySelector('.page[data-page="device"]').classList.contains('active'))refreshPreview();if(document.querySelector('.page[data-page="connection"]').classList.contains('active'))loadPanels().catch(function(error){showToast(error.message,true)})},5000)}
start();
