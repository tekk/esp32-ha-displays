#ifndef SETTINGS_H
#define SETTINGS_H

#include <Arduino.h>
#include "config.h"

// Night brightness schedule. Versioned NVS blob "backlight"; `brightness` is
// the day level and lives in its own key.
struct BacklightSettings {
  uint8_t  version;
  uint8_t  nightEnabled;
  uint8_t  nightBrightness;
  uint8_t  reserved0;            // StatNode's offline-off flag, unused
  uint16_t nightStartMinute;     // minute of day, 0..1439
  uint16_t nightEndMinute;       // minute of day, 0..1439
  uint16_t reserved1;            // StatNode's offline sleep delay, unused
};

// Filament / status LED on a PWM pin. Versioned NVS blob "led"; see led.cpp.
struct LedSettings {
  uint8_t version;
  uint8_t enabled;
  uint8_t pin;
  uint8_t brightness;       // 0..255, the normal daytime level
  uint8_t nightEnabled;     // use nightBrightness inside the LED's own night interval
  uint8_t nightBrightness;  // 0..255, 0 switches the LED fully off at night
  uint8_t followDisplay;    // dark whenever the panel itself is dark
  uint8_t offlineOff;       // dark while the PC companion is offline
  uint16_t nightStartMinute;  // minute of day, 0..1439; v2, v1 shared the backlight's
  uint16_t nightEndMinute;    // minute of day, 0..1439
};

// Panel and PC metric tile settings, each its own NVS scalar.
constexpr uint8_t DAILY_MAX_COUNT = 32;

struct DisplaySettings {
  uint8_t  rotation;          // 0..3 (x90 degrees)
  uint16_t tempScaleMax;      // C, default full scale of temperature tiles
  uint16_t powerScaleW;       // W, default full scale of power tiles
  uint8_t  warnThresholdPct;  // metric tiles turn amber at >= this % of scale; 0 = off
  uint8_t  theme;             // THEME_MIDNIGHT, THEME_DAYLIGHT or THEME_GLASS
  uint8_t  glassTint;         // Glass: tile tint opacity %, 0..90
  uint8_t  glassBlur;         // Glass: blur radius px, 0..24 (0 = clear glass)
  uint8_t  glassDim;          // Glass: wallpaper darkened by %, 0..60
  uint8_t  glassOn;           // Glass: accent fill of an "on" tile, opacity %, 20..100
  uint8_t  wallEvery;         // Wallpaper interval in minutes, 0 = off
  uint8_t  wallOrder;         // 0 = in order, 1 = shuffle
  bool     wallDaily;         // Daily downloads enabled
  uint8_t  wallSource;        // 0 = own, 1 = daily, 2 = both
  bool     sdCard;
  uint16_t dailyMax;          // SD archive per orientation: 50, 100, 200 or 500
  uint8_t  dailyHour;         // Daily fetch hour, local time 0..23
  uint8_t  dailyOrient;       // 0 = landscape, 1 = portrait, 2 = both
  uint8_t  dailyCount;        // Daily pictures per orientation, 1..DAILY_MAX_COUNT
  bool     glassAutoText;     // Glass: text colour and tint follow the picture per tile
  bool     smoothCharts;      // PC metric charts glide between packets
  bool     printerFx;         // printer tiles: heat / frost, turning spool, print head
  uint8_t  tileFx;            // Tile animations: 0 classic, 1 calm, 2 water, 3 glass, 4 heavy, 5 custom
  // Custom (tileFx 5): one effect per moment, numbered as in the web selects.
  uint8_t  fxTouch, fxToggle, fxPage, fxCard;
};

// Screen sleep (portal Screen page); NVS scalars. Present = an entity
// "on"/"home", (pc) any PC online, or (printing) a printer with a job.
constexpr size_t MAX_PRESENCE_ENTITIES = 4;
struct PresenceSettings {
  uint16_t sleepMin = 0;  // 0 = never sleeps
  uint8_t dimPct = 0;     // asleep: 0 = backlight off, else at most this % of full
  bool frame = false;
  uint8_t frameEvery = 5;
  bool frameClock = true;
  bool frameAnim = true;
  bool pc = false;
  bool printing = false;
  bool nightWake = false;        // presence lifts the night schedule to nightWakeLevel
  uint8_t nightWakeLevel = 128;  // 0..255
  String entities[MAX_PRESENCE_ENTITIES];  // "" = unused slot
};

// Portal Advanced page; NVS scalars.
struct AdvancedSettings {
  bool printers;  // Bambu printers over LAN; off hides their pages and tiles, config kept
  bool weather60;  // weather icons every refresh (boards with a refresh clock, the 7B)
  bool charts60;   // chart glide and printer effects every refresh
  bool smoothDisplay;  // DSI boards: no scan ring, up to 60 fps but flash writes may flash the panel; on restart
};

// Printers page: printer errors, the bed cooled alert and print energy cost; NVS scalars.
struct PrinterSettings {
  bool errors = true;      // badge, error card and alerts for HMS / print_error
  bool errorsAll = false;  // common codes too, not only fatal and serious
  bool errorWake = true;   // a new error wakes the deck and shows the printer page
  bool follow = false;     // a print start shows the printer page, back once the bed has cooled
  bool coolAlert = true;   // after a print, say when the bed has cooled
  uint8_t coolTemp = 35;   // C
  float kwhPrice = 0;      // per kWh, 0 = energy without a cost
  char currency[8] = "";
};
constexpr uint8_t PRN_COOL_MIN = 20, PRN_COOL_MAX = 80;

// Vibration motor module on a GPIO (portal Hardware page); NVS scalars.
struct HapticSettings {
  bool enabled = false;
  uint8_t pin = 0;        // 0 = not chosen yet
  uint8_t strength = 100; // PWM duty %, HAPTIC_MIN_STRENGTH..100
  uint8_t pulseMs = 40;   // HAPTIC_MIN_MS..HAPTIC_MAX_MS
};
constexpr uint8_t HAPTIC_MIN_STRENGTH = 20;
constexpr uint8_t HAPTIC_MIN_MS = 10;
constexpr uint8_t HAPTIC_MAX_MS = 200;

constexpr size_t ENCODER_COUNT = 2;
constexpr uint8_t ENCODER_FOLLOW = 0, ENCODER_FIXED = 1, ENCODER_PC = 2;
constexpr uint8_t ENCODER_POPUP_DROPLET = 0, ENCODER_POPUP_EDGE = 1,
                  ENCODER_POPUP_BEAD = 2, ENCODER_POPUP_SIDE_PILL = 3;
constexpr uint8_t ENCODER_POPUP_STYLE = 0, ENCODER_POPUP_SLIDE = 1,
                  ENCODER_POPUP_FADE = 2, ENCODER_POPUP_NONE = 3, ENCODER_POPUP_WOBBLE = 4;

struct EncoderPopupSettings {
  uint8_t style = ENCODER_POPUP_DROPLET;
  uint8_t size = 1;
  uint8_t opacity = 88;
  uint8_t speed = 100;  // motion speed %, 50..200
  uint16_t holdMs = 1500;
  uint8_t anim = ENCODER_POPUP_STYLE;
  bool entityColor = true;
  uint32_t accentColor = 0xFFB45C;
};

struct EncoderSettings {
  bool enabled = false;
  uint8_t pinA = 0, pinB = 0, pinKey = 0;
  bool reverse = false;
  uint8_t mode = ENCODER_FOLLOW;
  uint8_t stepPct = 5;
  uint8_t countsPerDetent = 4;
  uint8_t popupY = 30;
  uint8_t edge = 0;
  char entity[72] = "";
};

// NS4168 speaker (portal Hardware page); NVS scalars. A file name is a WAV in
// audioDir(), "" = the built-in sound.
constexpr size_t AUDIO_FILE_LEN = 40;
constexpr uint16_t AUDIO_WAKE_MAX_MS = 1000;
constexpr uint32_t AUDIO_KEEP_ON_MIN_MS = 500;
constexpr uint32_t AUDIO_KEEP_ON_MAX_MS = 600000;

struct AudioSettings {
  bool enabled = false;
  uint8_t volume = 94;     // 0..100 on the dB scale (audioGainQ15), also the agent's voice
  bool nightMute = true;   // silent while the screen's night schedule is active
  bool click = false;      // tile taps
  bool finished = true;    // print finished
  bool error = true;       // new printer error
  bool cooled = true;      // bed cooled after a print
  uint16_t wakeMs = BOARD_AUDIO_WAKE_MS;       // amp + codec settle after power-up
  uint32_t keepOnMs = BOARD_AUDIO_KEEP_ON_MS;  // idle time before the amp is cut
  char fileFinished[AUDIO_FILE_LEN] = "";
  char fileError[AUDIO_FILE_LEN] = "";
  char fileCooled[AUDIO_FILE_LEN] = "";
};

// AI Agent (portal AI Agent page): a xiaozhi-protocol voice server or a Home
// Assistant Assist pipeline; boards with microphones only. NVS scalars.
constexpr size_t AGENT_URL_LEN = 128;
constexpr size_t AGENT_TOKEN_LEN = 128;
constexpr size_t AGENT_PIPELINE_LEN = 40;
constexpr uint8_t AGENT_BACKEND_XIAOZHI = 0, AGENT_BACKEND_HA = 1;
constexpr uint8_t AGENT_PGA_MAX = 14;     // ES7210 gain steps: 0 = 0 dB .. 14 = 37.5 dB
constexpr uint8_t AGENT_BOOST_MAX = 24;   // digital gain, dB
constexpr uint16_t AGENT_PAUSE_MIN_MS = 500, AGENT_PAUSE_MAX_MS = 3000;
constexpr uint8_t AGENT_IDLE_MIN_S = 3, AGENT_IDLE_MAX_S = 60;

struct AgentSettings {
  bool enabled = false;
  uint8_t backend = AGENT_BACKEND_XIAOZHI;
  char pipeline[AGENT_PIPELINE_LEN] = "";  // HA pipeline id, "" = preferred
  char url[AGENT_URL_LEN] = "";      // ws://host:port/path
  char token[AGENT_TOKEN_LEN] = "";  // sent as Authorization: Bearer
  uint8_t pga = 12;                   // 34.5 dB
  uint8_t boostDb = 6;
  uint16_t endPauseMs = 1100;         // quiet that ends what the user says
  uint8_t idleSec = 8;                // listening with nobody talking ends the chat
  bool chimes = true;                 // notes when listening starts and the chat ends
  char clientId[40] = "";            // UUID, made once
};

constexpr uint8_t THEME_MIDNIGHT = 0;
constexpr uint8_t THEME_DAYLIGHT = 1;
constexpr uint8_t THEME_GLASS = 2;  // Midnight colours, glass tiles over a wallpaper

// Network settings. NVS blob "net", layout shared with StatNode.
struct NetworkSettings {
  bool useDHCP;           // true = DHCP, false = static
  char staticIP[16];
  char gateway[16];
  char subnet[16];
  char dns[16];
  bool showIPAtStartup;   // show the IP screen for a moment after WiFi connects
  uint8_t timezoneIndex;  // unused
  char timezoneStr[64];   // POSIX TZ string
  bool use24h;            // top bar clock: 24h (default) or 12h
  uint8_t dateFormat;     // unused
  bool mdnsEnabled;       // advertise <hostname>.local over mDNS
  char hostname[32];      // sanitized [a-z0-9-], default "touchdeck"
};

extern char wifiSSID[33];
extern char wifiPass[65];
extern uint8_t brightness;
extern DisplaySettings dispSettings;
extern NetworkSettings netSettings;
// Where the clock comes from: network time (NTP) or Home Assistant, for decks
// on a network that reaches only Home Assistant. NVS key "tsrc", outside the
// "net" blob, whose layout is shared with StatNode.
constexpr uint8_t TIME_SRC_NTP = 0;
constexpr uint8_t TIME_SRC_HA = 1;
extern uint8_t timeSource;
extern BacklightSettings backlightSettings;
extern LedSettings ledSettings;
extern AdvancedSettings advSettings;
extern PresenceSettings presenceSettings;
extern HapticSettings hapticSettings;
#if BOARD_HAS_ENCODER
extern EncoderSettings encoderSettings[ENCODER_COUNT];
extern EncoderPopupSettings encoderPopupSettings;
EncoderSettings defaultEncoderSettings(size_t i);
#endif
extern AudioSettings audioSettings;
extern AgentSettings agentSettings;
extern PrinterSettings printerSettings;

bool validDailyMax(int count);
bool validWallEvery(int minutes);
bool validFrameEvery(int minutes);
void loadSettings();
void saveSettings();
bool factoryResetSettings();
void defaultDisplaySettings(DisplaySettings& ds);
void defaultNetworkSettings(NetworkSettings& ns);
void defaultBacklightSettings(BacklightSettings& bs);
void defaultLedSettings(LedSettings& ls);

// Normalize a string into a valid mDNS/DNS label: lowercase, keep only
// [a-z0-9-], strip leading/trailing hyphens. Falls back to "touchdeck".
void sanitizeHostname(const char* in, char* out, size_t outSize);

#endif // SETTINGS_H
