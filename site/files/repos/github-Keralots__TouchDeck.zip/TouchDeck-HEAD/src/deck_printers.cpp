// Guition deck: printer secrets and the plug power gate. See deck_printers.h.
#include "deck_printers.h"
#include <Preferences.h>
#include "deck_bambu.h"
#include "deck_bambu_ha.h"
#include "deck_ha.h"
#include "settings.h"

namespace deck {
namespace {

constexpr const char* NVS_NS = "printers";
// Without a reachable HA the plug state is unknown: after this long the
// printer is tried anyway rather than staying dark.
constexpr uint32_t HA_GRACE_MS = 60000;

struct Power {
  String id;
  bool on = false;
  bool known = false;  // the plug state was read from HA at least once
};
std::vector<Power> s_power;  // printers handed to deck_bambu (they have secrets)

void readSecret(const String& id, String& serial, String& code) {
  Preferences p;
  if (!p.begin(NVS_NS, true)) return;
  serial = p.getString(("s_" + id).c_str(), "");
  code = p.getString(("c_" + id).c_str(), "");
  p.end();
}

}  // namespace

void printersApply(const DeckConfig& cfg) {
  std::vector<PrinterConn> list;
  std::vector<PrinterHaDef> haList;
  std::vector<String> ids;  // both sources, in config order
  if (advSettings.printers) {  // else switched off on the Advanced page
    for (const PrinterDef& d : cfg.printers) {
      if (d.ha) {
        haList.push_back({d.id, d.serial});
        ids.push_back(d.id);
        continue;
      }
      PrinterConn c;
      c.id = d.id;
      c.ip = d.ip;
      readSecret(d.id, c.serial, c.code);
      if (c.serial.length() && c.code.length()) {
        list.push_back(c);
        ids.push_back(c.id);
      }
    }
  }
  printersSet(list);
  printersHaSet(haList);
  std::vector<Power> next;
  for (const String& id : ids) {
    Power p{id, false};
    for (const Power& old : s_power)
      if (old.id == id) {
        p.on = old.on && printerPowered(id);
        p.known = old.known;
      }
    next.push_back(p);
  }
  s_power = next;
}

bool printerSecretSet(const String& id, const String& serial, const String& code) {
  Preferences p;
  if (!p.begin(NVS_NS, false)) return false;
  bool ok = true;
  if (serial.length()) ok &= p.putString(("s_" + id).c_str(), serial) > 0;
  if (code.length()) ok &= p.putString(("c_" + id).c_str(), code) > 0;
  p.end();
  return ok;
}

bool printerHasSecret(const String& id) {
  if (printerHaKnown(id)) return true;  // HA source needs none
  String serial, code;
  readSecret(id, serial, code);
  return serial.length() && code.length();
}

bool printersPowerSync(const DeckConfig& cfg) {
  const bool haUp = haLink() == HA_CONNECTED;
  const bool haMissing = !haUrl().length() || !haHasToken();
  bool changed = false;
  for (const PrinterDef& d : cfg.printers) {
    Power* pw = nullptr;
    for (Power& p : s_power)
      if (p.id == d.id) pw = &p;
    if (!pw) continue;  // no serial / access code yet
    bool on = pw->on;
    HaEntity e;
    if (!d.plug.length() || haMissing) on = true;
    else if (haUp && haGetEntity(d.plug, e) && e.known) {
      on = e.state == "on";
      pw->known = true;
    }
    // HA down: a plug seen before keeps its state; a LAN printer never seen is tried.
    else if (!haUp && !pw->known && !d.ha && millis() > HA_GRACE_MS) on = true;
    if (on != pw->on) {
      pw->on = on;
      if (d.ha) printerHaPower(d.id, on);
      else printerPower(d.id, on);
      changed = true;
    }
  }
  printersHaTick();
  return changed;
}

}  // namespace deck
