// Deck UI: tile animations. A preset (Display > Animations) picks one effect
// for each moment: touch, on/off change, page change, card. Calm: a ring, a
// pop and halo, crossfade, the card growing out of its tile. Water: drop
// rings, on colour flooding out of the finger, a water edge between pages,
// the card revealed in a circle. Glass: a highlight and a springy release,
// a sheen, pages in depth, the card rising as a sheet. Page changes and
// cards are drawn by the compositor (deck_panel.cpp).
#include "deck_ui_int.h"

namespace deckui {

namespace {

enum FxTouch : uint8_t { TOUCH_NONE, TOUCH_RING, TOUCH_DROP, TOUCH_PRESS, TOUCH_DISTORT };
enum FxToggle : uint8_t { TOGGLE_NONE, TOGGLE_BLOOM, TOGGLE_LIQUID, TOGGLE_SHEEN, TOGGLE_AURORA };
enum FxCard : uint8_t { CARD_NONE, CARD_MORPH, CARD_REVEAL, CARD_SHEET };
struct FxSet {
  FxTouch touch;
  FxToggle toggle;
  PageFx page;
  FxCard card;
};
// Indexed by dispSettings.tileFx; 5 = custom, from the four settings.
constexpr FxSet kSets[] = {
    {TOUCH_NONE, TOGGLE_NONE, PAGE_SLIDE, CARD_NONE},      // Classic
    {TOUCH_RING, TOGGLE_BLOOM, PAGE_FADE, CARD_MORPH},     // Calm
    {TOUCH_DROP, TOGGLE_LIQUID, PAGE_WATER, CARD_REVEAL},  // Water
    {TOUCH_PRESS, TOGGLE_SHEEN, PAGE_DEPTH, CARD_SHEET},   // Glass
    {TOUCH_DISTORT, TOGGLE_AURORA, PAGE_CASCADE, CARD_MORPH},  // Heavy
};

FxSet fx() {
  const DisplaySettings& d = dispSettings;
  if (d.tileFx < sizeof(kSets) / sizeof(kSets[0])) return kSets[d.tileFx];
  return {(FxTouch)LV_MIN(d.fxTouch, TOUCH_DISTORT), (FxToggle)LV_MIN(d.fxToggle, TOGGLE_AURORA),
          (PageFx)LV_MIN(d.fxPage, PAGE_CASCADE), (FxCard)LV_MIN(d.fxCard, CARD_SHEET)};
}

constexpr uint32_t RIPPLE_MS = 600, POP_MS = 560, SQUISH_MS = 300, HALO_MS = 700;
constexpr uint32_t DROP_MS = 1280, DROP_RING_MS = 1000, DROP_GAP_MS = 140, SPLASH_MS = 320;
constexpr uint32_t LIQUID_ON_MS = 460, LIQUID_OFF_MS = 380;
constexpr uint32_t MORPH_MS = 300, MORPH_BACK_MS = 240, REVEAL_MS = 460, REVEAL_BACK_MS = 320;
constexpr uint32_t SHEET_MS = 460, SHEET_BACK_MS = 260;
constexpr uint32_t PRESS_FRESH_MS = 3000;  // a touch this recent places on/off and card effects
constexpr int32_t P = 1024;  // animation progress range

uint32_t s_quietUntil = 0;
lv_draw_buf_t* s_cardPic = nullptr;  // screen sized, kept once used
FxCard s_openFx = CARD_NONE;        // the open card's effect, its close plays the same
lv_point_t s_revealAt = {};          // where the open card's circle came from

float smooth(float t) { return t * t * (3 - 2 * t); }
float easeOut(float t) { return 1 - (1 - t) * (1 - t) * (1 - t); }
float clamp01(float t) { return t < 0 ? 0 : t > 1 ? 1 : t; }

// A non-clickable child outside the parent's layout. No clip_corner on the
// tile: it costs more than the rest of the effect (measured on the deck).
lv_obj_t* overlay(lv_obj_t* parent) {
  lv_obj_t* o = lv_obj_create(parent);
  lv_obj_remove_style_all(o);
  lv_obj_add_flag(o, (lv_obj_flag_t)(LV_OBJ_FLAG_IGNORE_LAYOUT | LV_OBJ_FLAG_FLOATING));
  lv_obj_remove_flag(o, (lv_obj_flag_t)(LV_OBJ_FLAG_CLICKABLE | LV_OBJ_FLAG_SCROLLABLE));
  return o;
}

// Tile shaped clip box over the whole tile for an effect's objects:
// clip_corner on it redraws only its own children.
lv_obj_t* tileBox(const TileRt& r) {
  lv_area_t tc, cc;
  lv_obj_get_coords(r.obj, &tc);
  lv_obj_get_content_coords(r.obj, &cc);
  lv_obj_t* box = overlay(r.obj);
  lv_obj_set_pos(box, tc.x1 - cc.x1, tc.y1 - cc.y1);
  lv_obj_set_size(box, lv_area_get_width(&tc), lv_area_get_height(&tc));
  lv_obj_set_style_radius(box, lv_obj_get_style_radius(r.obj, LV_PART_MAIN), 0);
  lv_obj_set_style_clip_corner(box, true, 0);
  return box;
}

// A circle's centre (in the parent's content coords) and target size, owned
// by the object (packing them into the pointer ran out of bits on 1024 px).
struct CircleGeo {
  int16_t cx, cy, size;
};
void unpack(const void* k, int& cx, int& cy, int& size) {
  const CircleGeo& g = *(const CircleGeo*)k;
  cx = g.cx;
  cy = g.cy;
  size = g.size;
}

void placeCircle(lv_obj_t* o, int cx, int cy, int d) {
  lv_obj_set_size(o, d, d);
  lv_obj_set_pos(o, cx - d / 2, cy - d / 2);
}

lv_obj_t* circle(lv_obj_t* parent, int cx, int cy, int size) {
  lv_obj_t* o = overlay(parent);
  CircleGeo* g = (CircleGeo*)lv_malloc(sizeof(CircleGeo));
  *g = {(int16_t)cx, (int16_t)cy, (int16_t)size};
  lv_obj_set_user_data(o, g);
  lv_obj_add_event_cb(o, [](lv_event_t* e) { lv_free(lv_event_get_user_data(e)); }, LV_EVENT_DELETE, g);
  lv_obj_set_style_radius(o, LV_RADIUS_CIRCLE, 0);
  placeCircle(o, cx, cy, 2);
  return o;
}

void startAnim(void* var, lv_anim_exec_xcb_t exec, uint32_t ms, lv_anim_path_cb_t path,
               lv_anim_completed_cb_t done) {
  lv_anim_t a;
  lv_anim_init(&a);
  lv_anim_set_var(&a, var);
  lv_anim_set_exec_cb(&a, exec);
  lv_anim_set_values(&a, 0, P);
  lv_anim_set_duration(&a, ms);
  lv_anim_set_path_cb(&a, path);
  if (done) lv_anim_set_completed_cb(&a, done);
  lv_anim_start(&a);
}

// Distance from p to the farthest corner of a: a circle that big covers it.
int farCorner(const lv_area_t& a, lv_point_t p) {
  const int dx = LV_MAX(p.x - a.x1, a.x2 - p.x), dy = LV_MAX(p.y - a.y1, a.y2 - p.y);
  return (int)sqrtf((float)(dx * dx + dy * dy)) + 2;
}

// The tile's last touch if it was recent and on the tile, else its centre.
lv_point_t touchPoint(const TileRt& r) {
  lv_area_t a;
  lv_obj_get_coords(r.obj, &a);
  const lv_point_t& p = r.press;
  if (r.pressMs && millis() - r.pressMs < PRESS_FRESH_MS && p.x >= a.x1 && p.x <= a.x2 && p.y >= a.y1 && p.y <= a.y2)
    return p;
  return {(a.x1 + a.x2) / 2, (a.y1 + a.y2) / 2};
}

// --- Touch: ripple ring (Calm) -----------------------------------------------------------
void rippleStep(void* var, int32_t v) {
  lv_obj_t* o = (lv_obj_t*)var;
  int cx, cy, r;
  unpack(lv_obj_get_user_data(o), cx, cy, r);
  placeCircle(o, cx, cy, LV_MAX(2, 2 * r * v / P));
  // Fades faster than it grows, so the ring is faint by the rounded corners.
  const float left = (float)(P - v) / P;
  lv_obj_set_style_border_opa(o, (lv_opa_t)(200 * left * left), 0);
}

// The touch effect's object is r.fx, a child of the tile.
void touchDone(lv_anim_t* a) {
  lv_obj_t* o = (lv_obj_t*)a->var;
  if (TileRt* r = tileOf(lv_obj_get_parent(o)))
    if (r->fx == o) r->fx = nullptr;
  lv_obj_delete_async(o);
}

// --- Touch: water drop (Water) -------------------------------------------------------------
// One A8 image over the tile, painted per frame: three rings 140 ms apart,
// then the splash at the finger. The tile's corners are cut in the image
// (a clip layer with bordered circles cost over a frame).
struct Drop {
  lv_draw_buf_t* buf;
  uint8_t* corner;  // coverage of the tile's top left corner, cr x cr
  int16_t w, h, cx, cy, cr;
  float size;  // the rings' last diameter
};

void dropFree(Drop* q) {
  if (q->buf) lv_draw_buf_destroy(q->buf);
  heap_caps_free(q->corner);
  delete q;
}

void dropDelete(lv_event_t* e) { dropFree((Drop*)lv_event_get_user_data(e)); }

// Adds a ring between the radii in and out (a disc when in <= 0). Edges are
// smoothed with d ~ (d2 + R2) / 2R, no root per pixel.
void dropShape(Drop& q, float out, float in, int alpha) {
  if (alpha <= 0 || out < 1) return;
  const int reach = (int)out + 1;
  const int x0 = LV_MAX(0, q.cx - reach), x1 = LV_MIN(q.w - 1, q.cx + reach);
  const int y0 = LV_MAX(0, q.cy - reach), y1 = LV_MIN(q.h - 1, q.cy + reach);
  const float o2 = out * out, i2 = in * in, ko = .5f / out, ki = in > .5f ? .5f / in : 0;
  const int hi2 = (int)((out + .5f) * (out + .5f)) + 1;
  const int lo2 = in > 1 ? (int)((in - .5f) * (in - .5f)) : -1;
  const int cr = q.cr;
  int wo = 0, wi = 0;  // the row's half widths: outer edge, empty middle
  for (int y = y0; y <= y1; y++) {
    uint8_t* row = q.buf->data + y * q.buf->header.stride;
    const int ey = y < cr ? y : y >= q.h - cr ? q.h - 1 - y : -1;
    const int dy2 = (y - q.cy) * (y - q.cy);
    if (dy2 > hi2) continue;
    while ((wo + 1) * (wo + 1) + dy2 <= hi2) wo++;
    while (wo > 0 && wo * wo + dy2 > hi2) wo--;
    while (wi * wi + dy2 < lo2) wi++;
    while (wi > 0 && (wi - 1) * (wi - 1) + dy2 >= lo2) wi--;
    // Left and right of the empty middle; one run when the row has none.
    for (int side = 0; side < (wi > 0 ? 2 : 1); side++) {
      const int a0 = LV_MAX(x0, wi > 0 && side ? q.cx + wi : q.cx - wo);
      const int a1 = LV_MIN(x1, wi > 0 && !side ? q.cx - wi : q.cx + wo);
      int dx = a0 - q.cx, d2 = dx * dx + dy2;
      for (int x = a0; x <= a1; x++, d2 += 2 * dx + 1, dx++) {
        float c = clamp01(.5f - ((float)d2 - o2) * ko);
        if (ki > 0) c *= clamp01(.5f + ((float)d2 - i2) * ki);
        int a = (int)(alpha * c);
        if (ey >= 0) {
          const int ex = x < cr ? x : x >= q.w - cr ? q.w - 1 - x : -1;
          if (ex >= 0) a = a * q.corner[ey * cr + ex] / 255;
        }
        if (a > 0) row[x] = (uint8_t)(row[x] + a - row[x] * a / 255);
      }
    }
  }
}

void dropStep(void* var, int32_t v) {
  lv_obj_t* img = (lv_obj_t*)var;
  Drop& q = *(Drop*)lv_obj_get_user_data(img);
  const float ms = (float)v * DROP_MS / P;
  memset(q.buf->data, 0, (size_t)q.buf->header.stride * q.h);
  for (int i = 0; i < 3; i++) {
    const float t = clamp01((ms - i * DROP_GAP_MS) / DROP_RING_MS);
    const float a = t < .08f ? t / .08f : 1 - (t - .08f) / .92f;
    const float out = q.size * easeOut(t) / 2;
    dropShape(q, out, out - (i < 2 ? 2 : 1), (int)(180 * a));
  }
  const float t = clamp01(ms / SPLASH_MS);
  dropShape(q, 12 * (.2f + 1.6f * t) / 2, 0, (int)(220 * (1 - t)));
  lv_obj_invalidate(img);
}

void touchRing(TileRt& r, lv_point_t p, int rad) {
  lv_area_t cc;
  lv_obj_get_content_coords(r.obj, &cc);
  lv_obj_t* o = r.fx = circle(r.obj, p.x - cc.x1, p.y - cc.y1, rad);
  lv_obj_set_style_border_width(o, 2, 0);
  lv_obj_set_style_border_color(o, lv_obj_get_style_text_color(r.obj, LV_PART_MAIN), 0);
  startAnim(o, rippleStep, RIPPLE_MS, lv_anim_path_ease_out, touchDone);
}

void touchDrop(TileRt& r, lv_point_t p, int rad) {
  lv_area_t tc, cc;
  lv_obj_get_coords(r.obj, &tc);
  lv_obj_get_content_coords(r.obj, &cc);
  Drop* q = new Drop();
  q->w = (int16_t)lv_area_get_width(&tc);
  q->h = (int16_t)lv_area_get_height(&tc);
  q->cx = (int16_t)(p.x - tc.x1);
  q->cy = (int16_t)(p.y - tc.y1);
  q->size = rad * 1.7f;
  q->cr = (int16_t)LV_MIN(lv_obj_get_style_radius(r.obj, LV_PART_MAIN), LV_MIN(q->w, q->h) / 2);
  q->buf = lv_draw_buf_create(q->w, q->h, LV_COLOR_FORMAT_A8, 0);
  q->corner = q->cr > 0 ? (uint8_t*)heap_caps_malloc((size_t)q->cr * q->cr, MALLOC_CAP_SPIRAM) : nullptr;
  if (!q->buf || (q->cr > 0 && !q->corner)) {
    dropFree(q);
    return;
  }
  for (int y = 0; y < q->cr; y++)
    for (int x = 0; x < q->cr; x++) {
      const float dx = q->cr - x - .5f, dy = q->cr - y - .5f;
      q->corner[y * q->cr + x] = (uint8_t)(255 * clamp01(q->cr + .5f - sqrtf(dx * dx + dy * dy)));
    }
  lv_obj_t* img = r.fx = lv_image_create(r.obj);
  lv_obj_add_flag(img, (lv_obj_flag_t)(LV_OBJ_FLAG_IGNORE_LAYOUT | LV_OBJ_FLAG_FLOATING));
  lv_obj_remove_flag(img, LV_OBJ_FLAG_CLICKABLE);
  lv_obj_set_user_data(img, q);
  lv_obj_add_event_cb(img, dropDelete, LV_EVENT_DELETE, q);
  lv_obj_set_pos(img, tc.x1 - cc.x1, tc.y1 - cc.y1);
  lv_obj_set_style_image_recolor(img, s_theme == THEME_DAYLIGHT ? lv_obj_get_style_text_color(r.obj, LV_PART_MAIN)
                                                                : lv_color_hex(0xDCF5FF), 0);
  dropStep(img, 0);
  lv_image_set_src(img, q->buf);
  startAnim(img, dropStep, DROP_MS, lv_anim_path_linear, touchDone);
}

// --- On/off: pop and halo (Calm) -----------------------------------------------------------
void popStep(void* var, int32_t v) {  // 1 -> 1.3 -> 0.92 -> 1
  const float t = (float)v / P;
  const float s = t < .35f ? 1 + .3f * smooth(t / .35f)
                : t < .7f  ? 1.3f - .38f * smooth((t - .35f) / .35f)
                           : .92f + .08f * smooth((t - .7f) / .3f);
  lv_obj_set_style_transform_scale((lv_obj_t*)var, (int32_t)(256 * s), 0);
}

void squishStep(void* var, int32_t v) {  // 1 -> 0.86 -> 1
  const float t = (float)v / P;
  const float s = t < .4f ? 1 - .14f * smooth(t / .4f) : .86f + .14f * smooth((t - .4f) / .6f);
  lv_obj_set_style_transform_scale((lv_obj_t*)var, (int32_t)(256 * s), 0);
}

void haloStep(void* var, int32_t v) {
  lv_obj_t* o = (lv_obj_t*)var;
  int cx, cy, d;
  unpack(lv_obj_get_user_data(o), cx, cy, d);
  const float t = (float)v / P;
  const float s = t < .3f ? .3f + .7f * smooth(t / .3f) : 1 + .6f * smooth((t - .3f) / .7f);
  const float a = t < .3f ? smooth(t / .3f) : 1 - smooth((t - .3f) / .7f);
  placeCircle(o, cx, cy, LV_MAX(2, (int)(d * s)));
  lv_obj_set_style_bg_opa(o, (lv_opa_t)(110 * a), 0);
}

void haloDone(lv_anim_t* a) {
  lv_obj_t* box = lv_obj_get_parent((lv_obj_t*)a->var);
  if (TileRt* r = tileOf(lv_obj_get_parent(box)))
    if (r->halo == box) r->halo = nullptr;
  lv_obj_delete_async(box);
}

void scaleAround(lv_obj_t* o, lv_anim_exec_xcb_t step, uint32_t ms) {
  lv_anim_delete(o, popStep);
  lv_anim_delete(o, squishStep);
  lv_obj_update_layout(o);
  lv_obj_set_style_transform_pivot_x(o, lv_obj_get_width(o) / 2, 0);
  lv_obj_set_style_transform_pivot_y(o, lv_obj_get_height(o) / 2, 0);
  startAnim(o, step, ms, lv_anim_path_linear, nullptr);
}

void toggleBloom(TileRt& r, bool on) {
  lv_obj_t* ic = r.chip ? r.chip : r.icon;
  if (ic) scaleAround(ic, on ? popStep : squishStep, on ? POP_MS : SQUISH_MS);
  if (!on || !ic || r.halo) return;
  lv_area_t a, tc;
  lv_obj_get_coords(ic, &a);
  lv_obj_get_coords(r.obj, &tc);
  const int d = LV_MIN(lv_obj_get_height(r.obj), lv_obj_get_width(r.obj)) * 4 / 5;
  lv_obj_t* box = r.halo = tileBox(r);
  lv_obj_t* h = circle(box, (a.x1 + a.x2) / 2 - tc.x1, (a.y1 + a.y2) / 2 - tc.y1, d);
  lv_obj_set_style_bg_color(h, lv_color_white(), 0);
  startAnim(h, haloStep, HALO_MS, lv_anim_path_linear, haloDone);
}

// --- On/off: liquid fill (Water) ------------------------------------------------------------
// The on colour grows from the finger in a circle under the tile's content
// (or drains back into it). Meanwhile the tile's "on" fill and the new text
// colour are held back: their local styles are saved and put back as found.
struct Held {
  lv_style_prop_t prop;
  lv_style_selector_t sel;
  lv_style_value_t v;
  bool had, used;
};
// What an on/off effect held back on its tile (liquid, sheen).
struct OnOff {
  Held fill, pressedFill, edge, text;  // the new fill (also pressed) and outline, the text's new colour
  bool on;
  lv_style_value_t from, to;  // sheen: the fill fades between these
  bool color;                 // ... as colours, else as opacities
};

Held hold(lv_obj_t* o, lv_style_prop_t prop, lv_style_selector_t sel, lv_style_value_t to) {
  Held h = {prop, sel, {}, false, true};
  h.had = lv_obj_get_local_style_prop(o, prop, &h.v, sel) == LV_STYLE_RES_FOUND;
  lv_obj_set_local_style_prop(o, prop, to, sel);
  return h;
}

void putBack(lv_obj_t* o, Held& h) {
  if (!h.used) return;
  if (h.had) lv_obj_set_local_style_prop(o, h.prop, h.v, h.sel);
  else lv_obj_remove_local_style_prop(o, h.prop, h.sel);
  h.used = false;
}

void onOffDelete(lv_event_t* e) { delete (OnOff*)lv_event_get_user_data(e); }

OnOff* onOffOf(lv_obj_t* box) { return (OnOff*)lv_obj_get_user_data(box); }

// Ends the running on/off effect at once: the tile shows its state as it is.
void onOffStop(TileRt& r) {
  if (!r.halo) return;
  if (OnOff* q = onOffOf(r.halo)) {
    putBack(r.obj, q->fill);
    putBack(r.obj, q->pressedFill);
    putBack(r.obj, q->edge);
    putBack(r.obj, q->text);
  }
  lv_obj_delete(r.halo);  // its animation goes with it
  r.halo = nullptr;
}

// Box children: the fill, the ring on its edge.
void liquidStep(void* var, int32_t v) {
  lv_obj_t* box = (lv_obj_t*)var;
  OnOff* q = onOffOf(box);
  TileRt* r = tileOf(lv_obj_get_parent(box));
  if (!q || !r) return;
  const float t = (float)v / P;
  lv_obj_t* fill = lv_obj_get_child(box, 0);
  lv_obj_t* ring = lv_obj_get_child(box, 1);
  int cx, cy, rad;
  unpack(lv_obj_get_user_data(fill), cx, cy, rad);
  const int d = LV_MAX(2, (int)(2 * rad * (q->on ? easeOut(t) : 1 - t * t * t)));
  placeCircle(fill, cx, cy, d);
  placeCircle(ring, cx, cy, d);
  lv_obj_set_style_border_opa(ring, (lv_opa_t)(q->on ? 190 * (1 - t) : 170 * t), 0);
  // The text turns over part way, as the fill passes under it.
  if (t >= (q->on ? .37f : .6f)) putBack(r->obj, q->text);
}

void liquidDone(lv_anim_t* a) {
  lv_obj_t* box = (lv_obj_t*)a->var;
  TileRt* r = tileOf(lv_obj_get_parent(box));
  if (r && r->halo == box) onOffStop(*r);  // the tile's own fill takes over in the same frame
}

// Before the tile changes state: hold back what the change would show at once.
void startLiquid(TileRt& r, bool on) {
  onOffStop(r);
  const bool glass = s_theme == THEME_GLASS && wallBlur();
  OnOff* q = new OnOff();
  q->on = on;
  // Still in the old state, so the current values are the ones to keep.
  // Turning on: the CHECKED fill (bg_opa on Glass, bg_color else) waits for
  // the circle. Both ways: the text keeps its colour until part way.
  lv_style_value_t v;
  if (on) {
    if (glass) v.num = LV_OPA_TRANSP;
    else v.color = lv_obj_get_style_bg_color(r.obj, LV_PART_MAIN);
    const lv_style_prop_t prop = glass ? LV_STYLE_BG_OPA : LV_STYLE_BG_COLOR;
    q->fill = hold(r.obj, prop, LV_STATE_CHECKED, v);
    q->pressedFill = hold(r.obj, prop, LV_STATE_PRESSED | LV_STATE_CHECKED, v);  // a slider dragged on
    // Glass tiles with a faint fill also get an outline when on.
    if (lv_obj_get_local_style_prop(r.obj, LV_STYLE_BORDER_WIDTH, &v, LV_STATE_CHECKED) == LV_STYLE_RES_FOUND) {
      v.num = 0;
      q->edge = hold(r.obj, LV_STYLE_BORDER_WIDTH, LV_STATE_CHECKED, v);
    }
  }
  v.color = lv_obj_get_style_text_color(r.obj, LV_PART_MAIN);
  q->text = hold(r.obj, LV_STYLE_TEXT_COLOR, on ? LV_STATE_CHECKED : LV_STATE_DEFAULT, v);

  lv_area_t tc;
  lv_obj_get_coords(r.obj, &tc);
  const lv_point_t p = touchPoint(r);
  const int rad = farCorner(tc, p);
  lv_obj_t* box = r.halo = tileBox(r);
  lv_obj_move_to_index(box, 0);  // under the tile's content
  lv_obj_set_user_data(box, q);
  lv_obj_add_event_cb(box, onOffDelete, LV_EVENT_DELETE, q);
  const TileDef& d = *r.def;
  lv_obj_t* fill = circle(box, p.x - tc.x1, p.y - tc.y1, rad);
  lv_obj_set_style_bg_color(fill, lv_color_hex(tileOnFill(d)), 0);
  lv_obj_set_style_bg_opa(fill, glass ? (lv_opa_t)(tileOnOpa(d) * 255 / 100) : LV_OPA_COVER, 0);
  lv_obj_t* ring = circle(box, p.x - tc.x1, p.y - tc.y1, rad);
  lv_obj_set_style_border_width(ring, 2, 0);
  lv_obj_set_style_border_color(ring, lv_color_white(), 0);
  lv_obj_set_style_border_opa(ring, LV_OPA_TRANSP, 0);
  startAnim(box, liquidStep, on ? LIQUID_ON_MS : LIQUID_OFF_MS, lv_anim_path_linear, liquidDone);
}

// --- Glass: light images ---------------------------------------------------------------------
// White with alpha, made once (radial gradients are off in lv_conf): a round
// highlight for the press, a slanted glossy band for the sheen.
constexpr int SPOT = 128, BAND_W = 120, BAND_H = 200;

lv_draw_buf_t* lightImage(lv_draw_buf_t*& buf, int w, int h, uint8_t (*alpha)(float x, float y)) {
  if (buf) return buf;
  buf = lv_draw_buf_create(w, h, LV_COLOR_FORMAT_ARGB8888, 0);
  if (!buf) return nullptr;
  for (int y = 0; y < h; y++) {
    uint32_t* row = (uint32_t*)(buf->data + y * buf->header.stride);
    for (int x = 0; x < w; x++) row[x] = (uint32_t)alpha((x + .5f) / w, (y + .5f) / h) << 24 | 0xFFFFFF;
  }
  return buf;
}

uint8_t spotAlpha(float x, float y) {
  const float r = sqrtf((2 * x - 1) * (2 * x - 1) + (2 * y - 1) * (2 * y - 1));
  return (uint8_t)(107 * smooth(clamp01(1 - r)));
}

// A soft band 48 px wide, leaning 18 degrees.
uint8_t bandAlpha(float x, float y) {
  const float u = x * BAND_W - (1 - y) * BAND_H * .325f - 24;
  return (uint8_t)(153 * smooth(clamp01(1 - fabsf(u) / 24)));
}

lv_draw_buf_t* s_spot = nullptr;
lv_draw_buf_t* s_band = nullptr;

// --- Touch: glass press (Glass) ---------------------------------------------------------------
// r.fx is a box with the highlight at the finger, faded in while pressed,
// out after the release; the tile springs back with a small overshoot.
constexpr uint32_t PRESS_IN_MS = 130, PRESS_OUT_MS = 360, SPRING_MS = 480;

void spotIn(void* var, int32_t v) {
  lv_obj_set_style_image_opa(lv_obj_get_child((lv_obj_t*)var, 0), (lv_opa_t)(255 * v / P), 0);
}

void spotOut(void* var, int32_t v) {
  lv_obj_set_style_image_opa(lv_obj_get_child((lv_obj_t*)var, 0), (lv_opa_t)(255 * (P - v) / P), 0);
}

void springStep(void* var, int32_t v) {  // 0 -> +3 px -> -1 -> 0
  const float t = (float)v / P;
  const float s = t < .45f ? 3 * smooth(t / .45f) : t < .75f ? 3 - 4 * smooth((t - .45f) / .3f) : -1 + smooth((t - .75f) / .25f);
  lv_obj_set_style_transform_width((lv_obj_t*)var, (int32_t)lroundf(s), 0);
  lv_obj_set_style_transform_height((lv_obj_t*)var, (int32_t)lroundf(s), 0);
}

void springReset(lv_obj_t* t) {
  lv_obj_remove_local_style_prop(t, LV_STYLE_TRANSFORM_WIDTH, 0);
  lv_obj_remove_local_style_prop(t, LV_STYLE_TRANSFORM_HEIGHT, 0);
}

void springDone(lv_anim_t* a) { springReset((lv_obj_t*)a->var); }

void touchPress(TileRt& r, lv_point_t p) {
  if (!lightImage(s_spot, SPOT, SPOT, spotAlpha)) return;
  lv_area_t tc;
  lv_obj_get_coords(r.obj, &tc);
  lv_obj_t* box = r.fx = tileBox(r);
  lv_obj_t* img = lv_image_create(box);
  lv_obj_remove_flag(img, LV_OBJ_FLAG_CLICKABLE);
  lv_image_set_src(img, s_spot);
  lv_obj_set_pos(img, p.x - tc.x1 - SPOT / 2, p.y - tc.y1 - SPOT / 2);
  lv_obj_set_style_image_opa(img, LV_OPA_TRANSP, 0);
  startAnim(box, spotIn, PRESS_IN_MS, lv_anim_path_ease_out, nullptr);
}

void pressRelease(TileRt& r) {
  lv_anim_delete(r.obj, springStep);
  startAnim(r.obj, springStep, SPRING_MS, lv_anim_path_linear, springDone);
  if (!r.fx || lv_anim_get(r.fx, spotOut)) return;
  lv_anim_delete(r.fx, spotIn);
  startAnim(r.fx, spotOut, PRESS_OUT_MS, lv_anim_path_ease_out, touchDone);
}

// --- On/off: glass sheen (Glass) -----------------------------------------------------------
// The fill fades in (or out) instead of switching, and a glossy band sweeps
// across the tile once. Box children: the band.
constexpr uint32_t SHEEN_FILL_MS = 280, SHEEN_ON_MS = 700, SHEEN_OFF_MS = 500;

void sheenStep(void* var, int32_t v) {
  lv_obj_t* box = (lv_obj_t*)var;
  OnOff* q = onOffOf(box);
  TileRt* r = tileOf(lv_obj_get_parent(box));
  if (!q || !r) return;
  const uint32_t ms = (q->on ? SHEEN_ON_MS : SHEEN_OFF_MS) * v / P;
  const float k = clamp01((float)ms / SHEEN_FILL_MS);
  if (k < 1 || ms < SHEEN_FILL_MS + 40) {
    lv_style_value_t c;
    if (q->color) c.color = lv_color_mix(q->to.color, q->from.color, (uint8_t)(255 * k));
    else c.num = q->from.num + (int32_t)lroundf((q->to.num - q->from.num) * k);
    lv_obj_set_local_style_prop(r->obj, q->fill.prop, c, q->fill.sel);
    lv_obj_set_local_style_prop(r->obj, q->pressedFill.prop, c, q->pressedFill.sel);
  }
  // The band crosses from one side to the other, slow at both ends.
  const float t = smooth((float)v / P);
  const int w = lv_obj_get_width(box), x0 = q->on ? -BAND_W : w, x1 = q->on ? w : -BAND_W;
  lv_obj_set_x(lv_obj_get_child(box, 0), x0 + (int)lroundf((x1 - x0) * t));
}

void sheenDone(lv_anim_t* a) {
  lv_obj_t* box = (lv_obj_t*)a->var;
  TileRt* r = tileOf(lv_obj_get_parent(box));
  if (r && r->halo == box) onOffStop(*r);
}

// Before the tile changes state, like the liquid.
void startSheen(TileRt& r, bool on) {
  onOffStop(r);
  if (!lightImage(s_band, BAND_W, BAND_H, bandAlpha)) return;
  const bool glass = s_theme == THEME_GLASS && wallBlur();
  const lv_style_prop_t prop = glass ? LV_STYLE_BG_OPA : LV_STYLE_BG_COLOR;
  OnOff* q = new OnOff();
  q->on = on;
  q->color = !glass;
  // From what the tile shows now to the new state's own value.
  q->from = lv_obj_get_style_prop(r.obj, LV_PART_MAIN, prop);
  const lv_style_selector_t sel = on ? LV_STATE_CHECKED : LV_STATE_DEFAULT;
  if (lv_obj_get_local_style_prop(r.obj, prop, &q->to, sel) != LV_STYLE_RES_FOUND) q->to = q->from;
  q->fill = hold(r.obj, prop, sel, q->from);
  q->pressedFill = hold(r.obj, prop, sel | LV_STATE_PRESSED, q->from);
  lv_obj_t* box = r.halo = tileBox(r);
  lv_obj_set_user_data(box, q);
  lv_obj_add_event_cb(box, onOffDelete, LV_EVENT_DELETE, q);
  lv_obj_t* band = lv_image_create(box);
  lv_obj_remove_flag(band, LV_OBJ_FLAG_CLICKABLE);
  lv_image_set_src(band, s_band);
  lv_obj_set_pos(band, on ? -BAND_W : lv_obj_get_width(r.obj), (lv_obj_get_height(r.obj) - BAND_H) / 2);
  lv_obj_set_style_image_opa(band, on ? LV_OPA_COVER : (lv_opa_t)107, 0);
  startAnim(box, sheenStep, on ? SHEEN_ON_MS : SHEEN_OFF_MS, lv_anim_path_linear, sheenDone);
}

// --- On/off: aurora (Heavy) --------------------------------------------------------------
// For 2 s after turning on, the fill drifts through aurora colours (a
// horizontal gradient), then settles on the on colour. Only then: an
// always moving fill would keep the deck from ever going idle.
constexpr uint32_t AURORA_MS = 2000;
constexpr uint32_t kAurora[] = {0x2DD4BF, 0x4ADE80, 0xA78BFA, 0x60A5FA};

lv_color_t auroraAt(float u) {
  u = (u - floorf(u)) * 4;
  const int i = (int)u;
  return lv_color_mix(lv_color_hex(kAurora[(i + 1) % 4]), lv_color_hex(kAurora[i % 4]), (uint8_t)(255 * (u - i)));
}

// OnOff slots here: fill = CHECKED bg_color, pressedFill = its gradient colour, edge = the gradient direction.
void auroraStep(void* var, int32_t v) {
  lv_obj_t* box = (lv_obj_t*)var;
  OnOff* q = onOffOf(box);
  TileRt* r = tileOf(lv_obj_get_parent(box));
  if (!q || !r) return;
  const float t = (float)v / P, keep = 1 - smooth(clamp01((t - .75f) / .25f));
  lv_style_value_t c;
  c.color = lv_color_mix(auroraAt(t * 1.5f), q->to.color, (uint8_t)(255 * keep));
  lv_obj_set_local_style_prop(r->obj, LV_STYLE_BG_COLOR, c, LV_STATE_CHECKED);
  c.color = lv_color_mix(auroraAt(t * 1.5f + .35f), q->to.color, (uint8_t)(255 * keep));
  lv_obj_set_local_style_prop(r->obj, LV_STYLE_BG_GRAD_COLOR, c, LV_STATE_CHECKED);
}

void startAurora(TileRt& r, bool on) {
  onOffStop(r);
  if (!on) return;
  OnOff* q = new OnOff();
  q->on = true;
  q->color = true;
  if (lv_obj_get_local_style_prop(r.obj, LV_STYLE_BG_COLOR, &q->to, LV_STATE_CHECKED) != LV_STYLE_RES_FOUND)
    q->to.color = lv_color_hex(tileOnFill(*r.def));
  lv_style_value_t v;
  v.color = auroraAt(0);
  q->fill = hold(r.obj, LV_STYLE_BG_COLOR, LV_STATE_CHECKED, v);
  v.color = auroraAt(.35f);
  q->pressedFill = hold(r.obj, LV_STYLE_BG_GRAD_COLOR, LV_STATE_CHECKED, v);
  v.num = LV_GRAD_DIR_HOR;
  q->edge = hold(r.obj, LV_STYLE_BG_GRAD_DIR, LV_STATE_CHECKED, v);
  lv_obj_t* box = r.halo = tileBox(r);  // carries the animation and the record
  lv_obj_set_user_data(box, q);
  lv_obj_add_event_cb(box, onOffDelete, LV_EVENT_DELETE, q);
  startAnim(box, auroraStep, AURORA_MS, lv_anim_path_linear, sheenDone);
}

// --- Touch: water distortion (Heavy) ------------------------------------------------------
// The tile as last shown (wallpaper and glass included) bends in rings from
// the finger and settles. Per pixel: the distance and direction from the
// finger, worked out once; per frame: the offset for each distance.
constexpr uint32_t DISTORT_MS = 900;

struct Distort {
  uint16_t* src;    // the tile as shown, w x h
  uint16_t* dist;   // per pixel: distance from the finger
  int8_t* dir;      // per pixel: unit direction (x, y), x127
  int16_t* lut;     // per distance: offset along the direction, px x16
  int w, h, maxd;
  int x0, y0;       // where src sits on the screen
  int retake;       // steps until src is taken again from a frame without the effect
  lv_draw_buf_t* out;
};

void distortTake(Distort* q) {
  const uint16_t* fb = lastFrame();
  const int sw = logicalW();
  for (int y = 0; y < q->h; y++) memcpy(q->src + y * q->w, fb + (q->y0 + y) * sw + q->x0, (size_t)q->w * 2);
}

void distortFree(Distort* q) {
  heap_caps_free(q->src);
  heap_caps_free(q->dist);
  heap_caps_free(q->dir);
  heap_caps_free(q->lut);
  if (q->out) lv_draw_buf_destroy(q->out);
  delete q;
}

void distortDelete(lv_event_t* e) { distortFree((Distort*)lv_event_get_user_data(e)); }

void distortStep(void* var, int32_t v) {
  lv_obj_t* box = (lv_obj_t*)var;
  Distort* q = (Distort*)lv_obj_get_user_data(box);
  if (!q) return;
  // The tile changed under the effect: it was hidden for a frame, now it is
  // drawn in its new look and taken again.
  if (q->retake && --q->retake) return;
  if (lv_obj_has_flag(box, LV_OBJ_FLAG_HIDDEN)) {
    distortTake(q);
    lv_obj_remove_flag(box, LV_OBJ_FLAG_HIDDEN);
  }
  const float t = (float)v / P, amp = 16 * 5 * (1 - t) * (1 - t);  // in 1/16 px
  for (int d = 0; d <= q->maxd; d++)
    q->lut[d] = (int16_t)(amp * sinf(d * .16f - t * 22) * expf(-d / 70.0f));
  const int w = q->w, h = q->h;
  const uint32_t stride = q->out->header.stride / 2;
  for (int y = 0; y < h; y++) {
    uint16_t* o = (uint16_t*)q->out->data + y * stride;
    for (int x = 0; x < w; x++) {
      const int i = y * w + x, off = q->lut[q->dist[i]];
      const int sx = constrain(x - (q->dir[2 * i] * off >> 11), 0, w - 1);
      const int sy = constrain(y - (q->dir[2 * i + 1] * off >> 11), 0, h - 1);
      o[x] = q->src[sy * w + sx];
    }
  }
  lv_obj_invalidate(lv_obj_get_child(box, 0));
}

struct DistortSetup {
  Distort* q;
  int fx, fy;  // the finger, in src coords
};

// Distance and direction from the finger for rows lo..hi (both cores).
void distortRows(void* ctx, int lo, int hi) {
  const DistortSetup& s = *(const DistortSetup*)ctx;
  Distort* q = s.q;
  const int w = q->w, h = q->h;
  for (int y = lo; y < hi; y++)
    for (int x = 0; x < w; x++) {
      const int i = y * w + x, dx = x - s.fx, dy = y - s.fy;
      const float d = sqrtf((float)(dx * dx + dy * dy));
      // Still at the edges, so the tile's outline stays where it is.
      const float k = d > 0 ? 127 * clamp01((float)LV_MIN(LV_MIN(x, w - 1 - x), LV_MIN(y, h - 1 - y)) / 10) / d : 0;
      q->dist[i] = (uint16_t)d;
      q->dir[2 * i] = (int8_t)(dx * k);
      q->dir[2 * i + 1] = (int8_t)(dy * k);
    }
}

void touchDistort(TileRt& r, lv_point_t p) {
  lv_area_t tc;
  lv_obj_get_coords(r.obj, &tc);
  const int sw = logicalW(), sh2 = logicalH();
  const int x0 = LV_MAX(0, tc.x1), y0 = LV_MAX(0, tc.y1);
  const int w = LV_MIN(sw, tc.x2 + 1) - x0, h = LV_MIN(sh2, tc.y2 + 1) - y0;
  if (w <= 0 || h <= 0) return;
  Distort* q = new Distort();
  q->w = w;
  q->h = h;
  q->maxd = (int)sqrtf((float)(w * w + h * h)) + 1;
  q->src = (uint16_t*)heap_caps_malloc((size_t)w * h * 2, MALLOC_CAP_SPIRAM);
  q->dist = (uint16_t*)heap_caps_malloc((size_t)w * h * 2, MALLOC_CAP_SPIRAM);
  q->dir = (int8_t*)heap_caps_malloc((size_t)w * h * 2, MALLOC_CAP_SPIRAM);
  q->lut = (int16_t*)heap_caps_malloc((size_t)(q->maxd + 1) * 2, MALLOC_CAP_SPIRAM);
  q->out = lv_draw_buf_create(w, h, LV_COLOR_FORMAT_RGB565, 0);
  if (!q->src || !q->dist || !q->dir || !q->lut || !q->out) {
    distortFree(q);
    return;
  }
  q->x0 = x0;
  q->y0 = y0;
  distortTake(q);
  DistortSetup ds = {q, p.x - x0, p.y - y0};
  panelShare(distortRows, &ds, h, 16);
  lv_obj_t* box = r.fx = tileBox(r);
  lv_obj_set_user_data(box, q);
  lv_obj_add_event_cb(box, distortDelete, LV_EVENT_DELETE, q);
  // src holds the corners as shown and the edges stay still: no clip needed,
  // and an opaque image lets LVGL skip the tile under it.
  lv_obj_set_style_clip_corner(box, false, 0);
  lv_obj_set_style_radius(box, 0, 0);
  lv_obj_t* img = lv_image_create(box);
  lv_obj_set_style_bg_opa(img, LV_OPA_COVER, 0);
  lv_obj_remove_flag(img, LV_OBJ_FLAG_CLICKABLE);
  lv_obj_set_pos(img, x0 - tc.x1, y0 - tc.y1);
  lv_image_set_src(img, q->out);
  distortStep(box, 0);
  startAnim(box, distortStep, DISTORT_MS, lv_anim_path_linear, touchDone);
}

// Only changes the user can see: not while pages are built, not under the
// card or the photo frame, not on pages off screen.
bool live(const TileRt& r) {
  return (int32_t)(millis() - s_quietUntil) >= 0 && r.page == sh.active && !frameActive() && !modalShown() &&
         lv_obj_is_visible(r.obj);
}

// --- Cards: morph (Calm) and reveal (Water) ------------------------------------------------
FrameRect rectOf(lv_obj_t* o) {
  lv_area_t a;
  lv_obj_get_coords(o, &a);
  return {(int16_t)a.x1, (int16_t)a.y1, (int16_t)lv_area_get_width(&a), (int16_t)lv_area_get_height(&a)};
}

// The screen sized buffer for the card's picture. A snapshot reshapes it to
// the card, so its room is data_size, not the header.
bool cardPicBuf() {
  const uint32_t w = logicalW(), h = logicalH();
  if (s_cardPic && s_cardPic->data_size < w * h * 2) {
    lv_draw_buf_destroy(s_cardPic);
    s_cardPic = nullptr;
  }
  if (!s_cardPic) s_cardPic = lv_draw_buf_create(w, h, LV_COLOR_FORMAT_RGB565, 0);
  return s_cardPic != nullptr;
}

// The card's picture for the compositor. Only while no morph reads the buffer.
bool snapCard(lv_obj_t* card) {
  if (compMode() != COMP_NONE && !compMorphWaiting()) return false;
  if (!cardPicBuf()) return false;
  lv_obj_update_layout(card);
  if (!lv_snapshot_reshape_draw_buf(card, s_cardPic)) return false;
  return lv_snapshot_take_to_draw_buf(card, LV_COLOR_FORMAT_RGB565, s_cardPic) == LV_RESULT_OK;
}

Src cardPic() { return {(const uint16_t*)s_cardPic->data, (uint16_t)(s_cardPic->header.stride / 2), true}; }

MorphScene cardScene(lv_obj_t* card) {
  MorphScene m = {};
  m.card = cardPic();
  m.cw = (int16_t)lv_obj_get_width(card);
  m.ch = (int16_t)lv_obj_get_height(card);
  m.ghost = lv_color_to_u16(lv_color_hex(C_PANEL));
  return m;
}

lv_obj_t* visibleTile(int tileIdx) {
  if (tileIdx < 0 || tileIdx >= (int)s_tiles.size()) return nullptr;
  lv_obj_t* t = s_tiles[tileIdx].obj;
  return lv_obj_is_visible(t) ? t : nullptr;
}

}  // namespace

PageFx fxPage() { return fx().page; }

void fxQuiet() { s_quietUntil = millis() + 800; }

void fxPressed(lv_event_t* e) {
  TileRt* r = tileOf((lv_obj_t*)lv_event_get_current_target(e));
  lv_indev_t* in = lv_indev_active();
  if (!r || !in) return;
  if (lv_event_get_code(e) != LV_EVENT_PRESSED) {  // released or lost
    if (fx().touch == TOUCH_PRESS) pressRelease(*r);
    return;
  }
  lv_point_t p;
  lv_indev_get_point(in, &p);
  r->press = p;
  r->pressMs = millis();
  fxRipple(*r, p);
}

void fxRipple(TileRt& r, lv_point_t p) {
  const FxTouch t = fx().touch;
  if (t == TOUCH_NONE) return;
  lv_area_t tc;
  lv_obj_get_coords(r.obj, &tc);
  if (r.fx) lv_obj_delete(r.fx);
  r.fx = nullptr;
  if (t == TOUCH_DROP) touchDrop(r, p, farCorner(tc, p));
  else if (t == TOUCH_PRESS) touchPress(r, p);
  else if (t == TOUCH_DISTORT) touchDistort(r, p);
  else touchRing(r, p, farCorner(tc, p));
}

bool fxCancelRipples() {
  bool any = false;
  for (TileRt& r : s_tiles) {
    if (lv_anim_delete(r.obj, springStep)) {
      springReset(r.obj);
      any = true;
    }
    if (!r.fx) continue;
    lv_obj_delete(r.fx);
    r.fx = nullptr;
    any = true;
  }
  return any;
}

void fxBeforeTileOn(TileRt& r, bool on) {
  const FxToggle t = fx().toggle;
  if (t != TOGGLE_LIQUID && t != TOGGLE_SHEEN && t != TOGGLE_AURORA) {
    if (r.halo && onOffOf(r.halo)) onOffStop(r);  // started under an earlier preset
    return;
  }
  if (!live(r)) onOffStop(r);
  else if (t == TOGGLE_SHEEN) startSheen(r, on);
  else if (t == TOGGLE_AURORA) startAurora(r, on);
  else startLiquid(r, on);
}

void fxTileOn(TileRt& r, bool wasOn) {
  const bool on = lv_obj_has_state(r.obj, LV_STATE_CHECKED);
  if (wasOn != on && r.fx && lv_anim_get(r.fx, distortStep)) {
    lv_obj_add_flag(r.fx, LV_OBJ_FLAG_HIDDEN);
    ((Distort*)lv_obj_get_user_data(r.fx))->retake = 2;
  }
  if (fx().toggle == TOGGLE_BLOOM && wasOn != on && live(r)) toggleBloom(r, on);
}

// Calm: the compositor flies the card picture out of the tile over the
// dimmed page. Water: it reveals the card in a circle from the finger. Glass:
// the card rises as a sheet. Then LVGL's frame with the real card takes over.
// card: its picture is in s_cardPic, false when it comes later.
bool beginOpen(lv_obj_t* t, FrameRect to, int r1, bool card) {
  const FxCard kind = s_openFx;
  MorphScene m = {};
  if (card) m.card = cardPic();
  m.cw = to.w;
  m.ch = to.h;
  m.ghost = lv_color_to_u16(lv_color_hex(C_PANEL));
  m.from = rectOf(t);
  m.to = to;
  m.r0 = (int16_t)lv_obj_get_style_radius(t, LV_PART_MAIN);
  m.r1 = (int16_t)r1;
  m.dim = 2;  // the scrim fades in with the card
  m.open = true;
  if (kind == CARD_REVEAL) {
    m.reveal = true;
    m.cx = (int16_t)s_revealAt.x;
    m.cy = (int16_t)s_revealAt.y;
  }
  m.sheet = kind == CARD_SHEET;
  return compBeginMorph(m, kind == CARD_REVEAL ? REVEAL_MS : kind == CARD_SHEET ? SHEET_MS : MORPH_MS, ++s_gen);
}

// Only with no card open and the compositor idle; the next card allocates it again.
void fxCardPicFree() {
  if (s_cardPic) lv_draw_buf_destroy(s_cardPic);
  s_cardPic = nullptr;
}

// Before the card is built, so the tap is answered at once: the scrim fades
// in while openModal works. to: where the card will be, r1: its corner radius.
void fxCardOpenBegin(int tileIdx, FrameRect to, int r1) {
  const FxCard kind = s_openFx = fx().card;
  if (tileIdx >= 0 && tileIdx < (int)s_tiles.size()) s_revealAt = touchPoint(s_tiles[tileIdx]);
  lv_obj_t* t = kind != CARD_NONE ? visibleTile(tileIdx) : nullptr;
  // Without room for the picture the card opens plainly.
  if (t && compMode() == COMP_NONE && cardPicBuf()) beginOpen(t, to, r1, false);
}

// The card is built: its picture starts the animation begun above, or the
// whole animation when the compositor was busy then.
void fxCardOpen(lv_obj_t* card, int tileIdx) {
  if (compMorphWaiting()) {
    if (snapCard(card)) compMorphCard(cardPic());
    else compCancel();
    return;
  }
  lv_obj_t* t = s_openFx != CARD_NONE ? visibleTile(tileIdx) : nullptr;
  if (t && snapCard(card)) beginOpen(t, rectOf(card), lv_obj_get_style_radius(card, LV_PART_MAIN), true);
}

void fxCardClose(lv_obj_t* card, int tileIdx) {
  const FxCard kind = s_openFx;
  lv_obj_t* t = kind != CARD_NONE && card ? visibleTile(tileIdx) : nullptr;
  const bool morph = t && snapCard(card) && snapPage(sh.active);
  MorphScene m = {};
  if (morph) {
    m = cardScene(card);
    m.base = sh.src[sh.active];
    m.from = rectOf(card);
    m.to = rectOf(t);
    m.r0 = (int16_t)lv_obj_get_style_radius(card, LV_PART_MAIN);
    m.r1 = (int16_t)lv_obj_get_style_radius(t, LV_PART_MAIN);
    m.dim = 2;  // the scrim fades out with the card
    if (kind == CARD_REVEAL || kind == CARD_SHEET) {  // the card stays where it is
      m.to = m.from;
      m.r1 = m.r0;
      m.reveal = kind == CARD_REVEAL;
      m.sheet = kind == CARD_SHEET;
      m.cx = (int16_t)s_revealAt.x;
      m.cy = (int16_t)s_revealAt.y;
    }
  }
  closeModal();
  if (morph) compBeginMorph(m, kind == CARD_REVEAL ? REVEAL_BACK_MS : kind == CARD_SHEET ? SHEET_BACK_MS : MORPH_BACK_MS, ++s_gen);
}

}  // namespace deckui
