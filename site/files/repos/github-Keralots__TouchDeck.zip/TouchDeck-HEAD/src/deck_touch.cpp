// Touch task and swipe arbiter, shared by every board; the controller
// driver is deck_touch_<chip>.cpp (contract in deck_touch_int.h).
#include "deck_touch.h"
#include "deck_touch_int.h"
#include "deck_panel.h"
#include "deck_ui.h"

namespace deck {
namespace {

// No valid frame for this long = finger lifted (the controller reports no
// explicit release event that we have seen).
constexpr uint32_t RELEASE_MS = 60;
// Read interval for controllers without an interrupt line.
constexpr uint32_t POLL_MS = 10;
// Movement before a touch is classified as a swipe or a vertical gesture.
constexpr int SLOP_PX = 12;
// A released swipe changes page when it travelled this share of the width,
// or when it is flung faster than FLING_PX_PER_MS toward the next page. The
// owner found the Phase 0 rule (half the width) needed far too long a swipe.
constexpr float COMMIT_FRACTION = 0.18f;
constexpr float FLING_PX_PER_MS = 0.25f;
constexpr uint32_t VELOCITY_WINDOW_MS = 90;
constexpr uint32_t SLIDE_MAX_MS = 280;
constexpr uint32_t SLIDE_MIN_MS = 90;
// The quick panel is pulled down from this band at the top edge (the page
// header), and opens or closes after this share of its height.
constexpr int EDGE_PX = 30;
constexpr float PANEL_COMMIT_FRACTION = 0.3f;

TaskHandle_t s_task = nullptr;
portMUX_TYPE s_mux = portMUX_INITIALIZER_UNLOCKED;
TouchPoint s_lv = {0, 0, false, false};
volatile bool s_down = false;
uint32_t s_lastTouch = 0;
volatile bool s_activity = false;
volatile bool s_swipeStarted = false;
volatile bool s_suppress = false;

// G_EAT: a swipe with no page that way; LVGL must not see it as a tap.
// G_WAIT: the compositor was busy (previous slide landing); retried each frame.
enum GestureState : uint8_t { G_IDLE, G_PENDING, G_PASS, G_DRAG, G_EAT, G_WAIT };

struct Sample {
  uint32_t ms;
  int16_t x, y;
};

// One compositor drag: horizontal (columns), vertical (pages of a column) or
// the quick panel, in compositor offset units: off runs from startOff toward
// commitOff.
struct Drag {
  bool vertical;
  bool panel;
  int startOff, commitOff, range, off;
  int8_t landing;  // reported when the drag commits
};
constexpr int NSAMPLES = 8;


// Native coordinates to the logical (rotated) space; same mapping as the
// pixels in deck_panel.cpp.
void toLogical(int nx, int ny, int16_t& x, int16_t& y) {
  switch (panelNativeRotation()) {
    case 1:  x = ny;                 y = NATIVE_W - 1 - nx; break;
    case 2:  x = NATIVE_W - 1 - nx;  y = NATIVE_H - 1 - ny; break;
    case 3:  x = NATIVE_H - 1 - ny;  y = nx;                break;
    default: x = nx;                 y = ny;                break;
  }
}

// cancel goes with the release in one critical section, so LVGL cannot read
// the release without it.
void publish(int16_t x, int16_t y, bool pressed, bool cancel = false) {
  portENTER_CRITICAL(&s_mux);
  s_lv.x = x;
  s_lv.y = y;
  s_lv.pressed = pressed;
  s_lv.cancel |= cancel;
  portEXIT_CRITICAL(&s_mux);
}

void touchTask(void*) {
  const bool irq = touchHwBegin(xTaskGetCurrentTaskHandle());

  GestureState state = G_IDLE;
  int16_t x0 = 0, y0 = 0, lastX = 0, lastY = 0;
  bool noSwipe = false;
  uint32_t lastMs = 0;
  Drag drag = {};
  Sample samples[NSAMPLES];
  int nsamples = 0;

  for (;;) {
    bool woke = true;
    if (irq) woke = ulTaskNotifyTake(pdTRUE, pdMS_TO_TICKS(s_down ? RELEASE_MS : 1000)) != 0;
    else vTaskDelay(pdMS_TO_TICKS(POLL_MS));
    const uint32_t now = millis();
    int nx, ny;
    if (woke && touchHwRead(nx, ny)) {
      touchNoteActivity();
      int16_t x, y;
      toLogical(nx, ny, x, y);
      if (!s_down) {
        s_down = true;
        s_activity = true;
        x0 = x;
        y0 = y;
        state = G_PENDING;
        noSwipe = uiNoSwipeAt(x, y);
        nsamples = 0;
      }
      lastX = x;
      lastY = y;
      lastMs = now;
      if (nsamples == NSAMPLES) {
        memmove(samples, samples + 1, sizeof(Sample) * (NSAMPLES - 1));
        nsamples--;
      }
      samples[nsamples++] = {now, x, y};

      bool took = false;
      if ((state == G_PENDING || state == G_WAIT) && !s_suppress) {
        const GestureState was = state;
        const int dx = x - x0, dy = y - y0;
        if (noSwipe && (abs(dx) >= SLOP_PX || abs(dy) >= SLOP_PX)) {
          state = G_PASS;  // a slider tile takes the drag
        } else if (abs(dx) >= SLOP_PX && abs(dx) > abs(dy)) {
          // Finger moving left reveals the next page.
          const int d = dx < 0 ? 1 : -1;
          Src a, b;
          int so, idxA;
          if (uiTryBeginSwipe(d, false, a, b, so, idxA)) {
            if (compBeginDrag(a, b, so, idxA, false)) {
              state = G_DRAG;
              const int w = logicalW();
              drag = {false, false, so, d > 0 ? w : 0, w, so, (int8_t)d};
            } else {
              uiSwipeAborted();
              state = G_WAIT;
            }
          } else {
            state = uiSwipeOwnsTouch() ? G_EAT : G_PASS;
          }
        } else if (abs(dy) >= SLOP_PX && abs(dy) > abs(dx)) {
          // Pull the quick panel down from the top edge, or push an open
          // one back up from anywhere. Elsewhere a vertical drag moves
          // between the pages of a column.
          const bool open = uiPanelIsOpen();
          state = G_PASS;
          if ((!open && dy > 0 && y0 < EDGE_PX) || (open && dy < 0)) {
            Src panel, page;
            int so, ph;
            if (uiTryBeginPanel(!open, panel, page, so, ph)) {
              if (compBeginPanel(panel, page, so)) {
                state = G_DRAG;
                drag = {true, true, so, open ? 0 : ph, ph, so, (int8_t)(open ? -1 : 1)};
              } else {
                uiSwipeAborted();
                state = G_WAIT;
              }
            }
          } else if (!open && y0 >= EDGE_PX) {
            // Finger moving up reveals the page below.
            const int d = dy < 0 ? 1 : -1;
            Src a, b;
            int so, idxA;
            if (uiTryBeginSwipe(d, true, a, b, so, idxA)) {
              if (compBeginDrag(a, b, so, idxA, true)) {
                state = G_DRAG;
                const int h = logicalH();
                drag = {true, false, so, d > 0 ? h : 0, h, so, (int8_t)d};
              } else {
                uiSwipeAborted();
                state = G_WAIT;
              }
            } else if (uiSwipeOwnsTouch()) {
              state = G_EAT;
            }
          }
        }
        if (was == G_WAIT && state == G_PASS) state = G_EAT;  // LVGL lost this press already
        took = was == G_PENDING && state != G_PENDING && state != G_PASS;
        if (took) s_swipeStarted = true;
      }
      if (state == G_DRAG) {
        int off = drag.panel      ? drag.startOff + (y - y0)
                  : drag.vertical ? drag.startOff - (y - y0)
                                  : drag.startOff - (x - x0);
        if (off < 0) off = 0;
        if (off > drag.range) off = drag.range;
        drag.off = off;
        compDrag(off);
      }
      publish(x, y, (state == G_PENDING || state == G_PASS) && !s_suppress, took);
      continue;
    }

    if (s_down && now - lastMs >= RELEASE_MS) {
      if (state == G_DRAG) {
        // Offset velocity (px/ms) over the last samples. Page offsets grow as
        // the finger moves left or up, the panel's as it moves down.
        float v = 0.0f;
        int first = nsamples - 1;
        while (first > 0 && lastMs - samples[first - 1].ms <= VELOCITY_WINDOW_MS) first--;
        const uint32_t dt = samples[nsamples - 1].ms - samples[first].ms;
        if (dt >= 15) {
          const Sample& a = samples[first];
          const Sample& b = samples[nsamples - 1];
          v = drag.panel      ? (float)(b.y - a.y) / dt
            : drag.vertical ? -(float)(b.y - a.y) / dt
                            : -(float)(b.x - a.x) / dt;
        }
        const float toward = drag.commitOff > drag.startOff ? v : -v;
        const int progress = abs(drag.off - drag.startOff);
        const float fraction = drag.panel ? PANEL_COMMIT_FRACTION : COMMIT_FRACTION;
        bool commit;
        if (toward > FLING_PX_PER_MS) commit = true;
        else if (toward < -FLING_PX_PER_MS) commit = false;
        else commit = progress > (int)(drag.range * fraction);
        const int target = commit ? drag.commitOff : drag.startOff;
        const int remaining = abs(target - drag.off);
        uint32_t dur = (uint32_t)remaining * SLIDE_MAX_MS / (uint32_t)drag.range;
        const float speed = fabsf(v);
        if (commit && speed > FLING_PX_PER_MS) {
          const uint32_t flingDur = (uint32_t)(remaining / speed * 1.6f);
          if (flingDur < dur) dur = flingDur;
        }
        if (dur < SLIDE_MIN_MS) dur = SLIDE_MIN_MS;
        if (dur > SLIDE_MAX_MS) dur = SLIDE_MAX_MS;
        compRelease(target, dur, commit ? drag.landing : 0);
      }
      touchNoteActivity();
      s_down = false;
      s_suppress = false;
      state = G_IDLE;
      publish(lastX, lastY, false);
    }
  }
}

}  // namespace

void touchBegin() {
  // Stack in PSRAM: this task never touches flash (NVS, LittleFS).
  xTaskCreatePinnedToCoreWithCaps(touchTask, "deck_touch", 4096, nullptr, 10, &s_task, 0, MALLOC_CAP_SPIRAM);
}

TouchPoint touchForLvgl() {
  portENTER_CRITICAL(&s_mux);
  TouchPoint p = s_lv;
  s_lv.cancel = false;
  portEXIT_CRITICAL(&s_mux);
  return p;
}

bool touchIsDown() { return s_down; }

uint32_t touchLastActivity() {
  portENTER_CRITICAL(&s_mux);
  const uint32_t ms = s_lastTouch;
  portEXIT_CRITICAL(&s_mux);
  return ms;
}

void touchNoteActivity() {
  portENTER_CRITICAL(&s_mux);
  s_lastTouch = millis();
  portEXIT_CRITICAL(&s_mux);
}

bool touchTakeActivity() {
  if (!s_activity) return false;
  s_activity = false;
  return true;
}

bool touchTakeSwipeStarted() {
  if (!s_swipeStarted) return false;
  s_swipeStarted = false;
  return true;
}

void touchSuppressUntilRelease() {
  s_suppress = true;
  portENTER_CRITICAL(&s_mux);
  s_lv.pressed = false;
  s_lv.cancel = true;
  portEXIT_CRITICAL(&s_mux);
}

}  // namespace deck
