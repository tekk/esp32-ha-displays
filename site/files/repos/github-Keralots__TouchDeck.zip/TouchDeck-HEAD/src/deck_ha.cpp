// Guition deck: Home Assistant client. See deck_ha.h.
#include "deck_ha.h"
#include "deck_config.h"
#include "deck_panel.h"
#include <LittleFS.h>
#include <time.h>
#include <sys/time.h>
#include <ArduinoJson.h>
#include <HTTPClient.h>
#include <Preferences.h>
#include <WebSocketsClient.h>
#include <WiFi.h>
#include <esp_task_wdt.h>
#include <algorithm>
#include <deque>
#include <new>

namespace deck {
namespace {

// The WebSocket library drops any frame over 15 KB, and the first frame of a
// subscription carries every attribute of every entity in it. A few entities
// per subscription keeps that frame small even for chatty lights.
constexpr size_t SUB_BATCH = 4;
constexpr uint32_t RECONNECT_MS = 5000;
constexpr size_t MAX_QUEUED_CALLS = 8;

// ArduinoJson grows a document in small blocks, and small blocks land in
// internal RAM. A filtered /api/states of a real installation is hundreds of
// blocks; it emptied the internal heap and stalled the portal's sockets.
struct PsramAllocator : ArduinoJson::Allocator {
  void* allocate(size_t n) override { return heap_caps_malloc(n, MALLOC_CAP_SPIRAM); }
  void deallocate(void* p) override { heap_caps_free(p); }
  void* reallocate(void* p, size_t n) override { return heap_caps_realloc(p, n, MALLOC_CAP_SPIRAM); }
};
ArduinoJson::Allocator* psram() {
  static PsramAllocator a;
  return &a;
}

SemaphoreHandle_t s_lock = nullptr;
struct Lock {
  Lock() { xSemaphoreTake(s_lock, portMAX_DELAY); }
  ~Lock() { xSemaphoreGive(s_lock); }
};

// --- guarded by s_lock ---
String s_url, s_token;
uint32_t s_credGen = 1;
HaLink s_link = HA_NOT_CONFIGURED;
String s_error, s_haVersion;
struct Entry {
  String id;
  HaEntity e;
};
std::vector<Entry> s_store;
std::vector<String> s_wanted;
uint32_t s_wantedGen = 1;
uint32_t s_version = 1;
struct Call {
  String domain, service, target, data;
  uint32_t tracking;
};
struct CallResultSlot {
  uint32_t id = 0;
  bool ready = false;
  HaCallResult result;
};
CallResultSlot s_results[16];
uint32_t s_nextTracking = 0;
std::deque<Call> s_calls;
struct Failure {
  String entity, message;
};
std::deque<Failure> s_failures;
struct RawId {
  char id[HA_RAW_ID];
};
RawId* s_raw = nullptr;  // PSRAM, sorted
size_t s_rawCount = 0;
HaRawHook s_rawHook = nullptr;

int rawCmp(const void* a, const void* b) { return strcmp((const char*)a, (const char*)b); }

// Registry lookup: queued under s_lock, then owned by the HA task.
constexpr size_t REG_BATCH = 6;  // get_entries answers stay well under the frame limit
struct RegJob {
  String tmpl;
  uint32_t tag = 0;
  HaRegDone done = nullptr;
  HaRegEntry* list = nullptr;  // PSRAM
  size_t count = 0, next = 0;
  uint32_t waitId = 0;
  bool started = false;
};
RegJob* s_regQueued = nullptr;

// --- HA task only ---
RegJob* s_reg = nullptr;
WebSocketsClient s_ws;
bool s_started = false;
uint32_t s_appliedCredGen = 0;
uint32_t s_subscribedGen = 0;
uint32_t s_nextId = 1;
std::vector<uint32_t> s_subIds;
struct Pending {
  uint32_t id;
  String entity;
  uint32_t tracking;
};
std::vector<Pending> s_pending;
bool s_everConnected = false;

// --- History store and worker handle, guarded by s_lock ---
struct HistoryData {
  float value[HA_HISTORY_POINTS], weight[HA_HISTORY_POINTS];
  float low[HA_HISTORY_POINTS], high[HA_HISTORY_POINTS];
  time_t end = 0, cursor = 0;
  float live = NAN;
};
struct History {
  HaHistoryKey key;
  HistoryData data, tail;
  bool configured = false, detail = false, fetching = false;
  uint32_t id = 0, request = 0, version = 0, due = 0;
};
std::vector<History*> s_history;
uint32_t s_histVersion = 1, s_histId = 0;
TaskHandle_t s_histTask = nullptr;
void historyTask(void*);

void clearHistory(HistoryData& d, time_t end, float live) {
  for (int i = 0; i < HA_HISTORY_POINTS; i++) {
    d.value[i] = d.low[i] = d.high[i] = NAN;
    d.weight[i] = 0;
  }
  d.end = d.cursor = end;
  d.live = live;
}

void addHistory(HistoryData& d, int i, float value, float seconds) {
  if (!isfinite(value) || seconds <= 0) return;
  const float total = d.weight[i] + seconds;
  d.value[i] = d.weight[i] > 0 ? (float)(((double)d.value[i] * d.weight[i] +
                                       (double)value * seconds) / total) : value;
  d.weight[i] = total;
  d.low[i] = isnan(d.low[i]) ? value : min(d.low[i], value);
  d.high[i] = isnan(d.high[i]) ? value : max(d.high[i], value);
}

void shiftHistory(HistoryData& d, time_t end, int width) {
  const int n = (int)min((time_t)HA_HISTORY_POINTS, (end - d.end) / width);
  if (n <= 0) return;
  for (int i = 0; i < HA_HISTORY_POINTS; i++) {
    d.value[i] = i + n < HA_HISTORY_POINTS ? d.value[i + n] : NAN;
    d.weight[i] = i + n < HA_HISTORY_POINTS ? d.weight[i + n] : 0;
    d.low[i] = i + n < HA_HISTORY_POINTS ? d.low[i + n] : NAN;
    d.high[i] = i + n < HA_HISTORY_POINTS ? d.high[i + n] : NAN;
  }
  d.end = end;
}

bool advanceHistory(HistoryData& d, uint8_t hours, time_t now) {
  if (!d.end || now <= d.cursor) return false;
  const int width = hours * 3600 / HA_HISTORY_POINTS;
  const time_t end = now > d.end ? d.end + ((now - d.end + width - 1) / width) * width : d.end;
  const bool shifted = end != d.end;
  shiftHistory(d, end, width);
  const time_t start = d.end - hours * 3600;
  time_t at = max(d.cursor, start);
  bool changed = shifted;
  while (at < now) {
    const int i = min(HA_HISTORY_POINTS - 1, (int)((at - start) / width));
    const time_t to = min(now, start + (i + 1) * width);
    const float before = d.value[i], low = d.low[i], high = d.high[i];
    addHistory(d, i, d.live, (float)(to - at));
    changed = changed || (isfinite(before) != isfinite(d.value[i])) ||
              (isfinite(before) && (before != d.value[i] || low != d.low[i] || high != d.high[i]));
    at = to;
  }
  d.cursor = now;
  return changed;
}

// Called with s_lock held; integrate the old state before accepting the new one.
void historyLive(time_t now) {
  if (now < 1609459200) return;
  for (History* h : s_history) {
    bool changed = advanceHistory(h->data, h->key.hours, now);
    float value = NAN;
    if (s_link == HA_CONNECTED)
      for (const Entry& en : s_store)
        if (en.id == h->key.entity && en.e.known) { haNumericState(en.e.state, value); break; }
    if (!h->data.end) clearHistory(h->data, now, value);
    h->data.live = value;
    if (h->fetching) {
      advanceHistory(h->tail, h->key.hours, now);
      h->tail.live = value;
    }
    if (changed) h->version = ++s_histVersion;
  }
}

History* findHistory(const String& entity, uint8_t hours) {
  for (History* h : s_history)
    if (h->key.entity == entity && h->key.hours == hours) return h;
  return nullptr;
}

History* ensureHistory(const String& entity, uint8_t hours) {
  if (!entity.length()) return nullptr;
  if (History* h = findHistory(entity, hours)) return h;
  void* mem = heap_caps_malloc(sizeof(History), MALLOC_CAP_SPIRAM);
  if (!mem) return nullptr;
  History* h = new (mem) History;
  h->key.entity = entity;
  h->key.hours = hours;
  h->id = ++s_histId;
  clearHistory(h->data, 0, NAN);
  clearHistory(h->tail, 0, NAN);
  s_history.push_back(h);
  return h;
}

void pruneHistory() {
  for (auto it = s_history.begin(); it != s_history.end();) {
    History* h = *it;
    if (h->configured || h->detail) { ++it; continue; }
    h->~History();
    heap_caps_free(h);
    it = s_history.erase(it);
  }
}

void startHistoryTask() {
  if (!s_histTask && !s_history.empty())
    // Stack in PSRAM: this task never touches flash (NVS, LittleFS).
    xTaskCreatePinnedToCoreWithCaps(historyTask, "deck_hist", 6144, nullptr, 2, &s_histTask, 0, MALLOC_CAP_SPIRAM);
}

void setLink(HaLink l, const String& err = String()) {
  Lock g;
  if (s_link != l || (err.length() && err != s_error)) s_version++;
  const bool connected = l == HA_CONNECTED && s_link != l;
  historyLive(time(nullptr));
  s_link = l;
  if (connected) for (History* h : s_history) { h->due = 0; h->request++; }
  if (l != HA_CONNECTED)
    for (History* h : s_history) h->data.live = h->tail.live = NAN;
  if (err.length()) s_error = err;
  if (l == HA_CONNECTED) s_error = "";
}

void loadCredentials() {
  Preferences p;
  if (p.begin("deckha", true)) {
    s_url = p.getString("url", "");
    s_token = p.getString("token", "");
    p.end();
  }
}

// "http://host:port" (or "host:port", "host") -> host, port.
bool parseUrl(const String& url, String& host, uint16_t& port, String& err) {
  String u = url;
  u.trim();
  while (u.endsWith("/")) u.remove(u.length() - 1);
  if (u.startsWith("https://")) {
    err = "https is not supported yet - use the LAN http address";
    return false;
  }
  if (u.startsWith("http://")) u = u.substring(7);
  const int slash = u.indexOf('/');
  if (slash >= 0) u = u.substring(0, slash);
  const int colon = u.indexOf(':');
  if (colon >= 0) {
    host = u.substring(0, colon);
    port = (uint16_t)u.substring(colon + 1).toInt();
  } else {
    host = u;
    port = 8123;
  }
  if (!host.length() || port == 0) {
    err = "invalid Home Assistant address";
    return false;
  }
  return true;
}

void sendJson(JsonDocument& doc) {
  String out;
  serializeJson(doc, out);
  s_ws.sendTXT(out);
}

// The climate attribute a number field holds, or null for other keys.
float* climateField(HaEntity& e, const char* k) {
  if (!strcmp(k, "temperature")) return &e.target;
  if (!strcmp(k, "target_temp_low")) return &e.targetLow;
  if (!strcmp(k, "target_temp_high")) return &e.targetHigh;
  if (!strcmp(k, "current_temperature")) return &e.current;
  if (!strcmp(k, "min_temp")) return &e.tempMin;
  if (!strcmp(k, "max_temp")) return &e.tempMax;
  if (!strcmp(k, "target_temp_step")) return &e.tempStep;
  return nullptr;
}

void clearClimate(HaEntity& e) {
  e.target = e.targetLow = e.targetHigh = e.current = NAN;
  e.tempMin = e.tempMax = e.tempStep = NAN;
  e.hvacAction = "";
  e.hvacModes = "";
}

bool historyEpoch(const char* s, time_t& epoch);

void clearMedia(HaEntity& e) {
  e.mediaTitle = "";
  e.mediaArtist = "";
  e.mediaPicture = "";
  e.mediaPictureRemote = "";
  e.mediaSource = "";
  e.mediaInputs = "";
  e.mediaDuration = e.mediaPosition = 0;
  e.mediaPosAt = 0;
}

// True when k is a media attribute (absent or null clears it).
bool mediaField(HaEntity& e, const char* k, JsonVariantConst v) {
  if (!strcmp(k, "media_title")) e.mediaTitle = v.is<const char*>() ? (const char*)v : "";
  else if (!strcmp(k, "media_artist")) e.mediaArtist = v.is<const char*>() ? (const char*)v : "";
  else if (!strcmp(k, "entity_picture")) e.mediaPictureRemote = v.is<const char*>() ? (const char*)v : "";
  else if (!strcmp(k, "entity_picture_local")) e.mediaPicture = v.is<const char*>() ? (const char*)v : "";
  else if (!strcmp(k, "source")) e.mediaSource = v.is<const char*>() ? (const char*)v : "";
  else if (!strcmp(k, "source_list")) {
    e.mediaInputs = "";
    for (JsonVariantConst s : v.as<JsonArrayConst>())
      if (s.is<const char*>()) e.mediaInputs += String('\n') + s.as<const char*>();
    if (e.mediaInputs.length()) e.mediaInputs += '\n';
  } else if (!strcmp(k, "media_duration")) e.mediaDuration = v.is<float>() ? (int32_t)lroundf(v.as<float>()) : 0;
  else if (!strcmp(k, "media_position")) e.mediaPosition = v.is<float>() ? (int32_t)lroundf(v.as<float>()) : 0;
  else if (!strcmp(k, "media_position_updated_at")) {
    if (!v.is<const char*>() || !historyEpoch(v.as<const char*>(), e.mediaPosAt)) e.mediaPosAt = 0;
  } else return false;
  return true;
}

void entityFromAttrs(HaEntity& e, JsonObjectConst a) {
  if (a.isNull()) return;
  if (a["friendly_name"].is<const char*>()) e.name = (const char*)a["friendly_name"];
  if (a["icon"].is<const char*>()) e.icon = (const char*)a["icon"];
  if (a["unit_of_measurement"].is<const char*>()) e.unit = (const char*)a["unit_of_measurement"];
  if (a["device_class"].is<const char*>()) e.deviceClass = (const char*)a["device_class"];
  // Present-but-null (a light turning off) must clear it, so look at the
  // keys rather than at a["brightness"], which cannot tell null from absent.
  for (JsonPairConst kv : a) {
    const char* k = kv.key().c_str();
    if (!strcmp(k, "brightness")) {
      e.brightness = kv.value().is<int>() ? kv.value().as<int>() : -1;
    } else if (!strcmp(k, "rgb_color")) {
      JsonArrayConst c = kv.value().as<JsonArrayConst>();
      e.rgb = c.size() == 3 ? (int32_t)((c[0].as<int>() & 255) << 16 | (c[1].as<int>() & 255) << 8 | (c[2].as<int>() & 255)) : -1;
    } else if (!strcmp(k, "color_temp_kelvin")) {
      e.kelvin = kv.value().is<int>() ? kv.value().as<int>() : -1;
    } else if (!strcmp(k, "min_color_temp_kelvin")) {
      e.kelvinMin = kv.value().is<int>() ? kv.value().as<int>() : -1;
    } else if (!strcmp(k, "max_color_temp_kelvin")) {
      e.kelvinMax = kv.value().is<int>() ? kv.value().as<int>() : -1;
    } else if (!strcmp(k, "current_position") || !strcmp(k, "percentage")) {
      e.level = kv.value().is<float>() ? (int)lroundf(kv.value().as<float>()) : -1;
    } else if (!strcmp(k, "supported_features")) {
      e.features = kv.value().is<int32_t>() ? kv.value().as<int32_t>() : -1;
    } else if (!strcmp(k, "volume_level")) {
      e.level = kv.value().is<float>() ? (int)lroundf(kv.value().as<float>() * 100) : -1;
    } else if (float* f = climateField(e, k)) {
      *f = kv.value().is<float>() ? kv.value().as<float>() : NAN;  // null when off
    } else if (mediaField(e, k, kv.value())) {
    } else if (!strcmp(k, "hvac_action")) {
      e.hvacAction = kv.value().is<const char*>() ? (const char*)kv.value() : "";
    } else if (!strcmp(k, "hvac_modes")) {
      e.hvacModes = "";
      for (JsonVariantConst m : kv.value().as<JsonArrayConst>()) {
        if (!m.is<const char*>()) continue;
        if (e.hvacModes.length()) e.hvacModes += ',';
        e.hvacModes += (const char*)m;
      }
    }
  }
  if (a["min"].is<float>()) e.numMin = a["min"].as<float>();
  if (a["max"].is<float>()) e.numMax = a["max"].as<float>();
  if (a["step"].is<float>()) e.numStep = a["step"].as<float>();
}

Entry* findEntry(const char* id) {
  for (Entry& en : s_store)
    if (en.id == id) return &en;
  return nullptr;
}

HaRawHook rawHook(const char* id) {
  Lock g;
  if (!s_rawHook || !s_rawCount || !bsearch(id, s_raw, s_rawCount, sizeof(RawId), rawCmp)) return nullptr;
  return s_rawHook;
}

// subscribe_entities event: "a" = full states, "c" = diffs, "r" = removed.
void applyEvent(JsonObjectConst ev) {
  for (JsonPairConst kv : ev["a"].as<JsonObjectConst>())
    if (HaRawHook h = rawHook(kv.key().c_str())) h(kv.key().c_str(), kv.value().as<JsonObjectConst>(), true);
  for (JsonPairConst kv : ev["c"].as<JsonObjectConst>())
    if (HaRawHook h = rawHook(kv.key().c_str())) h(kv.key().c_str(), kv.value().as<JsonObjectConst>(), false);
  for (JsonVariantConst r : ev["r"].as<JsonArrayConst>())
    if (HaRawHook h = rawHook(r | "")) h(r | "", JsonObjectConst(), true);
  Lock g;
  bool changed = false;
  for (JsonPairConst kv : ev["a"].as<JsonObjectConst>()) {
    Entry* en = findEntry(kv.key().c_str());
    if (!en) continue;
    HaEntity& e = en->e;
    e.known = true;
    e.state = (const char*)(kv.value()["s"] | "");
    e.name = "";
    e.icon = "";
    e.unit = "";
    e.deviceClass = "";
    e.brightness = -1;
    e.rgb = -1;
    e.kelvin = e.kelvinMin = e.kelvinMax = -1;
    e.level = -1;
    e.features = -1;
    e.numMin = e.numMax = e.numStep = NAN;
    clearClimate(e);
    clearMedia(e);
    entityFromAttrs(e, kv.value()["a"].as<JsonObjectConst>());
    e.version++;
    changed = true;
  }
  for (JsonPairConst kv : ev["c"].as<JsonObjectConst>()) {
    Entry* en = findEntry(kv.key().c_str());
    if (!en) continue;
    HaEntity& e = en->e;
    JsonObjectConst plus = kv.value()["+"];
    if (!plus.isNull()) {
      if (plus["s"].is<const char*>()) e.state = (const char*)plus["s"];
      entityFromAttrs(e, plus["a"].as<JsonObjectConst>());
    }
    for (JsonVariantConst k : kv.value()["-"]["a"].as<JsonArrayConst>()) {
      const char* key = k | "";
      if (!strcmp(key, "brightness")) e.brightness = -1;
      else if (!strcmp(key, "rgb_color")) e.rgb = -1;
      else if (!strcmp(key, "color_temp_kelvin")) e.kelvin = -1;
      else if (!strcmp(key, "min_color_temp_kelvin")) e.kelvinMin = -1;
      else if (!strcmp(key, "max_color_temp_kelvin")) e.kelvinMax = -1;
      else if (!strcmp(key, "current_position") || !strcmp(key, "percentage") ||
               !strcmp(key, "volume_level"))
        e.level = -1;
      else if (!strcmp(key, "supported_features")) e.features = -1;
      else if (float* f = climateField(e, key)) *f = NAN;
      else if (mediaField(e, key, JsonVariantConst())) {}
      else if (!strcmp(key, "hvac_action")) e.hvacAction = "";
      else if (!strcmp(key, "hvac_modes")) e.hvacModes = "";
      else if (!strcmp(key, "icon")) e.icon = "";
      else if (!strcmp(key, "unit_of_measurement")) e.unit = "";
      else if (!strcmp(key, "device_class")) e.deviceClass = "";
      else if (!strcmp(key, "friendly_name")) e.name = "";
    }
    e.version++;
    changed = true;
  }
  for (JsonVariantConst r : ev["r"].as<JsonArrayConst>()) {
    Entry* en = findEntry(r | "");
    if (!en) continue;
    en->e.known = false;
    en->e.version++;
    changed = true;
  }
  if (changed) { s_version++; historyLive(time(nullptr)); }
}

// Called with s_lock held. Keep the state version and time at the actual result.
void finishCall(uint32_t tracking, const String& entity, bool ok) {
  if (!tracking) return;
  for (CallResultSlot& slot : s_results) {
    if (slot.id != tracking) continue;
    const Entry* en = findEntry(entity.c_str());
    slot.result = {ok, millis(), en ? en->e.version : 0};
    slot.ready = true;
    return;
  }
}

void failPending(const String& message) {
  Lock g;
  for (const Pending& p : s_pending) {
    finishCall(p.tracking, p.entity, false);
    s_failures.push_back({p.entity, message});
  }
  s_pending.clear();
  for (const Call& c : s_calls) {
    finishCall(c.tracking, c.target, false);
    s_failures.push_back({c.target, message});
  }
  s_calls.clear();
}

// --- Clock from Home Assistant ----------------------------------------------------------
// A render_template subscription of utcnow(): its first event carries the
// time, then it is unsubscribed. Half the round trip is added, as SNTP does.
volatile bool s_timeSync = false;
volatile time_t s_timeSyncedAt = 0;  // guarded loosely: a status read
String s_timeError;                  // under s_lock
constexpr uint32_t TIME_RESYNC_MS = 60UL * 60 * 1000;
constexpr uint32_t TIME_RETRY_MS = 60UL * 1000;
constexpr uint32_t TIME_ANSWER_MS = 10000;
// HA task only:
uint32_t s_timeId = 0, s_timeSentMs = 0, s_timeNextMs = 0;
bool s_timeDue = true;

void timeError(const String& e) {
  Lock g;
  s_timeError = e;
}

void timeStop(bool retry) {
  if (s_timeId) {
    JsonDocument u(psram());
    u["id"] = s_nextId++;
    u["type"] = "unsubscribe_events";
    u["subscription"] = s_timeId;
    sendJson(u);
  }
  s_timeId = 0;
  s_timeDue = false;
  s_timeNextMs = millis() + (retry ? TIME_RETRY_MS : TIME_RESYNC_MS);
}

void timeTick() {
  if (!s_timeSync) {
    if (s_timeId) timeStop(false);
    s_timeDue = true;  // first thing once it is turned on
    return;
  }
  const uint32_t now = millis();
  if (s_timeId) {
    if (now - s_timeSentMs >= TIME_ANSWER_MS) {
      timeError("no answer from Home Assistant");
      Serial.println("HA: no answer to the time request");
      timeStop(true);
    }
    return;
  }
  if (!s_timeDue && (int32_t)(now - s_timeNextMs) < 0) return;
  JsonDocument d(psram());
  s_timeId = s_nextId++;
  d["id"] = s_timeId;
  d["type"] = "render_template";
  d["template"] = "{{ utcnow().timestamp() }}";
  s_timeSentMs = now;
  s_timeDue = false;
  sendJson(d);
}

void timeReply(JsonVariantConst result) {
  double ts = NAN;
  if (result.is<double>()) ts = result.as<double>();
  else if (result.is<const char*>()) ts = strtod(result.as<const char*>(), nullptr);
  if (!(ts > 1609459200.0)) {  // 2021-01-01: anything older is not a clock
    timeError("Home Assistant sent no usable time");
    timeStop(true);
    return;
  }
  ts += (millis() - s_timeSentMs) / 2000.0;
  timeval tv;
  tv.tv_sec = (time_t)ts;
  tv.tv_usec = (suseconds_t)((ts - (double)tv.tv_sec) * 1e6);
  const time_t before = time(nullptr);
  settimeofday(&tv, nullptr);
  s_timeSyncedAt = tv.tv_sec;
  timeError("");
  Serial.printf("HA: clock set from Home Assistant (%+ld s)\n", (long)(tv.tv_sec - before));
  timeStop(false);
}

void regFinish(bool ok, const char* err);
void regReply(bool ok, JsonDocument& doc);
void regStep();

void handleText(const uint8_t* payload, size_t len) {
  JsonDocument doc(psram());
  if (deserializeJson(doc, payload, len)) return;
  const char* type = doc["type"] | "";
  if (!strcmp(type, "auth_required")) {
    String token;
    {
      Lock g;
      token = s_token;
    }
    JsonDocument a(psram());
    a["type"] = "auth";
    a["access_token"] = token;
    sendJson(a);
    setLink(HA_AUTHENTICATING);
  } else if (!strcmp(type, "auth_ok")) {
    {
      Lock g;
      s_haVersion = (const char*)(doc["ha_version"] | "");
    }
    s_everConnected = true;
    s_subscribedGen = 0;  // subscribe from scratch on every connection
    s_subIds.clear();
    s_timeId = 0;
    s_timeDue = true;  // the clock again on every connection
    setLink(HA_CONNECTED);
    Serial.printf("HA: connected, Home Assistant %s\n", (const char*)(doc["ha_version"] | "?"));
  } else if (!strcmp(type, "auth_invalid")) {
    setLink(HA_AUTH_FAILED, String("token rejected: ") + (const char*)(doc["message"] | ""));
    Serial.println("HA: authentication failed, waiting for new settings");
    s_ws.disconnect();
  } else if (!strcmp(type, "event")) {
    if (s_timeId && (doc["id"] | 0u) == s_timeId) {
      timeReply(doc["event"]["result"]);
      return;
    }
    applyEvent(doc["event"].as<JsonObjectConst>());
  } else if (!strcmp(type, "result")) {
    const uint32_t id = doc["id"] | 0;
    const bool ok = doc["success"] | false;
    if (s_reg && s_reg->waitId == id) {
      regReply(ok, doc);
      return;
    }
    if (s_timeId && id == s_timeId) {
      if (!ok) {  // a template error, or a server that refuses render_template
        const char* msg = doc["error"]["message"] | "request refused";
        timeError(String("time request refused: ") + msg);
        Serial.printf("HA: time request refused: %s\n", msg);
        s_timeId = 0;  // nothing to unsubscribe
        timeStop(false);
      }
      return;
    }
    for (size_t i = 0; i < s_pending.size(); i++) {
      if (s_pending[i].id != id) continue;
      {
        Lock g;
        finishCall(s_pending[i].tracking, s_pending[i].entity, ok);
        if (!ok)
          s_failures.push_back({s_pending[i].entity, (const char*)(doc["error"]["message"] | "service call failed")});
      }
      s_pending.erase(s_pending.begin() + i);
      return;
    }
    if (!ok) Serial.printf("HA: request %u failed: %s\n", (unsigned)id,
                           (const char*)(doc["error"]["message"] | "?"));
  }
}

void onWsEvent(WStype_t type, uint8_t* payload, size_t length) {
  switch (type) {
    case WStype_CONNECTED:
      setLink(HA_AUTHENTICATING);
      break;
    case WStype_DISCONNECTED: {
      HaLink l;
      {
        Lock g;
        l = s_link;
      }
      if (l != HA_AUTH_FAILED) setLink(s_everConnected ? HA_CONNECTING : HA_UNREACHABLE,
                                       s_everConnected ? String() : String("no answer from Home Assistant"));
      s_subscribedGen = 0;
      s_subIds.clear();
      s_timeId = 0;
      if (s_reg) regFinish(false, "connection to Home Assistant lost");
      // Never replay an uncertain call after a reconnect: report it instead.
      failPending("connection to Home Assistant lost");
      break;
    }
    case WStype_TEXT:
      handleText(payload, length);
      break;
    default:
      break;
  }
}

void resubscribe() {
  std::vector<String> wanted;
  RawId* raw = nullptr;
  size_t rawCount = 0;
  uint32_t gen;
  {
    Lock g;
    wanted = s_wanted;
    raw = s_rawCount ? (RawId*)heap_caps_malloc(s_rawCount * sizeof(RawId), MALLOC_CAP_SPIRAM) : nullptr;
    if (raw) {
      memcpy(raw, s_raw, s_rawCount * sizeof(RawId));
      rawCount = s_rawCount;
    }
    gen = s_wantedGen;
  }
  std::vector<const char*> ids;
  ids.reserve(wanted.size() + rawCount);
  for (const String& id : wanted) ids.push_back(id.c_str());
  for (size_t i = 0; i < rawCount; i++)
    if (!std::binary_search(wanted.begin(), wanted.end(), String(raw[i].id))) ids.push_back(raw[i].id);
  for (uint32_t sub : s_subIds) {
    JsonDocument u(psram());
    u["id"] = s_nextId++;
    u["type"] = "unsubscribe_events";
    u["subscription"] = sub;
    sendJson(u);
  }
  s_subIds.clear();
  for (size_t i = 0; i < ids.size(); i += SUB_BATCH) {
    JsonDocument d(psram());
    const uint32_t id = s_nextId++;
    d["id"] = id;
    d["type"] = "subscribe_entities";
    JsonArray batch = d["entity_ids"].to<JsonArray>();
    for (size_t k = i; k < ids.size() && k < i + SUB_BATCH; k++) batch.add(ids[k]);
    sendJson(d);
    s_subIds.push_back(id);
  }
  heap_caps_free(raw);
  s_subscribedGen = gen;
}

void sendQueuedCalls() {
  for (int n = 0; n < 4; n++) {
    Call c;
    {
      Lock g;
      if (s_link != HA_CONNECTED || s_calls.empty()) return;
      c = s_calls.front();
      s_calls.pop_front();
    }
    JsonDocument d(psram());
    const uint32_t id = s_nextId++;
    d["id"] = id;
    d["type"] = "call_service";
    d["domain"] = c.domain;
    d["service"] = c.service;
    if (c.target.length()) d["target"]["entity_id"] = c.target;
    if (c.data.length()) {
      JsonDocument data(psram());
      if (!deserializeJson(data, c.data)) d["service_data"] = data.as<JsonObjectConst>();
    }
    s_pending.push_back({id, c.target, c.tracking});
    sendJson(d);
  }
}

volatile bool s_paused = false;

void haTask(void*) {
  for (;;) {
    uint32_t credGen;
    String url, token;
    {
      Lock g;
      credGen = s_credGen;
      url = s_url;
      token = s_token;
    }
    if (credGen != s_appliedCredGen) {
      s_appliedCredGen = credGen;
      if (s_started) s_ws.disconnect();
      s_started = false;
      s_everConnected = false;
      setLink(HA_NOT_CONFIGURED);
      failPending("connection to Home Assistant lost");
      if (s_reg) regFinish(false, "Home Assistant settings changed");
      {
        Lock g;
        s_error = "";
      }
    }
    if (!url.length() || !token.length()) {
      setLink(HA_NOT_CONFIGURED);
      vTaskDelay(pdMS_TO_TICKS(250));
      continue;
    }
    if (WiFi.status() != WL_CONNECTED) {
      if (s_started) {
        s_ws.disconnect();
        s_started = false;
      }
      setLink(HA_WAITING_WIFI);
      failPending("connection to Home Assistant lost");
      vTaskDelay(pdMS_TO_TICKS(500));
      continue;
    }
    if (haLink() == HA_AUTH_FAILED) {
      vTaskDelay(pdMS_TO_TICKS(250));  // until the settings change
      continue;
    }
    if (s_paused) {
      if (s_started) {
        s_ws.disconnect();
        s_started = false;
      }
      setLink(HA_CONNECTING);
      vTaskDelay(pdMS_TO_TICKS(250));
      continue;
    }
    if (!s_started) {
      String host, err;
      uint16_t port;
      if (!parseUrl(url, host, port, err)) {
        setLink(HA_UNREACHABLE, err);
        vTaskDelay(pdMS_TO_TICKS(1000));
        continue;
      }
      s_ws.begin(host.c_str(), port, "/api/websocket", "");
      s_ws.onEvent(onWsEvent);
      s_ws.setReconnectInterval(RECONNECT_MS);
      s_ws.enableHeartbeat(25000, 10000, 2);
      s_started = true;
      setLink(HA_CONNECTING);
      Serial.printf("HA: connecting to %s:%u\n", host.c_str(), (unsigned)port);
    }
    s_ws.loop();
    static uint32_t lastHistory = 0;
    if (millis() - lastHistory >= 1000) {
      lastHistory = millis();
      Lock g;
      historyLive(time(nullptr));
    }
    if (haLink() == HA_CONNECTED) {
      uint32_t wantedGen;
      {
        Lock g;
        wantedGen = s_wantedGen;
      }
      if (s_subscribedGen != wantedGen) resubscribe();
      sendQueuedCalls();
      regStep();
      timeTick();
    }
    vTaskDelay(pdMS_TO_TICKS(5));
  }
}

}  // namespace

const char* haLinkName(HaLink s) {
  switch (s) {
    case HA_NOT_CONFIGURED: return "not set up";
    case HA_WAITING_WIFI: return "waiting for WiFi";
    case HA_CONNECTING: return "connecting";
    case HA_AUTHENTICATING: return "authenticating";
    case HA_CONNECTED: return "connected";
    case HA_AUTH_FAILED: return "token rejected";
    case HA_UNREACHABLE: return "unreachable";
  }
  return "?";
}

void haPause(bool pause) { s_paused = pause; }

void haSetTimeSync(bool on) { s_timeSync = on; }
time_t haTimeSyncedAt() { return s_timeSyncedAt; }
String haTimeError() {
  if (!s_lock) return "";
  Lock g;
  return s_timeError;
}

void haBegin() {
  if (s_lock) return;
  s_lock = xSemaphoreCreateMutex();
  loadCredentials();
  // Core 0 with the WiFi stack; the display pipeline owns core 1. Stack in
  // PSRAM: this task never touches flash (credentials load above).
  xTaskCreatePinnedToCoreWithCaps(haTask, "deck_ha", 8192, nullptr, 4, nullptr, 0, MALLOC_CAP_SPIRAM);
}

void haSetCredentials(const String& url, const String& token) {
  String u = url;
  u.trim();
  Preferences p;
  if (p.begin("deckha", false)) {
    p.putString("url", u);
    if (token.length()) p.putString("token", token);
    p.end();
  }
  Lock g;
  s_url = u;
  if (token.length()) s_token = token;
  s_credGen++;
  s_version++;
}

void haClearCredentials() {
  Preferences p;
  if (p.begin("deckha", false)) {
    p.clear();
    p.end();
  }
  Lock g;
  s_url = "";
  s_token = "";
  s_credGen++;
  s_version++;
}

String haUrl() {
  Lock g;
  return s_url;
}

bool haHasToken() {
  Lock g;
  return s_token.length() > 0;
}

HaLink haLink() {
  Lock g;
  return s_link;
}

String haLastError() {
  Lock g;
  return s_error;
}

String haServerVersion() {
  Lock g;
  return s_haVersion;
}

void haSetEntities(const std::vector<String>& ids) {
  std::vector<String> sorted = ids;
  std::sort(sorted.begin(), sorted.end());
  sorted.erase(std::unique(sorted.begin(), sorted.end()), sorted.end());
  Lock g;
  if (sorted == s_wanted) return;
  s_wanted = sorted;
  std::vector<Entry> next;
  for (const String& id : sorted) {
    Entry* old = findEntry(id.c_str());
    next.push_back(old ? *old : Entry{id, HaEntity()});
  }
  s_store.swap(next);
  s_wantedGen++;
  s_version++;
}

void haSetRawEntities(const char* const* ids, size_t count, HaRawHook hook) {
  RawId* next = count ? (RawId*)heap_caps_calloc(count, sizeof(RawId), MALLOC_CAP_SPIRAM) : nullptr;
  size_t n = 0;
  if (next) {
    for (size_t i = 0; i < count; i++)
      if (strlen(ids[i]) < HA_RAW_ID) strlcpy(next[n++].id, ids[i], HA_RAW_ID);
    qsort(next, n, sizeof(RawId), rawCmp);
    size_t u = 0;
    for (size_t i = 0; i < n; i++)
      if (!u || strcmp(next[u - 1].id, next[i].id)) next[u++] = next[i];
    n = u;
  }
  Lock g;
  s_rawHook = hook;
  if (n == s_rawCount && (!n || !memcmp(next, s_raw, n * sizeof(RawId)))) {
    heap_caps_free(next);
    return;
  }
  heap_caps_free(s_raw);
  s_raw = next;
  s_rawCount = n;
  s_wantedGen++;
}

bool haRegistryLookup(const String& tmpl, uint32_t tag, HaRegDone done) {
  if (!s_lock || !done) return false;
  Lock g;
  if (s_regQueued) return false;
  s_regQueued = new RegJob;
  s_regQueued->tmpl = tmpl;
  s_regQueued->tag = tag;
  s_regQueued->done = done;
  return true;
}

bool haGetEntity(const String& id, HaEntity& out) {
  Lock g;
  Entry* en = findEntry(id.c_str());
  if (!en) return false;
  out = en->e;
  return true;
}

uint32_t haStoreVersion() {
  if (!s_lock) return 0;
  Lock g;
  return s_version;
}

static uint32_t queueService(const String& domain, const String& service, const String& target,
                             const String& dataJson, bool tracked) {
  if (!s_lock) return 0;
  Lock g;
  if (s_link != HA_CONNECTED || s_calls.size() >= MAX_QUEUED_CALLS) return 0;
  uint32_t id = 0;
  if (tracked) {
    for (CallResultSlot& slot : s_results) {
      if (slot.id) continue;
      do { id = ++s_nextTracking; } while (!id);
      slot.id = id;
      slot.ready = false;
      break;
    }
    if (!id) return 0;
  }
  s_calls.push_back({domain, service, target, dataJson, id});
  return tracked ? id : 1;
}

bool haCallService(const String& domain, const String& service, const String& target,
                   const String& dataJson) {
  return queueService(domain, service, target, dataJson, false) != 0;
}

uint32_t haCallServiceTracked(const String& domain, const String& service, const String& target,
                              const String& dataJson) {
  return queueService(domain, service, target, dataJson, true);
}

bool haTakeCallResult(uint32_t id, HaCallResult& result) {
  if (!s_lock || !id) return false;
  Lock g;
  for (CallResultSlot& slot : s_results) {
    if (slot.id != id || !slot.ready) continue;
    result = slot.result;
    slot.id = 0;
    return true;
  }
  return false;
}

bool haTakeFailure(String& entity, String& message) {
  if (!s_lock) return false;
  Lock g;
  if (s_failures.empty()) return false;
  entity = s_failures.front().entity;
  message = s_failures.front().message;
  s_failures.pop_front();
  return true;
}

// --- Entity list for the portal picker ---------------------------------------------
namespace {

const char* const LIST_PATH = "/ha_entities.json";
const char* const LIST_TMP = "/ha_entities.json.tmp";
constexpr size_t MAX_BODY = 4 * 1024 * 1024;

// Entities per template page. HA caps template output at 256 KB (#5); a page
// that still exceeds it is retried at half the size.
#ifndef HA_LIST_PAGE
#define HA_LIST_PAGE 500
#endif
constexpr size_t LIST_PAGE_MIN = 25;

// Rendered by Home Assistant itself, so the device never parses the full
// /api/states JSON: one record per entity, fields split by 0x1F, records by
// 0x1E (neither can appear in a name), sorted, the page after `after`. The
// separators must reach HA as \u001f escapes, because a raw control
// character inside a JSON string is invalid (and ArduinoJson would write it raw).
String listRequest(const String& after, size_t page) {
  String r = "{\"template\":\"{% for s in (states|selectattr('entity_id','>','";
  r += after;
  r += "')|sort(attribute='entity_id'))[:";
  r += String((unsigned)page);
  r += "] %}"
       "{{ s.entity_id }}\\u001f{{ s.name }}\\u001f{{ s.state }}\\u001f"
       "{{ s.attributes.icon|default('') }}\\u001f"
       "{{ s.attributes.unit_of_measurement|default('') }}\\u001e"
       "{% endfor %}\"}";
  return r;
}

// The list goes to flash while it is fetched, never whole into RAM:
// {"updated":epoch,"entities":[...],"count":n}.
struct ListFile {
  File f;
  size_t count = 0;
  bool ok = false;
  bool begin(String& err) {
    count = 0;
    if (!deckFsReady() || !(f = LittleFS.open(LIST_TMP, "w"))) {
      err = "cannot write the entity list to flash";
      return false;
    }
    const time_t now = time(nullptr);
    ok = f.print("{\"updated\":" + String((uint32_t)(now > 1609459200 ? now : 0)) + ",\"entities\":[") > 0;
    return true;
  }
  // objs: comma-separated objects, n of them.
  void add(const String& objs, size_t n) {
    if (!n) return;
    if (count) ok = ok && f.print(',') == 1;
    ok = ok && f.print(objs) == objs.length();
    count += n;
  }
  void abort() {
    if (f) f.close();
    LittleFS.remove(LIST_TMP);
  }
  bool finish(String& err) {
    ok = ok && f.print("],\"count\":" + String((unsigned)count) + "}") > 0;
    f.close();
    if (!ok) {
      LittleFS.remove(LIST_TMP);
      err = "flash is full, the entity list does not fit";
      return false;
    }
    LittleFS.remove(LIST_PATH);
    if (!LittleFS.rename(LIST_TMP, LIST_PATH)) {
      err = "cannot write the entity list to flash";
      return false;
    }
    return true;
  }
};

// Whole response body into a PSRAM buffer (caller frees). Parsing straight
// off the socket reads byte by byte and big answers hit the read timeout.
bool readBody(HTTPClient& http, char*& body, size_t& len, String& err) {
  const int declared = http.getSize();
  size_t cap = declared > 0 ? (size_t)declared + 1 : 256 * 1024;
  if (cap > MAX_BODY) {
    err = "the entity list is too large";
    return false;
  }
  body = (char*)heap_caps_malloc(cap, MALLOC_CAP_SPIRAM);
  if (!body) {
    err = "out of memory";
    return false;
  }
  len = 0;
  WiFiClient* in = http.getStreamPtr();  // nullptr once the server has closed
  uint32_t lastData = millis();
  while (in) {
    if (declared > 0 && len >= (size_t)declared) break;
    const int avail = in->available();
    if (avail > 0) {
      if (len + avail + 1 > cap) {
        size_t ncap = cap * 2;
        if (ncap > MAX_BODY) ncap = MAX_BODY;
        char* nb = ncap > cap ? (char*)heap_caps_realloc(body, ncap, MALLOC_CAP_SPIRAM) : nullptr;
        if (!nb) {
          heap_caps_free(body);
          body = nullptr;
          err = "the entity list is too large";
          return false;
        }
        body = nb;
        cap = ncap;
      }
      const int got = in->read((uint8_t*)body + len, min((size_t)avail, cap - len - 1));
      if (got > 0) {
        len += got;
        lastData = millis();
      }
    } else if (!in->connected()) {
      break;
    } else if (millis() - lastData > 5000) {
      break;  // stalled
    } else {
      vTaskDelay(1);
    }
    esp_task_wdt_reset();
  }
  body[len] = 0;
  if (declared > 0 && len < (size_t)declared) {
    heap_caps_free(body);
    body = nullptr;
    err = "the answer from Home Assistant was cut off";
    return false;
  }
  return true;
}

void appendJsonString(String& o, const char* s, size_t n) {
  o += '"';
  for (size_t i = 0; i < n; i++) {
    const unsigned char c = (unsigned char)s[i];
    if (c == '"' || c == '\\') {
      o += '\\';
      o += (char)c;
    } else if (c < 0x20) {
      char esc[8];
      snprintf(esc, sizeof(esc), "\\u%04x", c);
      o += esc;
    } else {
      o += (char)c;
    }
  }
  o += '"';
}

// Template answer -> {"id","name","state","icon","unit"},... (no brackets);
// last = id of the final record.
void recordsToJson(const char* body, size_t len, String& out, size_t& count, String& last) {
  out = "";
  out.reserve(len + len / 3 + 64);
  count = 0;
  const char* p = body;
  const char* end = body + len;
  static const char* const kKeys[5] = {"id", "name", "state", "icon", "unit"};
  while (p < end) {
    const char* rec = p;
    while (p < end && *p != '\x1e') p++;
    const char* recEnd = p;
    if (p < end) p++;
    const char* f = rec;
    int field = 0;
    bool any = false;
    while (f < recEnd && field < 5) {
      const char* fe = f;
      while (fe < recEnd && *fe != '\x1f') fe++;
      if (field == 0) {
        while (f < fe && (*f == '\n' || *f == '\r' || *f == ' ')) f++;  // template whitespace
        if (f == fe) break;
        if (count) out += ',';
        out += '{';
        any = true;
        last = String(f, fe - f);
      }
      if (field < 3 || fe > f) {  // icon and unit only when set
        if (field) out += ',';
        out += '"';
        out += kKeys[field];
        out += "\":";
        appendJsonString(out, f, fe - f);
      }
      field++;
      f = fe < recEnd ? fe + 1 : fe;
    }
    if (any) {
      out += '}';
      count++;
    }
  }
}

bool openHa(HTTPClient& http, const char* path, String& token, String& err) {
  String url;
  {
    Lock g;
    url = s_url;
    token = s_token;
  }
  if (!url.length() || !token.length()) {
    err = "Home Assistant is not set up";
    return false;
  }
  String host;
  uint16_t port;
  if (!parseUrl(url, host, port, err)) return false;
  http.useHTTP10(true);  // plain body, no chunked framing
  http.setTimeout(8000);
  if (!http.begin("http://" + host + ":" + String(port) + path)) {
    err = "cannot open the connection";
    return false;
  }
  http.addHeader("Authorization", "Bearer " + token);
  return true;
}

// --- Registry lookup (HA task) ---

void regFinish(bool ok, const char* err) {
  RegJob* j = s_reg;
  s_reg = nullptr;
  j->done(j->tag, ok, j->list, ok ? j->count : 0, err);
  heap_caps_free(j->list);
  delete j;
}

// Rendered text in a PSRAM buffer (caller frees).
bool renderTemplate(const String& tmpl, char*& text, size_t& len, String& err) {
  HTTPClient http;
  String token;
  if (!openHa(http, "/api/template", token, err)) return false;
  http.addHeader("Content-Type", "application/json");
  JsonDocument req(psram());
  req["template"] = tmpl;
  String body;
  serializeJson(req, body);
  const int code = http.POST(body);
  if (code != 200) {
    err = code == 401 ? String("token rejected") : String("template answered ") + code;
    http.end();
    return false;
  }
  const bool ok = readBody(http, text, len, err);
  http.end();
  return ok;
}

bool regRender(RegJob& j, String& err) {
  char* text = nullptr;
  size_t len = 0;
  if (!renderTemplate(j.tmpl, text, len, err)) return false;
  size_t lines = 1;
  for (size_t i = 0; i < len; i++) lines += text[i] == '\n';
  j.list = (HaRegEntry*)heap_caps_calloc(lines, sizeof(HaRegEntry), MALLOC_CAP_SPIRAM);
  if (!j.list) {
    heap_caps_free(text);
    err = "out of memory";
    return false;
  }
  for (char* line = strtok(text, "\n"); line; line = strtok(nullptr, "\n")) {
    char* bar = strchr(line, '|');
    if (bar) *bar = 0;
    while (*line == ' ' || *line == '\r') line++;
    // A cut entity id would match the wrong entity: skip it.
    if (!*line || strlen(line) >= sizeof(HaRegEntry::entity)) continue;
    HaRegEntry& e = j.list[j.count++];
    strlcpy(e.entity, line, sizeof(e.entity));
    if (bar) strlcpy(e.extra, bar + 1, sizeof(e.extra));
    for (char* p = e.extra + strlen(e.extra); p > e.extra && (p[-1] == '\r' || p[-1] == ' ');) *--p = 0;
  }
  heap_caps_free(text);
  return true;
}

void regSendBatch() {
  JsonDocument d(psram());
  s_reg->waitId = s_nextId++;
  d["id"] = s_reg->waitId;
  d["type"] = "config/entity_registry/get_entries";
  JsonArray ids = d["entity_ids"].to<JsonArray>();
  for (size_t k = s_reg->next; k < s_reg->count && k < s_reg->next + REG_BATCH; k++)
    ids.add((const char*)s_reg->list[k].entity);
  sendJson(d);
}

void regReply(bool ok, JsonDocument& doc) {
  if (!ok) {
    regFinish(false, doc["error"]["message"] | "registry lookup failed");
    return;
  }
  JsonObjectConst result = doc["result"];
  const size_t end = min(s_reg->count, s_reg->next + REG_BATCH);
  for (size_t k = s_reg->next; k < end; k++) {
    HaRegEntry& e = s_reg->list[k];
    strlcpy(e.uid, result[(const char*)e.entity]["unique_id"] | "", sizeof(e.uid));
  }
  s_reg->next = end;
  if (end >= s_reg->count) regFinish(true, "");
  else regSendBatch();
}

void regStep() {
  if (!s_reg) {
    Lock g;
    s_reg = s_regQueued;
    s_regQueued = nullptr;
  }
  if (!s_reg || s_reg->started) return;
  s_reg->started = true;
  const uint32_t t0 = millis();
  String err;
  if (!regRender(*s_reg, err)) {
    regFinish(false, err.c_str());
    return;
  }
  Serial.printf("HA: registry lookup, %u entities (template %u ms)\n", (unsigned)s_reg->count,
                (unsigned)(millis() - t0));
  if (!s_reg->count) regFinish(true, "");
  else regSendBatch();
}

// ISO timestamps are UTC or carry an explicit offset; mktime would use local TZ.
bool historyEpoch(const char* s, time_t& epoch) {
  int y, m, d, hh, mm, ss, n = 0;
  if (sscanf(s, "%4d-%2d-%2dT%2d:%2d:%2d%n", &y, &m, &d, &hh, &mm, &ss, &n) != 6 ||
      y < 1970 || m < 1 || m > 12 || d < 1 || d > 31 || hh < 0 || hh > 23 ||
      mm < 0 || mm > 59 || ss < 0 || ss > 59) return false;
  static const int monthDays[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
  const bool leap = y % 4 == 0 && (y % 100 != 0 || y % 400 == 0);
  if (d > monthDays[m - 1] + (m == 2 && leap ? 1 : 0)) return false;
  const char* p = s + n;
  if (*p == '.') { p++; if (!isdigit(*p)) return false; while (isdigit(*p)) p++; }
  int offset = 0;
  if (*p == 'Z' && !p[1]) { p++; }
  else if (*p == '+' || *p == '-') {
    const int sign = *p++ == '+' ? 1 : -1;
    int oh, om, used = 0;
    if (sscanf(p, "%2d:%2d%n", &oh, &om, &used) != 2 || p[used] ||
        oh < 0 || oh > 23 || om < 0 || om > 59) return false;
    offset = sign * (oh * 3600 + om * 60);
    p += used;
  } else return false;
  if (*p) return false;
  y -= m <= 2;
  const int era = y / 400, yo = y - era * 400;
  const int doy = (153 * (m + (m > 2 ? -3 : 9)) + 2) / 5 + d - 1;
  const int days = era * 146097 + yo * 365 + yo / 4 - yo / 100 + doy - 719468;
  epoch = (time_t)((int64_t)days * 86400 + hh * 3600 + mm * 60 + ss - offset);
  return true;
}

String historyIso(time_t epoch) {
  struct tm utc;
  gmtime_r(&epoch, &utc);
  char text[24];
  strftime(text, sizeof(text), "%Y-%m-%dT%H:%M:%SZ", &utc);
  return String(text);
}

String historyEscape(const String& text) {
  String out;
  for (size_t i = 0; i < text.length(); i++) {
    const unsigned char c = text[i];
    if (isalnum(c) || c == '_' || c == '.' || c == '-') out += (char)c;
    else { char hex[4]; snprintf(hex, sizeof(hex), "%%%02X", c); out += hex; }
  }
  return out;
}

// A reply can run to megabytes (a power sensor over a week), so it is parsed
// one state at a time off the socket through a small buffer.
struct HistoryStream {
  WiFiClient* in;
  uint32_t deadline;
  bool feedWdt = false;  // loop task only: other tasks are not subscribed
  bool timedOut = false;
  int back = -1;
  size_t pos = 0, len = 0;
  uint8_t buf[512];
  int read() {
    if (back >= 0) {
      const int c = back;
      back = -1;
      return c;
    }
    while (pos >= len) {
      if (!in) return -1;  // getStreamPtr() after the server closed
      if (feedWdt) esp_task_wdt_reset();
      if ((int32_t)(millis() - deadline) >= 0) {
        timedOut = true;
        return -1;
      }
      const int avail = in->available();
      if (avail > 0) {
        const int got = in->read(buf, min((size_t)avail, sizeof(buf)));
        if (got > 0) { len = got; pos = 0; }
      } else if (!in->connected()) {
        return -1;
      } else {
        vTaskDelay(1);
      }
    }
    return buf[pos++];
  }
  size_t readBytes(char* out, size_t n) {
    size_t i = 0;
    for (int c; i < n && (c = read()) >= 0; i++) out[i] = (char)c;
    return i;
  }
  int next() {
    int c;
    do c = read();
    while (c == ' ' || c == '\n' || c == '\r' || c == '\t');
    return c;
  }
};

// slow: the reply did not arrive in time (too much history), retry much later.
bool fetchHistory(const HaHistoryKey& key, time_t now, HistoryData& out, String& err, bool& slow) {
  const time_t start = now - key.hours * 3600;
  clearHistory(out, now, NAN);
  HTTPClient http;
  String token;
  const String path = "/api/history/period/" + historyIso(start) + "?filter_entity_id=" +
                      historyEscape(key.entity) + "&end_time=" + historyIso(now) +
                      "&minimal_response&no_attributes";
  if (!openHa(http, path.c_str(), token, err)) return false;
  http.setConnectTimeout(3000);
  const int code = http.GET();
  if (code != 200) { err = "HTTP " + String(code); http.end(); return false; }
  HistoryStream s{http.getStreamPtr(), millis() + 20000};
  time_t at = start;
  float value = NAN;
  const int width = key.hours * 3600 / HA_HISTORY_POINTS;
  auto hold = [&](time_t until) {
    until = min(now, until);
    while (at < until) {
      const int i = min(HA_HISTORY_POINTS - 1, (int)((at - start) / width));
      const time_t to = min(until, start + (i + 1) * width);
      addHistory(out, i, value, (float)(to - at));
      at = to;
    }
  };
  JsonDocument filter(psram()), doc(psram());
  filter["state"] = true;
  filter["last_changed"] = true;
  // [[{...}, {...}]], or [] when the entity has no history.
  bool valid = s.next() == '[';
  int c = valid ? s.next() : -1;
  if (c != ']') {
    valid = valid && c == '[';
    c = valid ? s.next() : -1;
    time_t previous = 0;
    unsigned records = 0;
    while (valid && c != ']') {
      s.back = c;
      if (deserializeJson(doc, s, DeserializationOption::Filter(filter))) { valid = false; break; }
      time_t stamp;
      if (!historyEpoch(doc["last_changed"] | "", stamp) || (previous && stamp < previous)) {
        valid = false;
        break;
      }
      previous = stamp;
      if (++records % 128 == 0) vTaskDelay(1);
      if (stamp <= now) {
        if (stamp > start) hold(stamp);
        haNumericState(String(doc["state"] | ""), value);
      }
      c = s.next();
      if (c == ',') c = s.next();
      else if (c != ']') valid = false;
    }
  }
  http.end();
  if (!valid) {
    slow = s.timedOut;
    err = slow ? "history timed out" : "bad history reply";
    return false;
  }
  hold(now);
  return true;
}

void historyTask(void*) {
  size_t next = 0;
  for (;;) {
    HaHistoryKey key;
    uint32_t id = 0, request = 0, credentials = 0;
    const time_t now = time(nullptr);
    {
      Lock g;
      if (s_link == HA_CONNECTED && now >= 1609459200) {
        for (size_t n = 0; n < s_history.size(); n++) {
          const size_t i = (next + n) % s_history.size();
          History* h = s_history[i];
          if (h->due && (int32_t)(millis() - h->due) < 0) continue;
          next = (i + 1) % s_history.size();
          key = h->key;
          id = h->id;
          request = h->request;
          credentials = s_credGen;
          clearHistory(h->tail, now, h->data.live);
          h->fetching = true;
          break;
        }
      }
    }
    if (!id) { vTaskDelay(pdMS_TO_TICKS(250)); continue; }
    // The reply lands on core 0, where the compositor's helper builds frames.
    for (int i = 0; i < 100 && (compMode() == COMP_ANIM || compMode() == COMP_DRAG); i++)
      vTaskDelay(pdMS_TO_TICKS(20));
    HistoryData* result = (HistoryData*)heap_caps_malloc(sizeof(HistoryData), MALLOC_CAP_SPIRAM);
    String err;
    bool slow = false;
    const bool ok = result && fetchHistory(key, now, *result, err, slow);
    if (!result) err = "out of memory";
    {
      Lock g;
      History* h = findHistory(key.entity, key.hours);
      if (h && h->id == id) {
        historyLive(time(nullptr));
        h->fetching = false;
        if (h->request == request && s_credGen == credentials) {
          h->due = millis() + (ok || slow ? 15 * 60 * 1000 : 60 * 1000);
          if (ok) {
            shiftHistory(*result, h->tail.end, key.hours * 3600 / HA_HISTORY_POINTS);
            for (int i = 0; i < HA_HISTORY_POINTS; i++) {
              addHistory(*result, i, h->tail.value[i], h->tail.weight[i]);
              if (!isfinite(h->tail.low[i])) continue;
              result->low[i] = min(result->low[i], h->tail.low[i]);
              result->high[i] = max(result->high[i], h->tail.high[i]);
            }
            result->cursor = h->tail.cursor;
            result->live = h->tail.live;
            h->data = *result;
            h->version = ++s_histVersion;
          }
        }
      }
    }
    heap_caps_free(result);
    if (!ok) Serial.printf("HA: history %s (%uh) failed: %s\n", key.entity.c_str(), key.hours, err.c_str());
    vTaskDelay(pdMS_TO_TICKS(20));
  }
}

// One template page. code = HTTP status, 0 when the request never got one.
bool templatePage(const String& after, size_t page, String& objs, size_t& n, String& last, int& code,
                  String& err) {
  HTTPClient http;
  String token;
  code = 0;
  if (!openHa(http, "/api/template", token, err)) return false;
  http.addHeader("Content-Type", "application/json");
  code = http.POST(listRequest(after, page));
  if (code != 200) {
    err = code == 401 ? String("token rejected") : String("template answered ") + code;
    if (code > 0) err += ": " + http.getString().substring(0, 160);
    http.end();
    return false;
  }
  char* body = nullptr;
  size_t len = 0;
  const bool ok = readBody(http, body, len, err);
  http.end();
  if (!ok) return false;
  recordsToJson(body, len, objs, n, last);
  heap_caps_free(body);
  return true;
}

bool fetchViaTemplate(ListFile& lf, String& err) {
  String after, objs, last;
  size_t page = HA_LIST_PAGE;
  for (unsigned pages = 0; pages < 1000; pages++) {
    size_t n = 0;
    int code;
    if (!templatePage(after, page, objs, n, last, code, err)) {
      if (code == 400 && page / 2 >= LIST_PAGE_MIN) {
        page /= 2;
        Serial.printf("HA: template page refused (%s), %u per page\n", err.c_str(), (unsigned)page);
        continue;
      }
      return false;
    }
    lf.add(objs, n);
    esp_task_wdt_reset();
    if (n < page) return true;
    // The id goes back into the template as a quoted string.
    if (last <= after || last.indexOf('\'') >= 0 || last.indexOf('\\') >= 0) {
      err = "unexpected entity id " + last;
      return false;
    }
    after = last;
  }
  err = "the entity list does not end";
  return false;
}

// Fallback when the template endpoint is not available to this token.
// Parsed one entity at a time off the socket: a whole big /api/states in one
// document took over 30 s (ArduinoJson deduplicates strings linearly) and
// tripped the loop watchdog (#5).
bool fetchViaStates(ListFile& lf, String& err) {
  HTTPClient http;
  String token;
  if (!openHa(http, "/api/states", token, err)) return false;
  const int code = http.GET();
  if (code != 200) {
    err = code == 401 ? String("token rejected") : String("Home Assistant answered ") + code;
    http.end();
    return false;
  }
  HistoryStream s{http.getStreamPtr(), millis() + 60000};
  s.feedWdt = true;
  JsonDocument filter(psram()), doc(psram());
  filter["entity_id"] = true;
  filter["state"] = true;
  filter["attributes"]["friendly_name"] = true;
  filter["attributes"]["icon"] = true;
  filter["attributes"]["unit_of_measurement"] = true;
  String objs;
  size_t n = 0;
  bool valid = s.next() == '[';
  int c = valid ? s.next() : -1;
  while (valid && c != ']') {
    s.back = c;
    if (deserializeJson(doc, s, DeserializationOption::Filter(filter))) {
      valid = false;
      break;
    }
    const char* id = doc["entity_id"] | "";
    const char* name = doc["attributes"]["friendly_name"] | "";
    const char* state = doc["state"] | "";
    if (n) objs += ',';
    objs += "{\"id\":";
    appendJsonString(objs, id, strlen(id));
    objs += ",\"name\":";
    appendJsonString(objs, name, strlen(name));
    objs += ",\"state\":";
    appendJsonString(objs, state, strlen(state));
    const char* icon = doc["attributes"]["icon"] | "";
    if (*icon) {
      objs += ",\"icon\":";
      appendJsonString(objs, icon, strlen(icon));
    }
    const char* unit = doc["attributes"]["unit_of_measurement"] | "";
    if (*unit) {
      objs += ",\"unit\":";
      appendJsonString(objs, unit, strlen(unit));
    }
    objs += '}';
    if (++n == 64) {
      lf.add(objs, n);
      objs = "";
      n = 0;
      vTaskDelay(1);
    }
    c = s.next();
    if (c == ',') c = s.next();
    else if (c != ']') valid = false;
  }
  http.end();
  if (!valid) {
    err = s.timedOut ? "Home Assistant answered too slowly" : "bad answer from Home Assistant";
    return false;
  }
  lf.add(objs, n);
  return true;  // unsorted; the portal sorts
}

}  // namespace

bool haNumericState(const String& state, float& value) {
  char* end = nullptr;
  value = strtof(state.c_str(), &end);
  if (end != state.c_str() && end && !*end && isfinite(value)) return true;
  value = NAN;
  return false;
}

void haSetHistory(const std::vector<HaHistoryKey>& keys) {
  Lock g;
  bool changed = false;
  for (History* h : s_history) {
    bool wanted = false;
    for (const HaHistoryKey& key : keys)
      wanted = wanted || (h->key.entity == key.entity && h->key.hours == constrain(key.hours, 1, 168));
    changed = changed || (h->configured != wanted);
    h->configured = false;
  }
  for (const HaHistoryKey& key : keys) {
    changed = changed || !findHistory(key.entity, constrain(key.hours, 1, 168));
    History* h = ensureHistory(key.entity, constrain(key.hours, 1, 168));
    if (h) h->configured = true;
  }
  pruneHistory();
  if (changed) for (History* h : s_history) { h->due = 0; h->request++; }
  historyLive(time(nullptr));
  startHistoryTask();
}

void haDetailHistory(const String& entity, uint8_t hours) {
  if (!s_lock) return;
  Lock g;
  History* existing = findHistory(entity, constrain(hours, 1, 168));
  if (existing && existing->detail) return;
  for (History* h : s_history) h->detail = false;
  History* h = ensureHistory(entity, constrain(hours, 1, 168));
  if (h) h->detail = true;
  pruneHistory();
  historyLive(time(nullptr));
  startHistoryTask();
}

bool haCopyHistory(const String& entity, uint8_t hours, uint32_t& version, float* points,
                   float& low, float& high) {
  Lock g;
  History* h = findHistory(entity, hours);
  if (!h || !h->version || h->version == version) return false;
  memcpy(points, h->data.value, sizeof(h->data.value));
  low = high = NAN;
  for (int i = 0; i < HA_HISTORY_POINTS; i++) {
    if (!isfinite(h->data.low[i])) continue;
    low = isnan(low) ? h->data.low[i] : min(low, h->data.low[i]);
    high = isnan(high) ? h->data.high[i] : max(high, h->data.high[i]);
  }
  version = h->version;
  return true;
}

uint32_t haHistoryVersion() {
  Lock g;
  return s_histVersion;
}

const char* haEntityListPath() { return LIST_PATH; }

String haBaseUrl() {
  String url, host, err;
  uint16_t port;
  if (!s_lock) return "";
  {
    Lock g;
    url = s_url;
  }
  if (!url.length() || !parseUrl(url, host, port, err)) return "";
  return "http://" + host + ":" + String(port);
}

bool haEndpoint(String& host, uint16_t& port, String& token, String& err) {
  String url;
  if (s_lock) {
    Lock g;
    url = s_url;
    token = s_token;
  }
  if (!url.length() || !token.length()) {
    err = "Home Assistant is not set up";
    return false;
  }
  return parseUrl(url, host, port, err);
}

bool haRenderTemplate(const String& tmpl, String& out, String& err) {
  char* text = nullptr;
  size_t len = 0;
  if (!renderTemplate(tmpl, text, len, err)) return false;
  out = text;
  heap_caps_free(text);
  return true;
}

bool haRefreshEntityList(String& err) {
  const uint32_t t0 = millis();
  ListFile lf;
  if (!lf.begin(err)) return false;
  String why;
  if (!fetchViaTemplate(lf, why)) {
    Serial.printf("HA: template list failed (%s), falling back to /api/states\n", why.c_str());
    lf.abort();
    if (!lf.begin(err)) return false;
    if (!fetchViaStates(lf, err)) {
      lf.abort();
      return false;
    }
  }
  const size_t count = lf.count;
  if (!lf.finish(err)) return false;
  File f = LittleFS.open(LIST_PATH, "r");
  Serial.printf("HA: entity list updated, %u entities, %u bytes, %u ms\n", (unsigned)count,
                f ? (unsigned)f.size() : 0, (unsigned)(millis() - t0));
  return true;
}

}  // namespace deck
