// Deck UI: toast, detail card, confirm card and the PC pairing card.
#include "deck_ui_int.h"
#include "deck_daily.h"
#include <src/misc/cache/instance/lv_image_cache.h>

namespace deckui {

// --- Toast and detail card ------------------------------------------------------------
lv_obj_t* s_toast = nullptr;
lv_obj_t* s_modalScrim = nullptr;
lv_obj_t* s_modalCard = nullptr;
lv_draw_buf_t* s_modalGlass = nullptr;  // Glass theme: the card's frosted background
int s_modalTile = -1;
lv_obj_t* s_modalState = nullptr;
lv_obj_t* s_modalBtnLbl = nullptr;
lv_obj_t* s_modalSlider = nullptr;
lv_obj_t* s_modalIcon = nullptr;
uint32_t s_modalIconCp = 0;
lv_obj_t* s_modalChart = nullptr;
lv_obj_t* s_modalRange = nullptr;
lv_chart_series_t* s_modalSeries = nullptr;
int32_t* s_modalPoints = nullptr;
uint32_t s_modalHistoryVersion = 0;
uint8_t s_modalHours = 24;
float s_modalMin = NAN, s_modalMax = NAN;
bool s_modalBuilding = false;  // no history request before the open animation runs
// Confirm dialog (shares the card slot): which action waits, the tile state it
// was asked for, and the auto-cancel timer.
int8_t s_confirmHold = -1;  // -1 = the card is a detail card
bool s_confirmOn = false;
uint32_t s_confirmMs = 0;
lv_timer_t* s_confirmTimer = nullptr;
constexpr uint32_t CONFIRM_TIMEOUT_MS = 8000;
constexpr uint32_t CONFIRM_ARM_MS = 400;  // a stray second tap must not confirm

bool modalShown() { return s_modalCard != nullptr; }

// The page under a card, dimmed like the scrim, as an opaque picture on top of
// the screen: LVGL skips the page under it while the card is open.
lv_obj_t* s_modalUnder = nullptr;
lv_draw_buf_t* s_underBuf = nullptr;  // kept once used

// The cover's picture: the last frame at half brightness, as the compositor dims.
void coverFill() {
  if (!s_underBuf) return;
  const int w = logicalW(), h = logicalH();
  const uint16_t* fb = lastFrame();
  for (int y = 0; y < h; y++) {
    uint16_t* d = (uint16_t*)(s_underBuf->data + y * s_underBuf->header.stride);
    const uint16_t* s = fb + y * w;
    for (int x = 0; x < w; x++) d[x] = (s[x] >> 1) & 0x7BEF;
  }
}

// Only with no card open; the next card allocates it again.
void cardUnderFree() {
  if (s_modalUnder || !s_underBuf) return;
  lv_image_cache_drop(s_underBuf);
  lv_draw_buf_destroy(s_underBuf);
  s_underBuf = nullptr;
}

// fill false: the caller runs coverFill before LVGL draws again.
bool coverPage(bool fill) {
  const int w = logicalW(), h = logicalH();
  if (s_underBuf && (s_underBuf->header.w != w || s_underBuf->header.h != h)) {
    lv_draw_buf_destroy(s_underBuf);
    s_underBuf = nullptr;
  }
  if (!s_underBuf) s_underBuf = lv_draw_buf_create(w, h, LV_COLOR_FORMAT_RGB565, 0);
  if (!s_underBuf) return false;
  lv_image_cache_drop(s_underBuf);
  if (fill) coverFill();
  s_modalUnder = lv_image_create(lv_screen_active());
  lv_obj_add_flag(s_modalUnder, (lv_obj_flag_t)(LV_OBJ_FLAG_IGNORE_LAYOUT | LV_OBJ_FLAG_FLOATING));
  lv_obj_remove_flag(s_modalUnder, (lv_obj_flag_t)(LV_OBJ_FLAG_CLICKABLE | LV_OBJ_FLAG_SCROLLABLE));
  lv_obj_set_pos(s_modalUnder, 0, 0);
  lv_image_set_src(s_modalUnder, s_underBuf);
  // An image alone never reports "covers": the opaque background does.
  lv_obj_set_style_bg_color(s_modalUnder, lv_color_black(), 0);
  lv_obj_set_style_bg_opa(s_modalUnder, LV_OPA_COVER, 0);
  return true;
}

void onModalScrim(lv_event_t*);

// The scrim for a card: transparent over the covered page, else half black.
lv_obj_t* makeScrim(bool fill = true) {
  lv_obj_t* s = lv_obj_create(lv_layer_top());
  lv_obj_remove_style_all(s);
  lv_obj_set_size(s, logicalW(), logicalH());
  lv_obj_set_style_bg_color(s, lv_color_black(), 0);
  lv_obj_set_style_bg_opa(s, coverPage(fill) ? LV_OPA_TRANSP : LV_OPA_50, 0);
  lv_obj_add_event_cb(s, onModalScrim, LV_EVENT_CLICKED, nullptr);
  return s;
}

// Thin line on the top edge while daily pictures download: swipes may hitch then.
lv_obj_t* s_dailyBar = nullptr;
lv_obj_t* s_dailyPill = nullptr;  // "Daily pictures 3 of 20, tap to skip"

void dailySkipTap(lv_event_t*) {
  deck::dailySkip();
  hapticTap();
}

void dailyBarSync() {
  int done = 0, total = 0;
  if (!deck::dailyProgress(done, total) || !total) {
    if (s_dailyBar) lv_obj_add_flag(s_dailyBar, LV_OBJ_FLAG_HIDDEN);
    if (s_dailyPill) lv_obj_add_flag(s_dailyPill, LV_OBJ_FLAG_HIDDEN);
    return;
  }
  // Home Assistant and MQTT are paused meanwhile: say why, and offer a way out.
  if (!s_dailyPill) {
    s_dailyPill = lv_obj_create(lv_layer_top());
    lv_obj_remove_style_all(s_dailyPill);
    lv_obj_set_size(s_dailyPill, LV_SIZE_CONTENT, LV_SIZE_CONTENT);
    lv_obj_set_style_bg_color(s_dailyPill, lv_color_hex(0x2A2F38), 0);
    lv_obj_set_style_bg_opa(s_dailyPill, LV_OPA_COVER, 0);
    lv_obj_set_style_radius(s_dailyPill, LV_RADIUS_CIRCLE, 0);
    lv_obj_set_style_pad_hor(s_dailyPill, 14, 0);
    lv_obj_set_style_pad_ver(s_dailyPill, 7, 0);
    lv_obj_set_style_text_color(s_dailyPill, lv_color_hex(0xE6E8EC), 0);
    lv_obj_add_event_cb(s_dailyPill, dailySkipTap, LV_EVENT_CLICKED, nullptr);
    lv_label_create(s_dailyPill);
  }
  char text[64];
  snprintf(text, sizeof(text), "Daily pictures %d of %d, tap to skip", std::min(done + 1, total), total);
  lv_obj_t* label = lv_obj_get_child(s_dailyPill, 0);
  if (strcmp(lv_label_get_text(label), text)) lv_label_set_text(label, text);
  lv_obj_align(s_dailyPill, LV_ALIGN_TOP_MID, 0, 8);
  if (lv_obj_has_flag(s_dailyPill, LV_OBJ_FLAG_HIDDEN)) {
    lv_obj_remove_flag(s_dailyPill, LV_OBJ_FLAG_HIDDEN);
    lv_obj_move_foreground(s_dailyPill);
  }
  if (!s_dailyBar) {
    s_dailyBar = lv_obj_create(lv_layer_top());
    lv_obj_remove_style_all(s_dailyBar);
    lv_obj_set_style_bg_color(s_dailyBar, lv_color_hex(C_OK), 0);
    lv_obj_set_style_bg_opa(s_dailyBar, LV_OPA_80, 0);
    lv_obj_remove_flag(s_dailyBar, LV_OBJ_FLAG_CLICKABLE);
  }
  // Half a step for the picture in progress, so the line moves from the start.
  lv_obj_set_size(s_dailyBar, std::max(6, logicalW() * (2 * done + 1) / (2 * total)), 3);
  lv_obj_set_pos(s_dailyBar, 0, 0);
  lv_obj_remove_flag(s_dailyBar, LV_OBJ_FLAG_HIDDEN);
}

void setModalOpen(bool open) {
  portENTER_CRITICAL(&s_mux);
  sh.modalOpen = open;
  portEXIT_CRITICAL(&s_mux);
}

void toastOpa(void* obj, int32_t v) { lv_obj_set_style_opa((lv_obj_t*)obj, (lv_opa_t)v, 0); }
void toastDone(lv_anim_t* a) {
  if (lv_obj_get_style_opa((lv_obj_t*)a->var, LV_PART_MAIN) == LV_OPA_TRANSP)
    lv_obj_add_flag((lv_obj_t*)a->var, LV_OBJ_FLAG_HIDDEN);
}

void deckToastShow(const char* text, uint32_t holdMs) {
  if (!s_toast) {
    s_toast = lv_obj_create(lv_layer_top());
    lv_obj_remove_style_all(s_toast);
    lv_obj_set_size(s_toast, LV_SIZE_CONTENT, LV_SIZE_CONTENT);
    lv_obj_set_style_bg_color(s_toast, lv_color_hex(0x2A2F38), 0);
    lv_obj_set_style_bg_opa(s_toast, LV_OPA_COVER, 0);
    lv_obj_set_style_radius(s_toast, LV_RADIUS_CIRCLE, 0);
    lv_obj_set_style_pad_hor(s_toast, 16, 0);
    lv_obj_set_style_pad_ver(s_toast, 9, 0);
    lv_obj_set_style_text_color(s_toast, lv_color_hex(0xE6E8EC), 0);  // dark pill on both themes
    lv_obj_remove_flag(s_toast, LV_OBJ_FLAG_CLICKABLE);
    lv_label_create(s_toast);
  }
  lv_obj_t* label = lv_obj_get_child(s_toast, 0);
  lv_label_set_long_mode(label, LV_LABEL_LONG_WRAP);
  lv_obj_set_style_max_width(label, logicalW() - 40 - 32, 0);
  lv_label_set_text(label, text);
  // Above the page dots, which the flush task draws at the very bottom.
  lv_obj_align(s_toast, LV_ALIGN_BOTTOM_MID, 0, -34);
  lv_obj_remove_flag(s_toast, LV_OBJ_FLAG_HIDDEN);
  lv_obj_move_foreground(s_toast);  // above cards and the editor made after it
  lv_anim_delete(s_toast, toastOpa);
  lv_anim_t in;
  lv_anim_init(&in);
  lv_anim_set_var(&in, s_toast);
  lv_anim_set_exec_cb(&in, toastOpa);
  lv_anim_set_values(&in, lv_obj_get_style_opa(s_toast, LV_PART_MAIN), LV_OPA_COVER);
  lv_anim_set_duration(&in, 120);
  lv_anim_start(&in);
  lv_anim_t out;
  lv_anim_init(&out);
  lv_anim_set_var(&out, s_toast);
  lv_anim_set_exec_cb(&out, toastOpa);
  lv_anim_set_values(&out, LV_OPA_COVER, LV_OPA_TRANSP);
  lv_anim_set_delay(&out, 120 + holdMs);
  lv_anim_set_duration(&out, 250);
  lv_anim_set_completed_cb(&out, toastDone);
  lv_anim_start(&out);
}

// --- Climate controls on the detail card ---------------------------------------------
// +/- move the setpoint the card shows at once; the call goes out once the
// taps stop, so five taps are one set_temperature. The asked value stays on
// the card until Home Assistant reports it or CLIMATE_SETTLE_MS pass.
bool s_climate = false;
lv_obj_t* s_climMinus = nullptr;
lv_obj_t* s_climPlus = nullptr;
lv_obj_t* s_climInfo = nullptr;
std::vector<lv_obj_t*> s_climModeBtns;
std::vector<String> s_climModes;
float s_climWant = NAN, s_climWantHigh = NAN;  // high: heat_cool range only
bool s_climSent = false;
lv_timer_t* s_climTimer = nullptr;
String s_climModeWant;
uint32_t s_climModeMs = 0;
constexpr uint32_t CLIMATE_SEND_MS = 700;
constexpr uint32_t CLIMATE_SETTLE_MS = 5000;

void climateCallFailed() {
  deckToastShow(haLink() == HA_CONNECTED ? "Home Assistant is busy, try again" :
                                        "Home Assistant is offline", 1800);
}

bool modalTileOk() { return s_modalTile >= 0 && s_modalTile < (int)s_tiles.size(); }
const String& modalEntity() { return s_tiles[s_modalTile].def->entity; }

float climateStep(const HaEntity& e) { return e.tempStep > 0 ? e.tempStep : 0.5f; }

float climateClamp(const HaEntity& e, float v) {
  const float step = climateStep(e);
  v = roundf(v / step) * step;
  if (isfinite(e.tempMin) && v < e.tempMin) v = e.tempMin;
  if (isfinite(e.tempMax) && v > e.tempMax) v = e.tempMax;
  return v;
}

bool climateHasSetpoint(const HaEntity& e) {
  return e.known && e.state != "off" && e.state != "unavailable" && e.state != "unknown" &&
         (isfinite(e.target) || climateRange(e));
}

bool climateAdjust(const HaEntity& e, int detents, float& low, float& high) {
  if (!climateRange(e)) {
    const float base = isfinite(low) ? low : e.target;
    low = climateClamp(e, base + climateStep(e) * detents);
    high = NAN;
    return true;
  }

  float lo = isfinite(low) ? low : e.targetLow;
  float hi = isfinite(high) ? high : e.targetHigh;
  const int dir = detents > 0 ? 1 : -1;
  const float step = climateStep(e) * dir;
  bool moved = false;
  // Move the range together and stop at either limit.
  for (; detents; detents -= dir) {
    if ((isfinite(e.tempMin) && lo + step < e.tempMin) || (isfinite(e.tempMax) && hi + step > e.tempMax)) break;
    low = climateClamp(e, lo + step);
    high = climateClamp(e, hi + step);
    moved = true;
    if (low == lo && high == hi) break;
    lo = low;
    hi = high;
  }
  return moved;
}

void climateWantClear() {
  s_climWant = s_climWantHigh = NAN;
  s_climSent = false;
  if (s_climTimer) lv_timer_delete(s_climTimer);
  s_climTimer = nullptr;
}

bool climateSendTemperature(const String& entity, float low, float high) {
  char data[80];
  char a[16], b[16];
  snprintf(a, sizeof a, "%.4g", low);
  if (isfinite(high)) {
    snprintf(b, sizeof b, "%.4g", high);
    snprintf(data, sizeof data, "{\"target_temp_low\":%s,\"target_temp_high\":%s}", a, b);
  } else {
    snprintf(data, sizeof data, "{\"temperature\":%s}", a);
  }
  if (haCallService("climate", "set_temperature", entity, data)) return true;
  climateCallFailed();
  return false;
}

void onClimateTimer(lv_timer_t*) {
  s_climTimer = nullptr;  // one-shot: it deletes itself
  if (!modalTileOk() || !s_climate || !isfinite(s_climWant)) return;
  if (s_climSent) {  // Home Assistant never reported it: show what it has
    climateWantClear();
    refreshModal();
    return;
  }
  if (!climateSendTemperature(modalEntity(), s_climWant, s_climWantHigh)) {
    climateWantClear();
    refreshModal();
    return;
  }
  s_climSent = true;
  s_climTimer = lv_timer_create(onClimateTimer, CLIMATE_SETTLE_MS, nullptr);
  lv_timer_set_repeat_count(s_climTimer, 1);
}

void climateArm(uint32_t ms) {
  if (s_climTimer) lv_timer_delete(s_climTimer);
  s_climTimer = lv_timer_create(onClimateTimer, ms, nullptr);
  lv_timer_set_repeat_count(s_climTimer, 1);
}

void onClimateStep(lv_event_t* ev) {
  if (!modalTileOk() || !s_climate) return;
  const int dir = (int)(intptr_t)lv_event_get_user_data(ev);
  HaEntity e;
  if (!haGetEntity(modalEntity(), e) || !climateHasSetpoint(e)) return;
  if (!climateAdjust(e, dir, s_climWant, s_climWantHigh)) return;
  s_climSent = false;
  climateArm(CLIMATE_SEND_MS);
  refreshModal();
}

void onClimateMode(lv_event_t* ev) {
  if (!modalTileOk() || !s_climate) return;
  const size_t i = (size_t)(intptr_t)lv_event_get_user_data(ev);
  if (i >= s_climModes.size()) return;
  const String& mode = s_climModes[i];
  if (!haCallService("climate", "set_hvac_mode", modalEntity(), "{\"hvac_mode\":\"" + mode + "\"}")) {
    climateCallFailed();
    return;
  }
  climateWantClear();  // the setpoint may change with the mode
  s_climModeWant = mode;
  s_climModeMs = millis();
  refreshModal();
}

// A setpoint still waiting for its call goes out when the card closes.
void climateClose() {
  if (s_climate && modalTileOk() && isfinite(s_climWant) && !s_climSent)
    climateSendTemperature(modalEntity(), s_climWant, s_climWantHigh);
  climateWantClear();
  s_climate = false;
  s_climMinus = s_climPlus = s_climInfo = nullptr;
  s_climModeBtns.clear();
  s_climModes.clear();
  s_climModeWant = "";
}

void climateRefresh(const HaEntity* e) {
  const bool known = e != nullptr;
  // The asked setpoint has arrived: drop it, Home Assistant's own is the same.
  if (known && s_climSent && isfinite(s_climWant)) {
    const float tol = climateStep(*e) / 2;
    const bool same = isfinite(s_climWantHigh)
        ? fabsf(e->targetLow - s_climWant) < tol && fabsf(e->targetHigh - s_climWantHigh) < tol
        : fabsf(e->target - s_climWant) < tol;
    if (same) climateWantClear();
  }
  if (s_climModeWant.length() &&
      ((known && e->state == s_climModeWant) || millis() - s_climModeMs >= CLIMATE_SETTLE_MS))
    s_climModeWant = "";
  const bool setpoint = known && climateHasSetpoint(*e);
  float low = NAN, high = NAN;
  const char* mode = "";
#if BOARD_HAS_ENCODER
  if (known) encoderClimatePreview(modalEntity(), low, high, mode);
#endif
  if (isfinite(s_climWant)) {
    low = s_climWant;
    high = s_climWantHigh;
  } else if (!setpoint) {
    low = NAN;
  }
  String big;
  if (!known || !e->known || e->state == "unavailable" || e->state == "unknown") big = "Unavailable";
  else if (isfinite(low)) {
    if (isfinite(high)) {
      char lo[16];
      formatReading(low, lo, sizeof lo);
      big = String(lo) + "-" + formatTemp(high);
    } else big = formatTemp(low);
  } else if (setpoint) big = climateTarget(*e);
  else big = climateWord(e->state);
  lv_label_set_text(s_modalState, big.c_str());
  for (lv_obj_t* b : {s_climMinus, s_climPlus}) {
    if (setpoint) lv_obj_remove_state(b, LV_STATE_DISABLED);
    else lv_obj_add_state(b, LV_STATE_DISABLED);
  }
  // "Now 20.5°  ·  Heating"
  String info;
  if (known && isfinite(e->current)) info = "Now " + formatTemp(e->current);
  if (known && e->hvacAction.length()) {
    if (info.length()) info += "  \xE2\x80\xA2  ";
    info += climateWord(e->hvacAction);
  }
  lv_label_set_text(s_climInfo, info.c_str());
  if (s_climModeWant.length()) mode = s_climModeWant.c_str();
  else if (!*mode && known) mode = e->state.c_str();
  for (size_t i = 0; i < s_climModeBtns.size(); i++) {
    if (s_climModes[i] == mode) lv_obj_add_state(s_climModeBtns[i], LV_STATE_CHECKED);
    else lv_obj_remove_state(s_climModeBtns[i], LV_STATE_CHECKED);
  }
}

// Builds the climate part of the card from y; returns the height it took.
int climateBuild(lv_obj_t* c, int cw, int y, uint32_t accent, const HaEntity* e) {
  s_climate = true;
  constexpr int BTN = 52;
  auto stepButton = [&](int x, const char* sym, int dir) {
    lv_obj_t* b = qpButton(c, x, y, BTN, sym, false);
    lv_obj_set_height(b, BTN);
    lv_obj_set_style_radius(b, LV_RADIUS_CIRCLE, 0);
    lv_obj_set_style_text_font(b, &deck_font_20, 0);
    lv_obj_set_style_bg_color(b, lv_color_hex(accent), 0);
    lv_obj_set_style_text_color(b, lv_color_hex(C_TEXT_ON), 0);
    lv_obj_set_style_opa(b, LV_OPA_40, LV_STATE_DISABLED);
    lv_obj_set_ext_click_area(b, 8);
    lv_obj_add_event_cb(b, onClimateStep, LV_EVENT_CLICKED, (void*)(intptr_t)dir);
    return b;
  };
  s_climMinus = stepButton(16, LV_SYMBOL_MINUS, -1);
  s_climPlus = stepButton(cw - 16 - BTN, LV_SYMBOL_PLUS, 1);
  // The setpoint between the buttons.
  const int lh = lv_font_get_line_height(&deck_font_28);
  lv_obj_set_pos(s_modalState, 16 + BTN + 8, y + (BTN - lh) / 2);
  lv_obj_set_width(s_modalState, cw - 32 - 2 * BTN - 16);
  lv_obj_set_style_text_align(s_modalState, LV_TEXT_ALIGN_CENTER, 0);
  int at = y + BTN + 8;
  s_climInfo = lv_label_create(c);
  lv_obj_set_style_text_color(s_climInfo, lv_color_hex(C_DIM), 0);
  lv_obj_set_style_text_align(s_climInfo, LV_TEXT_ALIGN_CENTER, 0);
  lv_label_set_long_mode(s_climInfo, LV_LABEL_LONG_MODE_DOTS);
  lv_obj_set_size(s_climInfo, cw - 32, lv_font_get_line_height(&deck_font_14));
  lv_obj_set_pos(s_climInfo, 16, at);
  lv_label_set_text(s_climInfo, "");
  at += lv_font_get_line_height(&deck_font_14) + 10;
  // HVAC modes as a row of chips; it scrolls sideways when they do not fit.
  s_climModes.clear();
  s_climModeBtns.clear();
  if (e) {
    int from = 0;
    while (from < (int)e->hvacModes.length() && s_climModes.size() < 8) {
      int comma = e->hvacModes.indexOf(',', from);
      if (comma < 0) comma = e->hvacModes.length();
      if (comma > from) s_climModes.push_back(e->hvacModes.substring(from, comma));
      from = comma + 1;
    }
  }
  if (s_climModes.size() > 1) {
    lv_obj_t* row = lv_obj_create(c);
    lv_obj_remove_style_all(row);
    lv_obj_set_pos(row, 16, at);
    lv_obj_set_size(row, cw - 32, 40);
    lv_obj_set_flex_flow(row, LV_FLEX_FLOW_ROW);
    lv_obj_set_style_pad_column(row, 8, 0);
    lv_obj_set_scroll_dir(row, LV_DIR_HOR);
    lv_obj_set_scrollbar_mode(row, LV_SCROLLBAR_MODE_OFF);
    for (size_t i = 0; i < s_climModes.size(); i++) {
      lv_obj_t* b = qpButton(row, 0, 0, 10, climateWord(s_climModes[i]).c_str(), false);
      lv_obj_set_width(b, LV_SIZE_CONTENT);
      lv_obj_set_style_pad_hor(b, 12, 0);
      lv_obj_set_style_min_width(b, 52, 0);
      lv_obj_set_flex_grow(b, 1);
      lv_obj_set_style_bg_color(b, lv_color_hex(accent), LV_STATE_CHECKED);
      lv_obj_add_event_cb(b, onClimateMode, LV_EVENT_CLICKED, (void*)(intptr_t)i);
      s_climModeBtns.push_back(b);
    }
    at += 40 + 6;
  } else {
    s_climModes.clear();
  }
  return at - y;
}

void closeModal() {
  if (s_modalSlider && s_modalTile >= 0 && s_modalTile < (int)s_tiles.size()) {
    if (Wish* w = findWish(s_tiles[s_modalTile].def->entity)) {
      if (w->holding) w->level = {};
      w->dragging = w->holding = false;
    }
  }
  climateClose();
  coverCardClose();
  presetCardClose();
  if (s_modalCard) lv_obj_delete(s_modalCard);
  if (s_modalScrim) lv_obj_delete(s_modalScrim);
  if (s_modalUnder) lv_obj_delete(s_modalUnder);
  s_modalCard = s_modalScrim = s_modalUnder = nullptr;
  if (s_modalGlass) lv_draw_buf_destroy(s_modalGlass);
  s_modalGlass = nullptr;
  s_modalSlider = nullptr;
  s_modalIcon = nullptr;
  s_modalChart = s_modalRange = nullptr;
  s_modalSeries = nullptr;
  heap_caps_free(s_modalPoints);
  s_modalPoints = nullptr;
  s_modalHistoryVersion = 0;
  s_modalMin = s_modalMax = NAN;
  haDetailHistory("");
  s_modalTile = -1;
  s_confirmHold = -1;
  if (s_confirmTimer) lv_timer_delete(s_confirmTimer);
  s_confirmTimer = nullptr;
  setModalOpen(false);
}

// Calm: the detail card shrinks back into its tile; confirm cards just close.
void onModalScrim(lv_event_t*) {
  if (s_confirmHold < 0) fxCardClose(s_modalCard, s_modalTile);
  else closeModal();
}

// The card's button runs the tap action; a switch whose tap does not switch
// (it opens this card, a page or nothing) gets its toggle here instead.
const TileAction& cardAction(const TileDef& d) {
  static TileAction toggle;
  toggle.kind = ACT_TOGGLE;
  const ActionKind k = d.tap.kind;
  const String domain = entityDomain(d.entity);
  const bool number = domain == "input_number" || domain == "number";
  const bool switches = d.type == TILE_TOGGLE || (d.type == TILE_SLIDER && !number && !d.pcVolume);
  return switches && (k == ACT_MORE_INFO || k == ACT_PAGE || k == ACT_NOTHING) ? toggle : d.tap;
}

void onModalPrimary(lv_event_t*) {
  if (s_modalTile < 0 || s_modalTile >= (int)s_tiles.size()) return;
  TileRt& r = s_tiles[s_modalTile];
  const TileAction& a = cardAction(*r.def);
  if (needsConfirm(r, a)) {
    openConfirm(s_modalTile, false);  // replaces this card
    return;
  }
  runAction(r, a);
  refreshModal();
}

// The card gets a level slider for lights and for entities that report a level.
bool modalHasSlider() {
  if (s_modalTile < 0) return false;
  const String& id = s_tiles[s_modalTile].def->entity;
  const String d = entityDomain(id);
  if (d == "light") return true;
  HaEntity e;
  return sliderDomain(d) && haGetEntity(id, e) && sliderFrac(d, e) >= 0;
}

void sendLevel(int pct, bool dragging) {
  if (s_modalTile < 0) return;
  const String& entity = s_tiles[s_modalTile].def->entity;
  if (dragging) setWish(entity, true, pct / 100.0f, true);
  else releaseLevel(entity);
}

void onModalSlider(lv_event_t* e) {
  const lv_event_code_t code = lv_event_get_code(e);
  if (code == LV_EVENT_PRESSED && s_modalTile >= 0)
    holdLevel(s_tiles[s_modalTile].def->entity, lv_slider_get_value(s_modalSlider) / 100.0f);
  else if (code == LV_EVENT_VALUE_CHANGED || code == LV_EVENT_RELEASED || code == LV_EVENT_PRESS_LOST)
    sendLevel(lv_slider_get_value(s_modalSlider), code == LV_EVENT_VALUE_CHANGED);
}

void refreshModal() {
  if (s_modalTile < 0 || !s_modalCard) return;
  const TileRt& r = s_tiles[s_modalTile];
  if (s_confirmHold >= 0) {
    // The state changed under the question (HA, another device): ask again.
    if (r.on != s_confirmOn) closeModal();
    return;
  }
  String st = tileSub(r);
  HaEntity e;
  const bool haKnown = r.def->entity.length() && haGetEntity(r.def->entity, e);
  if (haKnown) st = wishText(r.def->entity, e, false);
  if (s_climate) {
    climateRefresh(haKnown ? &e : nullptr);
  } else if (s_modalSlider) {
    const float f = haKnown ? wishFrac(r.def->entity, e) : -1;
    const int pct = f > 0 ? (int)lroundf(f * 100) : 0;
    lv_slider_set_value(s_modalSlider, pct, LV_ANIM_OFF);
    lv_label_set_text(s_modalState, (haKnown ? wishText(r.def->entity, e, true) : st).c_str());
  } else {
    lv_label_set_text(s_modalState, st.c_str());
  }
  if (r.def->type == TILE_TOGGLE || (r.def->type == TILE_SLIDER && cardAction(*r.def).kind == ACT_TOGGLE))
    lv_label_set_text(s_modalBtnLbl, actionVerb(r, cardAction(*r.def)));
  if (s_modalChart) {
    float value;
    const bool numeric = haKnown && e.known && haNumericState(e.state, value);
    if (numeric) {
      if (!s_modalBuilding) haDetailHistory(r.def->entity, s_modalHours);
      copyHistoryChart(*r.def, s_modalHours, s_modalHistoryVersion, s_modalChart,
                       s_modalPoints, s_modalMin, s_modalMax);
    }
    showObj(s_modalChart, numeric);
    showObj(s_modalRange, numeric);
    lv_chart_set_series_color(s_modalChart, s_modalSeries, lv_color_hex(sensorLine(r)));
    lv_obj_set_style_text_color(s_modalState, lv_color_hex(sensorColour(r)), 0);
    if (numeric) {
      char range[128];
      if (isfinite(s_modalMin))
        snprintf(range, sizeof(range), "Last %u h    Min %.3g    Max %.3g %s",
                 s_modalHours, s_modalMin, s_modalMax, e.unit.c_str());
      else snprintf(range, sizeof(range), "Last %u h    No history yet", s_modalHours);
      lv_label_set_text(s_modalRange, range);
    }
  }
  coverCardRefresh(r.def->entity, haKnown ? &e : nullptr);
  presetCardRefresh(*r.def, haKnown ? &e : nullptr);
  const bool on = haKnown && wishOn(r.def->entity, e);
  s_modalIconCp = showIcon(s_modalIcon, *r.def, haKnown ? &e : nullptr, on, 28, s_modalIconCp);
}

// Detail card for a tile (hold action "more-info"): name, entity, state, a
// level slider (light brightness, cover position...), and the tap action as a
// button.
// Touch effects stop, and LVGL draws the page once without them: the card's
// background and animation take their picture of the page from that frame.
void cleanPage() {
  if (fxCancelRipples()) lv_refr_now(s_disp);
}

void openModal(int tileIdx) {
  closeModal();
  cleanPage();
  const TileRt& r = s_tiles[tileIdx];
  const TileDef& d = *r.def;
  const int w = logicalW(), h = logicalH();
  const uint32_t accent = d.hasColor ? d.color : domainColor(entityDomain(d.entity));
  s_modalTile = tileIdx;
  const bool light = modalHasSlider();
  HaEntity he;
  float hv;
  const bool haKnown = d.entity.length() && haGetEntity(d.entity, he);
  const bool graph = d.type == TILE_SENSOR && haKnown && he.known && haNumericState(he.state, hv);
  const bool climate = entityDomain(d.entity) == "climate" && !d.http.enabled;

  const int cw = w - 40 < 380 ? w - 40 : 380;
  int ch = graph ? (light ? 304 : 284) : light ? 236 : 196;
  // Climate: +/- row (52), info line, mode chips when it has several modes.
  int nModes = 0;
  if (climate && haKnown)
    for (int i = 0, n = he.hvacModes.length(); i < n; i++) nModes += i == 0 || he.hvacModes[i] == ',';
  if (climate) ch = 74 + 52 + 8 + lv_font_get_line_height(&deck_font_14) + 10 +
                    (nModes > 1 ? 46 : 0) + 10 + 44 + 16;
  // Cover: up / stop / down under the position slider.
  const bool cover = entityDomain(d.entity) == "cover" && !d.http.enabled;
  const int coverY = light ? 160 : 118;
  if (cover) ch = coverY + 48 + 12 + 44 + 16;
  // Light presets: the same row of keys, in the cover buttons' slot.
  const bool presets = light && !climate && hasPresets(d);
  if (presets) ch = 160 + 48 + 12 + 44 + 16;
  fxCardOpenBegin(tileIdx, {(int16_t)((w - cw) / 2), (int16_t)((h - ch) / 2), (int16_t)cw, (int16_t)ch}, 22);

  s_modalScrim = makeScrim(false);  // filled below, while the animation runs
  lv_obj_t* c = lv_obj_create(lv_layer_top());
  s_modalCard = c;
  lv_obj_remove_style_all(c);
  lv_obj_set_size(c, cw, ch);
  lv_obj_center(c);
  lv_obj_set_style_bg_color(c, lv_color_hex(C_PANEL), 0);
  lv_obj_set_style_bg_opa(c, LV_OPA_COVER, 0);
  lv_obj_set_style_radius(c, 22, 0);
  if (s_theme == THEME_GLASS &&
      (s_modalGlass = frostedCopy((w - cw) / 2, (h - ch) / 2, cw, ch, 22)))
    frostStyle(c, s_modalGlass);
  lv_obj_set_style_text_color(c, lv_color_hex(C_TEXT), 0);
  lv_obj_add_flag(c, LV_OBJ_FLAG_CLICKABLE);  // taps on the card stay on the card
  lv_obj_remove_flag(c, LV_OBJ_FLAG_SCROLLABLE);

  lv_obj_t* chip = lv_obj_create(c);
  lv_obj_remove_style_all(chip);
  lv_obj_set_size(chip, 44, 44);
  lv_obj_set_pos(chip, 16, 16);
  lv_obj_set_style_radius(chip, LV_RADIUS_CIRCLE, 0);
  lv_obj_set_style_bg_opa(chip, LV_OPA_COVER, 0);
  styleIconChip(chip, accent);
  lv_obj_set_style_text_font(chip, &deck_font_20, 0);
  lv_obj_remove_flag(chip, LV_OBJ_FLAG_CLICKABLE);
  s_modalIcon = lv_label_create(chip);
  s_modalIconCp = 0;
  lv_label_set_text(s_modalIcon, "");
  lv_obj_center(s_modalIcon);

  // Name and entity id: one line each, cut with dots (ids get long).
  lv_obj_t* name = lv_label_create(c);
  String title = tileLabel(d);
  if (!d.label.length() && haKnown && he.name.length())
    title = he.name;
  lv_label_set_text(name, title.c_str());
  lv_obj_set_style_text_font(name, &deck_font_20, 0);
  lv_label_set_long_mode(name, LV_LABEL_LONG_MODE_DOTS);
  lv_obj_set_size(name, cw - 88, lv_font_get_line_height(&deck_font_20));
  lv_obj_set_pos(name, 72, 15);
  lv_obj_t* ent = lv_label_create(c);
  lv_label_set_text(ent, d.entity.length() ? d.entity.c_str() : "No entity");
  lv_obj_set_style_text_color(ent, lv_color_hex(C_DIM), 0);
  lv_label_set_long_mode(ent, LV_LABEL_LONG_MODE_DOTS);
  lv_obj_set_size(ent, cw - 88, lv_font_get_line_height(&deck_font_14));
  lv_obj_set_pos(ent, 72, 41);

  s_modalState = lv_label_create(c);
  lv_obj_set_style_text_font(s_modalState, &deck_font_28, 0);
  lv_label_set_long_mode(s_modalState, LV_LABEL_LONG_MODE_DOTS);
  lv_obj_set_size(s_modalState, cw - 32, lv_font_get_line_height(&deck_font_28));
  lv_obj_set_pos(s_modalState, 16, 74);

  s_modalSlider = nullptr;
  if (climate) climateBuild(c, cw, 74, accent, haKnown ? &he : nullptr);
  if (light && !climate) {
    lv_obj_t* sl = lv_slider_create(c);
    s_modalSlider = sl;
    lv_obj_set_pos(sl, 26, 128);
    lv_obj_set_size(sl, cw - 52, 14);
    lv_slider_set_range(sl, 0, 100);
    lv_obj_set_style_bg_color(sl, lv_color_hex(C_TRACK), LV_PART_MAIN);
    lv_obj_set_style_bg_opa(sl, LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_style_bg_color(sl, lv_color_hex(accent), LV_PART_INDICATOR);
    lv_obj_set_style_bg_opa(sl, LV_OPA_COVER, LV_PART_INDICATOR);
    lv_obj_set_style_bg_color(sl, lv_color_hex(0xFFFFFF), LV_PART_KNOB);
    lv_obj_set_style_pad_all(sl, 7, LV_PART_KNOB);
    lv_obj_set_ext_click_area(sl, 18);
    lv_obj_add_event_cb(sl, onModalSlider, LV_EVENT_PRESSED, nullptr);
    lv_obj_add_event_cb(sl, onModalSlider, LV_EVENT_VALUE_CHANGED, nullptr);
    lv_obj_add_event_cb(sl, onModalSlider, LV_EVENT_RELEASED, nullptr);
    lv_obj_add_event_cb(sl, onModalSlider, LV_EVENT_PRESS_LOST, nullptr);
  }

  if (cover) coverCardBuild(c, cw, coverY, accent);
  if (presets) presetCardBuild(c, cw, 160, d);

  if (graph) {
    s_modalHours = d.style == METRIC_CHART ? d.hours : 24;
    s_modalPoints = (int32_t*)heap_caps_malloc(sizeof(int32_t) * HA_HISTORY_POINTS, MALLOC_CAP_SPIRAM);
    if (s_modalPoints) {
      s_modalChart = lv_chart_create(c);
      lv_obj_remove_style_all(s_modalChart);
      lv_obj_set_pos(s_modalChart, 16, light ? 154 : 112);
      lv_obj_set_size(s_modalChart, cw - 32, light ? 50 : 76);
      lv_chart_set_type(s_modalChart, LV_CHART_TYPE_LINE);
      lv_chart_set_div_line_count(s_modalChart, 0, 0);
      lv_chart_set_point_count(s_modalChart, HA_HISTORY_POINTS);
      lv_obj_set_style_line_width(s_modalChart, 2, LV_PART_ITEMS);
      lv_obj_set_style_width(s_modalChart, 0, LV_PART_INDICATOR);
      lv_obj_set_style_height(s_modalChart, 0, LV_PART_INDICATOR);
      lv_obj_remove_flag(s_modalChart, LV_OBJ_FLAG_CLICKABLE);
      s_modalSeries = lv_chart_add_series(s_modalChart, lv_color_hex(sensorLine(r)), LV_CHART_AXIS_PRIMARY_Y);
      for (int i = 0; i < HA_HISTORY_POINTS; i++) s_modalPoints[i] = LV_CHART_POINT_NONE;
      lv_chart_set_series_ext_y_array(s_modalChart, s_modalSeries, s_modalPoints);
      s_modalRange = lv_label_create(c);
      lv_obj_set_style_text_font(s_modalRange, &deck_font_12, 0);
      lv_label_set_long_mode(s_modalRange, LV_LABEL_LONG_MODE_WRAP);
      lv_obj_set_size(s_modalRange, cw - 32, 18);
      lv_obj_set_pos(s_modalRange, 16, light ? 212 : 196);
    }
  }

  const int bw = (cw - 16 * 2 - 10) / 2;
  const int by = ch - 16 - 44;
  lv_obj_t* primary = qpButton(c, 16, by, bw, "", false);
  lv_obj_set_height(primary, 44);
  lv_obj_set_style_bg_color(primary, lv_color_hex(accent), 0);
  lv_obj_set_style_text_color(primary, lv_color_hex(C_TEXT_ON), 0);
  s_modalBtnLbl = lv_obj_get_child(primary, 0);
  lv_label_set_text(s_modalBtnLbl, "Run");
  lv_obj_add_event_cb(primary, onModalPrimary, LV_EVENT_CLICKED, nullptr);
  // Nothing to run when the tap only opens this card (sensors, numbers).
  const ActionKind pk = cardAction(d).kind;
  const bool noPrimary = d.type == TILE_SENSOR || pk == ACT_MORE_INFO || pk == ACT_NOTHING || cover;
  if (noPrimary) lv_obj_add_flag(primary, LV_OBJ_FLAG_HIDDEN);
  lv_obj_t* close = qpButton(c, noPrimary ? 16 : 16 + bw + 10, by, noPrimary ? cw - 32 : bw, "Close", false);
  lv_obj_set_height(close, 44);
  lv_obj_add_event_cb(close, onModalScrim, LV_EVENT_CLICKED, nullptr);

  setModalOpen(true);
  s_modalBuilding = true;
  refreshModal();
  s_modalBuilding = false;
  fxCardOpen(c, tileIdx);
  coverFill();
  // The history reply lands on core 0; HA waits for the animation started above.
  if (s_modalChart) refreshModal();
}

void onConfirmOk(lv_event_t*) {
  if (s_modalTile < 0 || s_confirmHold < 0 || millis() - s_confirmMs < CONFIRM_ARM_MS) return;
  TileRt& r = s_tiles[s_modalTile];
  const TileAction& a = s_confirmHold ? r.def->hold : cardAction(*r.def);
  closeModal();
  runAction(r, a);
}

void onConfirmTimeout(lv_timer_t*) {
  s_confirmTimer = nullptr;  // a one-shot timer deletes itself
  closeModal();
}

// "Turn off Printer?" card for tiles with "confirm". Cancel, the scrim, the
// timeout or a state change close it without running anything.
void openConfirm(int tileIdx, bool hold) {
  closeModal();
  cleanPage();
  const TileRt& r = s_tiles[tileIdx];
  const TileDef& d = *r.def;
  const TileAction& a = hold ? d.hold : cardAction(d);
  const int w = logicalW(), h = logicalH();
  const uint32_t accent = d.hasColor ? d.color : domainColor(entityDomain(d.entity));
  constexpr uint32_t C_DANGER = 0xE5534B;
  s_modalTile = tileIdx;
  s_confirmHold = hold ? 1 : 0;
  s_confirmOn = r.on;
  s_confirmMs = millis();

  s_modalScrim = makeScrim();

  const int cw = w - 40 < 360 ? w - 40 : 360;
  const int ch = 188;
  lv_obj_t* c = lv_obj_create(lv_layer_top());
  s_modalCard = c;
  lv_obj_remove_style_all(c);
  lv_obj_set_size(c, cw, ch);
  lv_obj_center(c);
  lv_obj_set_style_bg_color(c, lv_color_hex(C_PANEL), 0);
  lv_obj_set_style_bg_opa(c, LV_OPA_COVER, 0);
  lv_obj_set_style_radius(c, 22, 0);
  if (s_theme == THEME_GLASS &&
      (s_modalGlass = frostedCopy((w - cw) / 2, (h - ch) / 2, cw, ch, 22)))
    frostStyle(c, s_modalGlass);
  lv_obj_set_style_text_color(c, lv_color_hex(C_TEXT), 0);
  lv_obj_add_flag(c, LV_OBJ_FLAG_CLICKABLE);
  lv_obj_remove_flag(c, LV_OBJ_FLAG_SCROLLABLE);

  lv_obj_t* chip = lv_obj_create(c);
  lv_obj_remove_style_all(chip);
  lv_obj_set_size(chip, 44, 44);
  lv_obj_set_pos(chip, 16, 16);
  lv_obj_set_style_radius(chip, LV_RADIUS_CIRCLE, 0);
  lv_obj_set_style_bg_opa(chip, LV_OPA_COVER, 0);
  styleIconChip(chip, accent);
  lv_obj_set_style_text_font(chip, &deck_font_20, 0);
  lv_obj_remove_flag(chip, LV_OBJ_FLAG_CLICKABLE);
  s_modalIcon = lv_label_create(chip);
  lv_label_set_text(s_modalIcon, "");
  lv_obj_center(s_modalIcon);
  HaEntity he;
  const bool haKnown = d.entity.length() && haGetEntity(d.entity, he);
  s_modalIconCp = showIcon(s_modalIcon, d, haKnown ? &he : nullptr, r.on, 28, 0);

  String title = tileLabel(d);
  if (!d.label.length() && haKnown && he.name.length()) title = he.name;
  lv_obj_t* name = lv_label_create(c);
  lv_label_set_text(name, title.c_str());
  lv_obj_set_style_text_font(name, &deck_font_20, 0);
  lv_label_set_long_mode(name, LV_LABEL_LONG_MODE_DOTS);
  lv_obj_set_size(name, cw - 88, lv_font_get_line_height(&deck_font_20));
  const String state = haKnown ? prettyState(entityDomain(d.entity), he, d.decimals) : tileSub(r);
  lv_obj_set_pos(name, 72, state.length() ? 15 : 26);
  if (state.length()) {
    lv_obj_t* st = lv_label_create(c);
    lv_label_set_text(st, state.c_str());
    lv_obj_set_style_text_color(st, lv_color_hex(C_DIM), 0);
    lv_label_set_long_mode(st, LV_LABEL_LONG_MODE_DOTS);
    lv_obj_set_size(st, cw - 88, lv_font_get_line_height(&deck_font_14));
    lv_obj_set_pos(st, 72, 41);
  }

  const char* verb = actionVerb(r, a);
  lv_obj_t* q = lv_label_create(c);
  lv_label_set_text_fmt(q, "%s?", verb);
  lv_obj_set_style_text_font(q, &deck_font_28, 0);
  lv_label_set_long_mode(q, LV_LABEL_LONG_MODE_DOTS);
  lv_obj_set_size(q, cw - 32, lv_font_get_line_height(&deck_font_28));
  lv_obj_set_pos(q, 16, 74);

  const int bw = (cw - 16 * 2 - 10) / 2;
  const int by = ch - 16 - 44;
  lv_obj_t* cancel = qpButton(c, 16, by, bw, "Cancel", false);
  lv_obj_set_height(cancel, 44);
  lv_obj_add_event_cb(cancel, onModalScrim, LV_EVENT_CLICKED, nullptr);
  lv_obj_t* ok = qpButton(c, 16 + bw + 10, by, bw, verb, false);
  lv_obj_set_height(ok, 44);
  lv_obj_set_style_bg_color(ok, lv_color_hex(C_DANGER), 0);
  lv_obj_set_style_text_color(ok, lv_color_white(), 0);
  lv_obj_add_event_cb(ok, onConfirmOk, LV_EVENT_CLICKED, nullptr);

  s_confirmTimer = lv_timer_create(onConfirmTimeout, CONFIRM_TIMEOUT_MS, nullptr);
  lv_timer_set_repeat_count(s_confirmTimer, 1);
  setModalOpen(true);
}

// Printer errors: print_error first, then the HMS codes worst first. A tap
// anywhere closes it.
void onErrorsClose(lv_event_t*) { closeModal(); }

void openPrinterErrors(const String& title, const PrinterState& s) {
  closeModal();
  cleanPage();
  const int w = logicalW(), h = logicalH();
  s_modalScrim = makeScrim();
  const int cw = w - 32 < 440 ? w - 32 : 440;
  const int ch = h - 40 < 340 ? h - 40 : 340;
  lv_obj_t* c = lv_obj_create(lv_layer_top());
  s_modalCard = c;
  lv_obj_remove_style_all(c);
  lv_obj_set_size(c, cw, ch);
  lv_obj_center(c);
  lv_obj_set_style_bg_color(c, lv_color_hex(C_PANEL), 0);
  lv_obj_set_style_bg_opa(c, LV_OPA_COVER, 0);
  lv_obj_set_style_radius(c, 22, 0);
  if (s_theme == THEME_GLASS &&
      (s_modalGlass = frostedCopy((w - cw) / 2, (h - ch) / 2, cw, ch, 22)))
    frostStyle(c, s_modalGlass);
  lv_obj_set_style_text_color(c, lv_color_hex(C_TEXT), 0);
  lv_obj_set_style_pad_all(c, 16, 0);
  lv_obj_set_style_pad_row(c, 10, 0);
  lv_obj_set_flex_flow(c, LV_FLEX_FLOW_COLUMN);
  lv_obj_set_scroll_dir(c, LV_DIR_VER);
  lv_obj_add_flag(c, LV_OBJ_FLAG_CLICKABLE);
  lv_obj_add_event_cb(c, onErrorsClose, LV_EVENT_CLICKED, nullptr);

  lv_obj_t* name = lv_label_create(c);
  lv_label_set_text(name, title.c_str());
  lv_obj_set_style_text_font(name, &deck_font_20, 0);
  lv_label_set_long_mode(name, LV_LABEL_LONG_MODE_DOTS);
  lv_obj_set_width(name, lv_pct(100));

  auto entry = [&](uint8_t sev, const String& head, const char* code, const String& text) {
    const uint32_t color = hmsSeverityColor(sev);
    lv_obj_t* box = lv_obj_create(c);
    lv_obj_remove_style_all(box);
    lv_obj_remove_flag(box, (lv_obj_flag_t)(LV_OBJ_FLAG_CLICKABLE | LV_OBJ_FLAG_SCROLLABLE));
    lv_obj_add_flag(box, LV_OBJ_FLAG_EVENT_BUBBLE);
    lv_obj_set_size(box, lv_pct(100), LV_SIZE_CONTENT);
    lv_obj_set_flex_flow(box, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_style_pad_left(box, 10, 0);
    lv_obj_set_style_pad_row(box, 2, 0);
    lv_obj_set_style_border_side(box, LV_BORDER_SIDE_LEFT, 0);
    lv_obj_set_style_border_width(box, 3, 0);
    lv_obj_set_style_border_color(box, lv_color_hex(color), 0);
    lv_obj_t* hl = lv_label_create(box);
    lv_label_set_text(hl, head.c_str());
    lv_obj_set_style_text_font(hl, &deck_font_14, 0);
    lv_obj_set_style_text_color(hl, lv_color_hex(color), 0);
    lv_obj_t* tl = lv_label_create(box);
    lv_label_set_text(tl, text.c_str());
    lv_obj_set_style_text_font(tl, &deck_font_14, 0);
    lv_obj_set_width(tl, lv_pct(100));
    lv_label_set_long_mode(tl, LV_LABEL_LONG_MODE_WRAP);
    lv_obj_t* cl = lv_label_create(box);
    lv_label_set_text(cl, code);
    lv_obj_set_style_text_font(cl, &deck_font_12, 0);
    lv_obj_set_style_text_opa(cl, LV_OPA_60, 0);
  };
  char code[32];
  if (s.printError && !printErrorIsCancel(s.printError)) {
    printErrorFormatCode(s.printError, code, sizeof(code));
    const char* t = printErrorText(s.printError);
    entry(1, "Print error", code, t ? t : "No description published for this code");
  }
  for (uint8_t i = 0; i < s.hmsCount; i++) {
    const PrinterHms& e = s.hms[i];
    const uint8_t sev = hmsSeverity(e.code);
    hmsFormatCode(e.attr, e.code, code, sizeof(code));
    const char* t = hmsText(e.attr, e.code);
    String head = String(hmsSeverityLabel(sev)) + " - " + hmsModuleLabel(e.attr);
    if (e.quiet) head += " (handled)";
    entry(sev >= 1 && sev <= 3 ? sev : 0, head, code, t ? t : "No description published for this code");
  }
  if (s.hmsTotal > s.hmsCount) {
    lv_obj_t* more = lv_label_create(c);
    lv_label_set_text_fmt(more, "+%u more on the printer", (unsigned)(s.hmsTotal - s.hmsCount));
    lv_obj_set_style_text_font(more, &deck_font_12, 0);
    lv_obj_set_style_text_opa(more, LV_OPA_60, 0);
  }
  setModalOpen(true);
}

// The pairing card: Allow / Deny for a companion's request, or the code an
// older companion asked for, until answered, cancelled or timed out
// (pc_metrics owns the state).
lv_obj_t* s_pairCard = nullptr;
lv_obj_t* s_pairScrim = nullptr;
uint32_t s_pairChecked = 0;
String s_pairName, s_pairCode;

void pairClose() {
  if (s_pairCard) lv_obj_delete(s_pairCard);
  if (s_pairScrim) lv_obj_delete(s_pairScrim);
  s_pairCard = s_pairScrim = nullptr;
  s_pairName = s_pairCode = "";
  setModalOpen(s_modalCard != nullptr);
}

void onPairCancel(lv_event_t*) {
  pcPairCancel();
  lv_async_call([](void*) { pairClose(); }, nullptr);  // runs in the button's own event
}

void onPairAllow(lv_event_t*) {
  pcPairAllow();
  lv_async_call([](void*) { pairClose(); }, nullptr);
}

void pairSync() {
  const uint32_t now = millis();
  if (now - s_pairChecked < 250) return;
  s_pairChecked = now;
  String name, code;
  const bool pending = pcPairPending(name, code);
  if (!pending) {
    if (s_pairCard) pairClose();
    return;
  }
  if (s_pairCard && name == s_pairName && code == s_pairCode) return;
  if (s_pairCard) pairClose();
  s_pairName = name;
  s_pairCode = code;
  const int w = logicalW(), h = logicalH();
  s_pairScrim = lv_obj_create(lv_layer_top());
  lv_obj_remove_style_all(s_pairScrim);
  lv_obj_set_size(s_pairScrim, w, h);
  lv_obj_set_style_bg_color(s_pairScrim, lv_color_black(), 0);
  lv_obj_set_style_bg_opa(s_pairScrim, LV_OPA_50, 0);
  lv_obj_add_flag(s_pairScrim, LV_OBJ_FLAG_CLICKABLE);
  const int cw = w - 40 < 340 ? w - 40 : 340;
  lv_obj_t* c = lv_obj_create(lv_layer_top());
  s_pairCard = c;
  lv_obj_remove_style_all(c);
  lv_obj_set_size(c, cw, 196);
  lv_obj_center(c);
  lv_obj_set_style_bg_color(c, lv_color_hex(C_PANEL), 0);
  lv_obj_set_style_bg_opa(c, LV_OPA_COVER, 0);
  lv_obj_set_style_radius(c, 22, 0);
  lv_obj_set_style_text_color(c, lv_color_hex(C_TEXT), 0);
  lv_obj_add_flag(c, LV_OBJ_FLAG_CLICKABLE);
  lv_obj_remove_flag(c, LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_t* t = lv_label_create(c);
  lv_label_set_text_fmt(t, "Pair %s", name.c_str());
  lv_obj_set_style_text_font(t, &deck_font_20, 0);
  lv_label_set_long_mode(t, LV_LABEL_LONG_MODE_DOTS);
  lv_obj_set_width(t, cw - 32);
  lv_obj_set_pos(t, 16, 14);
  if (!code.length()) {
    // Tap mode: the companion waits for this answer.
    lv_obj_t* q = lv_label_create(c);
    lv_label_set_text_fmt(q, "Let this deck control %s: media, volume, lock, power and hotkeys?", name.c_str());
    lv_label_set_long_mode(q, LV_LABEL_LONG_MODE_WRAP);
    lv_obj_set_width(q, cw - 32);
    lv_obj_set_style_text_color(q, lv_color_hex(C_DIM), 0);
    lv_obj_set_pos(q, 16, 52);
    const int bw = (cw - 40) / 2;
    lv_obj_t* deny = qpButton(c, 16, 196 - 16 - 44, bw, "Deny", false);
    lv_obj_set_height(deny, 44);
    lv_obj_add_event_cb(deny, onPairCancel, LV_EVENT_CLICKED, nullptr);
    lv_obj_t* allow = qpButton(c, 24 + bw, 196 - 16 - 44, bw, "Allow", false);
    lv_obj_set_height(allow, 44);
    lv_obj_add_state(allow, LV_STATE_CHECKED);  // the accent look
    lv_obj_add_event_cb(allow, onPairAllow, LV_EVENT_CLICKED, nullptr);
    setModalOpen(true);
    return;
  }
  lv_obj_t* k = lv_label_create(c);
  String spaced = code.substring(0, 3) + " " + code.substring(3);
  lv_label_set_text(k, spaced.c_str());
  lv_obj_set_style_text_font(k, &deck_font_28, 0);
  lv_obj_set_style_text_letter_space(k, 4, 0);
  lv_obj_align(k, LV_ALIGN_TOP_MID, 0, 50);
  lv_obj_t* hint = lv_label_create(c);
  lv_label_set_text(hint, "Enter this code in TouchDeck Companion");
  lv_obj_set_style_text_color(hint, lv_color_hex(C_DIM), 0);
  lv_obj_align(hint, LV_ALIGN_TOP_MID, 0, 94);
  lv_obj_t* cancel = qpButton(c, 16, 196 - 16 - 44, cw - 32, "Cancel", false);
  lv_obj_set_height(cancel, 44);
  lv_obj_add_event_cb(cancel, onPairCancel, LV_EVENT_CLICKED, nullptr);
  setModalOpen(true);  // no swipes under it
}

}  // namespace deckui
