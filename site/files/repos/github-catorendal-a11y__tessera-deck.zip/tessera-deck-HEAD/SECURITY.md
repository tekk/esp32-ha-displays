# Security

Tessera runs commands, opens files, calls web addresses and starts plugins on your PC when you press a key. This page says what the host exposes, what you should check, and how to report a problem.

## What the host exposes

The editor and the control API are two small web servers inside the host. Neither is reachable from another computer.

| Surface | Listens on | Protection |
|---|---|---|
| Editor | `127.0.0.1`, a free port | A per-run token that stays in a private file. The window opens with a one-time code that the page trades for a session key, which it sends in a header; a cookie (`HttpOnly`, `SameSite=Strict`) only opens icon previews. Requests whose `Host` is not `127.0.0.1:<port>` or that come from another web page (`Origin` header) are refused. |
| Control API (`/v1/…`) | `127.0.0.1`, a free port | A per-run token in the `X-Deck-Token` header. The same `Host` and `Origin` checks. Each token may make 20 calls a second, in bursts of up to 40, then gets `429`. |

- The tokens live in `host/deck-api.local.json` and in the editor's record file. Only your own account can read them. They change every time the host starts.
- Plugins get their own token with only the routes they declared, and only variable names that start with `<plugin id>.`. See [Plugins](docs/PLUGINS.md).
- An HTTP action does not follow a redirect from https to http. A redirect to another host goes there without the action's headers, so an `Authorization` header is not passed on.
- An *Open* step with an address does not fill in `%NAME%` from the PC's environment, so the address cannot leak it. Paths still do.
- Every call that changes something through the control API is written to the host log (**More → Host log …**) with the caller's name, the method, the path and the answer code. The log never holds request bodies, and it leaves out successful bulk variable updates (`/v1/vars`). Single updates (`/v1/var`) are logged.
- The panel itself has no network. It only speaks to the host over USB, see [Protocol](docs/PROTOCOL.md).
- Any program that can open the panel's COM port can write firmware to it, as esptool does. Secure boot is off, so the panel runs that firmware without checking who built it.
- *Check for updates* keeps a downloaded firmware package, or the program zip of *Update Tessera*, only if its SHA-256 matches `SHA256SUMS` from the same GitHub release. The program zip is unpacked over the program folder only: a name that leads outside it stops the update before anything is written, and your own files are never written over. That catches a damaged download. Someone who could change the release could change `SHA256SUMS` too, so for provenance use `gh attestation verify` as [Install](docs/INSTALL.md#download-and-verify) shows.

## Imported profiles

Treat an imported profile like a program. A profile can hold shell commands, web requests, program launches, plugin commands and rules that run by themselves.

- Import lists every shell command, web request (with the host it goes to), program launch outside web links and documents, plugin command and automatic rule, and asks before keeping them. You can import without them.
- Import also lists the plugins a file turns on, and importing without the listed actions drops the file's plugins. A file that leaves a plugin off can still carry settings for it, and *Replace the configuration* keeps them, so check the plugin settings after a Replace import.
- Variable values in shell commands are refused when they contain anything other than letters, digits, spaces and `. , : / - _`. In web addresses they are percent-encoded. Import marks a web request that sends a `$(env:NAME)` value as high risk.
- Read a shared profile before you import it, even when you know the author.

## Secrets

- Keep API keys out of profiles. Write `$(env:NAME)` in an HTTP header or body and set the variable in Windows, or in your environment on Linux.
- Exports replace known credential headers (`Authorization`, `Cookie`, `X-Api-Key` and similar) with `$(env:…)` references, and leave out the calendar address and plugin settings that look like secrets. The editor tells you what it left out.
- Plugin settings whose key contains `token`, `secret`, `password` or `api_key` are stored encrypted for your Windows account (DPAPI). `profiles.json` and its backups hold only the encrypted form. Another Windows account, or the same files on another PC, cannot read them. On Linux these settings go to the system keyring (a Secret Service such as GNOME Keyring or KWallet), and `profiles.json` holds only `$(keyring:<id>)`. Without a keyring the save fails with a message, and nothing is written in plain text.

## Plugins

A plugin runs with your own rights on the PC. Tessera does not sandbox it. It can read your files and use the network, whatever its manifest says. The manifest only limits what it may ask Tessera to do.

- Install a plugin only from a source you trust, and read its code first.
- The editor asks before a plugin first runs, and again for a new version, and shows the program it starts.
- A plugin's output goes to `host/plugins/<id>.log`.

## What Tessera contacts

Tessera makes these connections, each only after you ask for it:

| Address | When |
|---|---|
| The project's releases on `api.github.com` | The update check. |
| `api.open-meteo.com`, `geocoding-api.open-meteo.com` | The weather on the ambient screen and its city search. |
| `api.iconify.design` | Online icons. |
| Your own HTTP actions, the calendar address you enter for the *Next meeting* widget | When a key or widget uses them. |
| What the plugins you turn on contact | The bundled plugins only reach your own Home Assistant and OBS. |

Setup installs Python packages from PyPI, pinned by SHA-256 hash in `host/requirements.lock`. `tools\setup_sensors.ps1` downloads Libre Hardware Monitor and checks its SHA-256. The copy that runs with administrator rights (`Tessera.cmd --sensors` and the start at the end of setup) is downloaded and checked again into `%ProgramFiles%\Tessera\LibreHardwareMonitor`, where only administrators can write. It is never started from the Tessera folder. A firewall rule blocks its port 8085 from the network; Tessera reads it on 127.0.0.1. Releases carry a build attestation and `SHA256SUMS`; [Install](docs/INSTALL.md) shows how to check a download.

## Claude Code's permission questions

*Connect Claude Code* adds hooks to `~/.claude/settings.json`, after a backup, and keeps your other hooks. A question then appears on the panel's agents screen, and only a touch on **Allow** or **Deny** answers it.

Tessera never allows anything on its own. Claude Code falls back to its own dialog when there is no panel, when nobody answers within 25 seconds, or when the request is longer than 150 characters.

## Reporting a security problem

Do not open a public issue.

1. Open **Security → Report a vulnerability** on the repository page. The report is only visible to the maintainer.
2. Say which version you run (the `VERSION` file holds it) and how to reproduce the problem.
