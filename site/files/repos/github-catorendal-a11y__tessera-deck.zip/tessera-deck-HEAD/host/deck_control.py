"""Lifecycle for the local Tessera USB host."""
import json
import os
from pathlib import Path
import subprocess
from process_flags import NO_WINDOW
import sys
import time
import psutil

import config_store
from config_store import write_atomic
import secrets_store
from host_runtime import DEFAULT_PORT
from platform_support import IS_WINDOWS, load

ROOT = Path(__file__).resolve().parents[1]
MAX_LOG_BYTES = 5 * 1024 * 1024
FIRMWARE_FLAG_PATH = ROOT / 'host/firmware-install.local.json'  # exists while the editor flashes the panel
FIRMWARE_FLAG_SECONDS = 600  # a flash takes about a minute; a flag left by a crashed editor expires


def firmware_installing(path=None):
    """True while the editor installs panel firmware: a host started then takes the COM port from esptool."""
    try:
        return time.time() - Path(path or FIRMWARE_FLAG_PATH).stat().st_mtime < FIRMWARE_FLAG_SECONDS
    except OSError:
        return False


def startup_script_path(appdata=None):
    """The per-user startup entry: the XDG autostart file on Linux, the Startup folder's Tessera.vbs on Windows."""
    return load('autostart').startup_script_path(appdata)


def startup_line():
    """The line of Tessera.vbs that starts the tray app of this folder (Windows)."""
    from platform_windows import autostart
    return autostart.startup_line(ROOT)


def autostart_enabled(appdata=None):
    """True when the startup entry starts this folder. A script left by a copy in another folder does not count."""
    try:
        path = startup_script_path(appdata)
    except OSError:  # no startup folder (no APPDATA): nothing starts this folder
        return False
    return load('autostart').is_enabled(path, ROOT)


def set_autostart(enabled, appdata=None):
    """Start the tray app (which starts the USB host) after the user signs in."""
    path = startup_script_path(appdata)
    if not enabled:
        path.unlink(missing_ok=True)
        return path
    return load('autostart').enable(path, ROOT)


def stop_editor(record_path=None, script=None, wait=4.0):
    """Stop the editor when it runs in a browser tab. True when one was stopped.

    In a native window, closing the window ends the editor. A browser tab is not the editor's window, so without this
    the editor's web server would keep running after the tray is closed. Only the process the record names is
    touched, and only if it is still the same process (same script, same start time).

    Not on Windows: terminate() is a hard kill there, and the tray's Quit has never stopped the editor on Windows."""
    if IS_WINDOWS:
        return False
    record_path = Path(record_path or ROOT / 'host/editor.local.json')
    script = Path(script or ROOT / 'host/tessera_app.py')
    try:
        record = json.loads(record_path.read_text(encoding='utf-8'))
        if not isinstance(record, dict) or not record.get('browser'):
            return False
        process = psutil.Process(record['pid'])
        command = process.cmdline()
        if not (len(command) > 1 and Path(command[1]).resolve() == script.resolve()
                and abs(process.create_time() - record['created']) < .01):
            return False
    except (OSError, ValueError, KeyError, TypeError, psutil.Error):
        return False
    try:
        process.terminate()  # SIGTERM: the editor turns it into a normal shutdown (record and lock removed)
        try:
            process.wait(wait)
        except psutil.TimeoutExpired:
            process.kill()
            process.wait(2)
    except psutil.Error:
        return False
    return True


def is_alive(process) -> bool:
    """Still running. A process that has ended but whose parent has not collected it yet (a zombie) is gone: the tray starts
    the host, and the editor that stops it for a firmware install is not the parent, so psutil's own wait would see that
    process for as long as the tray lives."""
    try:
        return process.is_running() and process.status() != psutil.STATUS_ZOMBIE
    except psutil.NoSuchProcess:
        return False
    except psutil.Error:
        return True  # cannot tell (access denied): assume it runs, as before


def wait_until_gone(processes, timeout, sleep=time.sleep, clock=time.monotonic):
    """The processes that are still alive after `timeout` seconds."""
    deadline = clock() + timeout
    alive = [process for process in processes if is_alive(process)]
    while alive and clock() < deadline:
        sleep(0.1)
        alive = [process for process in alive if is_alive(process)]
    return alive


def save_profiles(config, path=None):
    from tesserad import validate_config
    path = Path(path or ROOT / 'host/profiles.json')
    try:
        previous = json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        previous = None
    config = secrets_store.seal_plugins(config, previous)  # plugin passwords and tokens never reach the file in plain text
    validate_config(config)
    text = json.dumps(config, ensure_ascii=False, indent=2) + '\n'
    # A unique, flushed temp file: the editor, terminal editor and tray can all save at once.
    write_atomic(path, text.encode('utf-8'))


class Controller:
    def __init__(self):
        self.pid_path = ROOT / 'host/deck-process.local.json'
        self.stop_path = ROOT / 'host/deck-stop.local.json'
        self.runtime_path = ROOT / 'host/deck-runtime.local.json'
        self.children = []  # hosts this object started: collected as they end, so none stays a zombie

    def processes(self, root=None):
        self.children = [child for child in self.children if child.poll() is None]
        try:
            saved = json.loads(self.pid_path.read_text())
            # The editor asks every 1.5 s: a host already found is checked, not searched for again.
            known = getattr(self, 'known', None)
            if known and known[0] == (saved['pid'], saved['created']) and known[1].is_running():
                return [known[1]]
            process = psutil.Process(saved['pid'])
            command = process.cmdline()
            if (abs(process.create_time() - saved['created']) < .01 and len(command) > 1
                    and Path(command[1]).resolve() == ROOT / 'host/tesserad.py'):
                # Windows venv Python can keep a launcher process above the
                # interpreter. Track the actual daemon PID used by status/stop.
                matching = [process]
                for child in process.children(recursive=True):
                    arguments = child.cmdline()
                    if len(arguments) > 1 and Path(arguments[1]).resolve() == ROOT / 'host/tesserad.py':
                        matching.append(child)
                actual = matching[-1]
                if actual.pid != saved['pid']:
                    saved = {'pid': actual.pid, 'created': actual.create_time()}
                    self.pid_path.write_text(json.dumps(saved))
                self.known = ((saved['pid'], saved['created']), actual)
                return [actual]
        except (OSError, ValueError, KeyError, psutil.Error):
            pass
        return self.adopted()

    def adopted(self):
        """A host that was not started from here (a terminal, a script) still counts: it writes the runtime file.

        Without this the editor says "The host has stopped" while a host holds the USB port, and Start host
        launches a second one that exits at once.
        """
        try:
            process = psutil.Process(json.loads(self.runtime_path.read_text(encoding='utf-8'))['pid'])
            command = process.cmdline()
            if len(command) > 1 and Path(command[1]).resolve() == ROOT / 'host/tesserad.py':
                self.pid_path.write_text(json.dumps({'pid': process.pid, 'created': process.create_time()}))
                return [process]
        except (OSError, ValueError, KeyError, TypeError, psutil.Error):
            pass
        return []

    def status(self):
        processes = self.processes()
        result = {'running': bool(processes), 'connection': 'The host has stopped',
                  'device': {'connected': False, 'port': os.environ.get('TESSERA_PORT', DEFAULT_PORT)}}
        if not processes:
            return result
        result['connection'] = 'Waiting for the panel'
        try:
            runtime = json.loads(self.runtime_path.read_text(encoding='utf-8'))
            if runtime.get('pid') != processes[0].pid or time.time() - float(runtime.get('updated', 0)) > 5:
                return result
            result['device'].update({key: runtime.get(key) for key in
                                     ('connected', 'port', 'profile', 'page', 'buttons', 'error',
                                      'foreground', 'auto_profile', 'last_action', 'firmware', 'protocol', 'board', 'reset', 'layout_bytes', 'sensor_hint')})
            result['agents'] = runtime.get('agents', {})
            result['agent_states'] = runtime.get('agent_states', {})
            result['mixer'] = runtime.get('mixer', [])
            result['remote_devices'] = runtime.get('remote_devices', [])
            result['notices'] = runtime.get('notices', [])
            result['variables'] = runtime.get('variables', {})
            result['plugins'] = runtime.get('plugins', [])
            # Label previews in the editor resolve $(var:…) and $(stat:…) like the panel does.
            result['vars'] = runtime.get('vars', {})
            result['stats'] = runtime.get('stats', {})
            result['device']['gauges'] = runtime.get('gauges', {})
            result['device']['widgets'] = runtime.get('widgets', {})
            result['connection'] = ('Panel connected' if runtime.get('connected')
                                    else runtime.get('error') or 'Waiting for the panel')
        except (OSError, ValueError, TypeError):
            pass
        return result

    def start(self, root=None, emit=lambda _: None, warn=None):
        """Start the host. `warn` gets what the user must know even when nothing else is shown (a restored backup)."""
        if firmware_installing():  # the tray, the terminal and the editor all start the host through here
            raise RuntimeError('The panel firmware is being installed. The host starts again when it is done.')
        if self.processes():
            emit('The deck host is already running.')
            return
        port = os.environ.get('TESSERA_PORT', DEFAULT_PORT)
        from tesserad import Daemon, shift_logs
        profiles = ROOT / 'host/profiles.json'
        log_path = ROOT / 'host/deck.local.log'
        try:  # the log is appended to on every start: keep three previous files instead of growing forever
            if log_path.stat().st_size > MAX_LOG_BYTES:
                os.replace(log_path, shift_logs(log_path))
        except OSError:
            pass
        try:
            restored = config_store.recover(profiles)
        except OSError:
            restored = None  # loading it below says what is wrong
        if restored:
            message = (f'profiles.json could not be used, so the backup {restored} was restored. '
                       'The broken file is kept as profiles-unreadable.local.json.')
            with log_path.open('a', encoding='utf-8') as stream:
                stream.write(f'[{time.strftime("%H:%M:%S")}] {message}\n')
            (warn or emit)(message)
        Daemon.load_profiles(profiles)
        log = log_path.open('ab')
        try:
            process = subprocess.Popen([sys.executable, str(ROOT / 'host/tesserad.py'), '--port', port],
                cwd=ROOT, stdout=log, stderr=subprocess.STDOUT,
                env=dict(os.environ, PYTHONUTF8='1', PYTHONUNBUFFERED='1'),
                creationflags=NO_WINDOW)
        finally:
            log.close()
        self.children.append(process)
        current = psutil.Process(process.pid)
        self.pid_path.write_text(json.dumps({'pid': process.pid, 'created': current.create_time()}))
        time.sleep(.3)
        if process.poll() is not None:
            raise RuntimeError('The host stopped right after it started. Open the host log (More → Host log) to see why.')
        self.processes()
        emit(f'The deck host has started on {port}.')

    def stop(self, root=None, emit=lambda _: None):
        processes = self.processes()
        for process in processes:
            self.stop_path.write_text(json.dumps({'pid': process.pid}))
        alive = wait_until_gone(processes, 8)
        for process in alive:
            process.terminate()
        alive = wait_until_gone(alive, 5)
        if alive:
            raise RuntimeError('Host did not stop; no new owner was started')
        self.stop_path.unlink(missing_ok=True)
        emit('The deck host has stopped. USB is released.')

    def install_adapters(self):
        return None
