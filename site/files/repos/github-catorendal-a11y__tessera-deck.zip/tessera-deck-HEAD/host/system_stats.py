"""Live sensor values for Tessera: the CPU, the graphics card, memory, disk and network."""
from __future__ import annotations

from lhm_reader import LibreHardwareMonitorReader
from platform_support import load
import time
from pathlib import Path

import psutil
from gpu_sources import GpuReaders


LHM_EXE = Path(__file__).resolve().parent / 'sensors' / 'LibreHardwareMonitor' / 'LibreHardwareMonitor.exe'
HINT_NOT_RUNNING = ('CPU temperature and power need Libre Hardware Monitor, which is installed but not running. '
                    'Run Tessera.cmd --sensors once: it starts at every sign-in after that.')
HINT_NOT_INSTALLED = ('CPU temperature and power need Libre Hardware Monitor. '
                      'In the Tessera folder run powershell -ExecutionPolicy Bypass -File tools\\setup_sensors.ps1, '
                      'then Tessera.cmd --sensors.')


# Sensor names that identify a graphics card on any vendor; integrated ones are demoted below.
GPU_SENSORS = ('gpu', 'radeon', 'geforce', 'nvidia', 'rtx', 'gtx', 'arc ')
INTEGRATED_GPU = ('integrated', 'radeon graphics', 'radeon(tm) graphics', 'radeon 7', 'uhd graphics', 'iris', 'vega ', 'intel(r) graphics')
DISCRETE_GPU = ('geforce', 'rtx', 'gtx', 'quadro', 'nvidia', 'radeon rx', 'rx ', 'arc a', 'arc b', 'radeon pro')


def gpu_discrete_bonus(sensor: str) -> int:
    """Prefer a discrete graphics card over the integrated one when both report sensors."""
    if any(name in sensor for name in INTEGRATED_GPU):
        return -4
    return 4 if any(name in sensor for name in DISCRETE_GPU) else 0


def _norm(value: str) -> str:
    return value.casefold().replace('°', '').strip()


def select_hwinfo_metrics(readings: list[dict]) -> dict[str, float]:
    """Pick stable desktop metrics from HWiNFO's hardware-specific labels."""
    specs = {
        'cpu_temp': (('core (tctl/tdie)', 'cpu (tctl/tdie)', 'cpu die (average)', 'cpu package',
                      'core temperatures', 'cpu die'), ('cpu', 'ryzen'), ('c',)),
        'cpu_power': (('cpu package power', 'cpu ppt', 'package power', 'package'),
                      ('cpu', 'ryzen'), ('w',)),
        'cpu_clock': (('cores (average)', 'core effective clocks', 'core clocks', 'cpu clock'),
                      ('cpu', 'ryzen'), ('mhz',)),
        'gpu_temp': (('gpu temperature', 'gpu core', 'gpu hotspot temperature', 'gpu hot spot'),
                      GPU_SENSORS, ('c',)),
        'gpu_load': (('gpu core load', 'gpu utilization', 'gpu d3d usage', 'gpu core'),
                      GPU_SENSORS, ('%',)),
        'gpu_power': (('gpu power', 'gpu asic power', 'total graphics power', 'gpu package', 'gpu core'),
                       GPU_SENSORS, ('w',)),
        'gpu_clock': (('gpu clock', 'gpu effective clock', 'gpu core'),
                       GPU_SENSORS, ('mhz',)),
        'gpu_fan': (('gpu fan', 'fan speed'), GPU_SENSORS, ('rpm',)),
        'vram': (('gpu memory usage', 'gpu memory utilization', 'vram usage'),
                  GPU_SENSORS, ('%',)),
    }
    selected = {}
    for key, (labels, sensors, units) in specs.items():
        best = None
        for item in readings:
            label = _norm(str(item.get('label', '')))
            sensor = _norm(str(item.get('sensor', '')))
            unit = _norm(str(item.get('unit', '')))
            label_rank = next((len(labels) - i for i, name in enumerate(labels)
                               if label == name or name in label), 0)
            if not label_rank or unit not in units:
                continue
            sensor_rank = sum(term in sensor for term in sensors)
            if not sensor_rank:
                continue  # a generic label such as 'Package' must come from the right chip
            discrete_bonus = gpu_discrete_bonus(sensor) if key.startswith(('gpu', 'vram')) else 0
            score = label_rank * 10 + sensor_rank + discrete_bonus
            if best is None or score > best[0]:
                best = (score, float(item['value']))
        if best is not None:
            selected[key] = best[1]
    return selected


def select_presentmon_fps(readings: list[dict]) -> float | None:
    """Use PresentMon's presented frame rate, never display refresh rate or frame time."""
    for item in readings:
        label = _norm(str(item.get('label', '')))
        if ('presentmon' in _norm(str(item.get('sensor', '')))
                and label in ('framerate (presented)', 'framerate presented (avg)')
                and _norm(str(item.get('unit', ''))) in ('fps', 'frames/s')):
            value = float(item['value'])
            if 0 < value < 10000:
                return value
    return None


def _rate(value: float) -> str:
    if value >= 1024 * 1024:
        return f'{value / 1024 / 1024:.1f}M'
    if value >= 1024:
        return f'{value / 1024:.0f}K'
    return f'{value:.0f}B'


def _uptime(seconds: float) -> str:
    days, remainder = divmod(max(0, int(seconds)), 86400)
    hours, minutes = divmod(remainder, 3600)[0], (remainder % 3600) // 60
    return f'{days}d {hours}h' if days else f'{hours}h {minutes}m'


class SystemStats:
    def __init__(self, hwinfo=None, lhm=None, counters=None, gpu=None):
        sensors = load('sensors')
        self.hwinfo = hwinfo or sensors.hwinfo_reader()
        self.lhm = lhm or LibreHardwareMonitorReader()
        frequency = psutil.cpu_freq()
        self.native_sensors = counters is None and sensors.NATIVE_SENSORS  # Linux: hwmon, the amdgpu files and nvidia-smi
        self.counters = counters or sensors.native_counters(frequency.max if frequency else None)
        # Tests that inject their own counters get no real graphics-driver readings unless they ask for them.
        self.gpu = gpu if gpu is not None else (GpuReaders() if counters is None else GpuReaders([]))
        self.raw: dict[str, float] = {}
        self.display = {key: '--' for key in (
            'cpu_temp', 'cpu_load', 'cpu_power', 'cpu_clock', 'gpu_temp',
            'gpu_load', 'gpu_power', 'gpu_clock', 'gpu_fan', 'ram', 'vram',
            'disk', 'net_down', 'net_up', 'uptime', 'fps')}
        self.display['sensor_status'] = 'BASIC'
        self.hint = ''  # why temperatures may be missing and what to do about it
        self._net = psutil.net_io_counters()
        self._net_at = time.monotonic()
        psutil.cpu_percent(None)

    def sample(self) -> dict[str, str]:
        now = time.monotonic()
        cpu = psutil.cpu_percent(None)
        ram = psutil.virtual_memory().percent
        drive = load('sensors').disk_root()
        try:
            disk = psutil.disk_usage(drive).percent
        except OSError:
            disk = 0.0
        net = psutil.net_io_counters()
        elapsed = max(.1, now - self._net_at)
        down = max(0, net.bytes_recv - self._net.bytes_recv) / elapsed
        up = max(0, net.bytes_sent - self._net.bytes_sent) / elapsed
        self._net, self._net_at = net, now
        lhm_readings = self.lhm.read()
        hwinfo_readings = self.hwinfo.read()
        readings = lhm_readings or hwinfo_readings
        sensor_values = select_hwinfo_metrics(readings)
        # Sensor tools win; Windows counters, then the graphics-driver readers fill what they leave empty.
        # nvidia-smi is a process start: skip the graphics-driver readers when a sensor tool has the GPU already.
        gpu = {} if {'gpu_temp', 'gpu_load'} <= sensor_values.keys() else self.gpu.sample()
        merged = {**gpu, **self.counters.sample(), **sensor_values}
        fps = select_presentmon_fps(hwinfo_readings)
        if fps is not None:
            merged['fps'] = fps
        self.raw = dict(merged, cpu_load=cpu, ram=ram, disk=disk, net_down=down, net_up=up,
                        uptime=time.time() - psutil.boot_time(), sensors=1.0 if readings else 0.0)
        for key in ('cpu_temp', 'cpu_load', 'cpu_power', 'gpu_temp', 'gpu_load',
                    'gpu_power', 'ram', 'vram', 'disk', 'fps'):
            value = self.raw.get(key)
            self.display[key] = '--' if value is None else f'{value:.0f}'
        for key in ('cpu_clock', 'gpu_clock'):
            value = self.raw.get(key)
            self.display[key] = '--' if value is None else f'{value:.0f}'
        fan = self.raw.get('gpu_fan')
        self.display['gpu_fan'] = '--' if fan is None else f'{fan:.0f}'
        self.display['net_down'] = _rate(down)
        self.display['net_up'] = _rate(up)
        self.display['uptime'] = _uptime(time.time() - psutil.boot_time())
        self.display['sensor_status'] = 'LIVE' if readings else 'BASIC'
        self.hint = '' if readings or self.native_sensors else HINT_NOT_RUNNING if LHM_EXE.is_file() else HINT_NOT_INSTALLED
        return dict(self.display)


MISSING_COLOR = '#4A5A63'
WARN_COLOR = '#FFB74D'
CRITICAL_COLOR = '#FF7070'


def _format_gauge_text(value: float, spec: dict) -> str:
    fmt = spec.get('fmt', 'int')
    unit = spec.get('unit', '')
    if fmt == 'clock':
        from live_state import clock_text
        return clock_text(value)
    if fmt == 'ghz':
        return f'{value / 1000:.1f}GHz' if value >= 1000 else f'{value:.0f}MHz'
    if fmt == 'gb':
        return f'{value:.1f}GB'
    if fmt == 'rate':
        return _rate(value)
    if fmt == 'live':
        return 'LIVE' if value >= 1 else 'BASIC'
    if fmt == 'uptime':
        days, remainder = divmod(max(0, int(value)), 86400)
        if days:
            return f'{days}d'
        return f'{remainder // 3600}h' if remainder >= 3600 else f'{remainder // 60}m'
    return f'{value:.0f}{unit}'


def gauge_state(spec: dict, raw: dict[str, float], base_color: str) -> dict:
    """Ring percent, centre text and color for a gauge button; '--' when unavailable."""
    value = raw.get(spec['key'])
    if value is None:
        return {'p': 0, 't': '--', 'color': MISSING_COLOR}
    limit = float(spec.get('max', 100)) or 100.0
    percent_value = raw.get(spec['percent_key'], value) if spec.get('percent_key') else value
    if spec.get('scale') == 'log':
        import math
        fraction = math.log10(1 + max(0.0, percent_value)) / math.log10(1 + limit)
    else:
        fraction = percent_value / limit
    color = base_color
    if percent_value >= spec.get('critical', float('inf')):
        color = CRITICAL_COLOR
    elif percent_value >= spec.get('warn', float('inf')):
        color = WARN_COLOR
    return {'p': max(0, min(100, round(fraction * 100))), 't': _format_gauge_text(value, spec)[:7],
            'color': color}
