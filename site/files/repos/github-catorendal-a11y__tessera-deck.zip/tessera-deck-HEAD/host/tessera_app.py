"""Local graphical editor for the standalone Tessera."""
from default_profile import seed_path
from process_flags import NEW_CONSOLE, NO_WINDOW
from desktop import open_path
from platform_support import IS_WINDOWS, load
from venv_paths import venv_python
import argparse
import zipfile
import copy
import hashlib
from functools import lru_cache
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler
import json
import os
from pathlib import Path
import secrets
import signal
import subprocess
import sys
import threading
import time
import urllib.request
import urllib.parse
import webbrowser

from deck_control import (FIRMWARE_FLAG_PATH, ROOT, Controller, autostart_enabled,
                          save_profiles, set_autostart)
from tesserad import SUPPORTED_PROTOCOLS, Daemon, DeviceRejected, PanelSerial, validate_config
from deck_assets import Assets
import ambient
import config_store
from control_api import REQUEST_TIMEOUT, ExclusiveServer
import diagnostics
import firmware_update
import iconify
import plugins
import updates
from host_runtime import InstanceLock
from action_preview import preview
from import_review import export_left_out, redact_secrets, review, strip_executable

WEB = Path(__file__).with_name('editor')


def editor_build_id():
    """Fingerprint every file cached or imported by the long-lived editor."""
    digest = hashlib.sha256()
    files = [Path(__file__), ROOT / 'host/deck_control.py', ROOT / 'host/deck_assets.py',
             ROOT / 'host/tesserad.py', ROOT / 'host/config_check.py', ROOT / 'host/panel_serial.py',
             ROOT / 'host/input_common.py', ROOT / 'host/desktop.py', ROOT / 'host/default_profile.py', ROOT / 'host/action_packs.json',
             *sorted((ROOT / 'host/platform_windows').glob('*.py')), *sorted((ROOT / 'host/platform_linux').glob('*.py')),
             WEB / 'index.html', WEB / 'style.css', WEB / 'streamdeck.css', WEB / 'cockpit.css', WEB / 'core.js', WEB / 'app.js', WEB / 'dialogs.js']
    for path in files:
        digest.update(path.name.encode('utf-8'))
        digest.update(path.read_bytes())
    return digest.hexdigest()


def activate_window(pid):
    """Restore the existing native editor instead of opening a duplicate (Windows; elsewhere the editor is a browser tab)."""
    return load('editor_window').activate_window(pid)


@lru_cache(maxsize=1)
def icon_catalog():
    return json.loads((ROOT / 'vendor/lucide/catalog.json').read_text(encoding='utf-8'))


@lru_cache(maxsize=1)
def icon_ids():
    return frozenset(item['id'] for item in icon_catalog()['icons'])


@lru_cache(maxsize=1)
def action_pack_catalog():
    catalog = json.loads((ROOT / 'host/action_packs.json').read_text(encoding='utf-8'))
    if catalog.get('version') != 1 or not isinstance(catalog.get('packs'), list) or not isinstance(catalog.get('templates'), list):
        raise ValueError('Invalid action pack')
    for index, pack in enumerate(catalog['packs'], 1):
        profile = {'match': [], 'pages': {'main': [{
            'id': 1, 'label': pack.get('label', pack.get('name', '')), 'icon': pack.get('icon', 'ok'),
            'color': pack.get('color', '#35D07F'), 'actions': pack.get('actions', []),
            **{field: pack[field] for field in ('confirm', 'states', 'bind') if field in pack}}]}}
        if not isinstance(pack.get('note', ''), str):
            raise ValueError('The action pack note must be text')
        validate_config({'default_profile': 'pakke', 'profiles': {'pakke': profile}})
        pack['id'] = f'pack-{index}'
    for template in catalog['templates']:
        if not isinstance(template.get('description'), str):
            raise ValueError('The profile template needs a description')
        validate_config({'default_profile': template.get('name'),
                         'profiles': {template.get('name'): template.get('profile')}})
    for template in catalog.get('page_templates', []):
        if not isinstance(template.get('name'), str) or not isinstance(template.get('description'), str):
            raise ValueError('The page template needs a name and a description')
        validate_config({'default_profile': 'mal', 'profiles': {'mal': {'match': [], 'pages': {'side': template.get('page')}}}})
    # What a save is checked against, so the editor can hold a step back with a reason instead of sending a file
    # the host refuses whole.
    from input_common import KEY_NAMES
    from script_files import SCRIPT_SUFFIXES
    catalog['rules'] = {'keys': list(KEY_NAMES), 'platform': 'win32' if IS_WINDOWS else 'linux', 'scripts': list(SCRIPT_SUFFIXES)}
    return catalog


def brand_taskbar_identity():
    """Give this process its own Windows identity, so the taskbar shows the editor's own icon."""
    load('editor_window').brand_taskbar_identity()


WINDOW_FILE = ROOT / 'host/window.local.json'
MIN_WINDOW = (1050, 640)


def window_geometry(screen, saved_file=WINDOW_FILE):
    """Width, height, x and y for the editor window: the last one used, kept on the screen, or one that fits the screen.

    x and y are None when nothing is saved; the window then fills the work area once it is shown.
    """
    sw, sh = screen.width, screen.height
    try:
        saved = json.loads(saved_file.read_text(encoding='utf-8'))
        width = max(min(int(saved['width']), sw), min(MIN_WINDOW[0], sw))  # a minimized window reports a tiny size
        height = max(min(int(saved['height']), sh), min(MIN_WINDOW[1], sh))
        x = min(max(int(saved['x']), screen.x), screen.x + sw - width)  # a window closed off-screen comes back on it
        y = min(max(int(saved['y']), screen.y), screen.y + sh - height)
        return width, height, x, y
    except (OSError, ValueError, KeyError, TypeError):
        return min(1600, int(sw * .92)), min(1000, int(sh * .88)), None, None


def save_window_geometry(geometry, saved_file=WINDOW_FILE):
    if {'width', 'height', 'x', 'y'} <= geometry.keys():
        try:
            saved_file.write_text(json.dumps(geometry), encoding='utf-8')
        except OSError:
            pass


def open_window(launch_url):
    """Open the editor in a native window (Windows: WebView2); anything else, or a failure, opens a browser tab. Returns
    False for the browser. `launch_url()` gives an address with a one-time code: the browser gets one of its own, since
    a window that failed after it had loaded the page has used the first."""
    if load('editor_window').open_native_window(launch_url(), window_geometry, save_window_geometry, MIN_WINDOW, ROOT):
        return True
    webbrowser.open(launch_url())
    return False


class Conflict(ValueError):
    pass


PROGRAMS_TTL = 60
_programs_cache = (0.0, None)


def installed_programs():
    """The program list, kept for a minute: each pick of a program asks for it and the scan runs PowerShell."""
    global _programs_cache
    taken, programs = _programs_cache
    if programs is None or time.monotonic() - taken > PROGRAMS_TTL:
        programs = scan_programs()
        _programs_cache = (time.monotonic(), programs)
    return [dict(item) for item in programs]


def scan_programs():
    """Return the programs of the system's menu (Windows: Start menu and Store apps; Linux: .desktop entries)."""
    return load('shell').scan_programs()


def shortcut_target(path):
    return load('shell').shortcut_target(path)


class Editor:
    def __init__(self, profiles=None, controller=None, dashboard=None):
        self.path = Path(profiles or ROOT / 'host/profiles.json')
        if not self.path.exists():  # first run: the window may open before the host has created the file
            Daemon.load_profiles(self.path)
        self.controller = controller or Controller()
        self.dashboard = dashboard
        self.lock = threading.RLock()
        self.assets = Assets(self.path)
        self.firmware_job = {'state': 'idle'}
        self.last_release = None  # what the last update check found; downloads never trust client-sent URLs
        self.firmware_lock = threading.Lock()
        self.served = {}  # revision -> the configuration read then, so a save can follow a tray brightness change

    def _raw(self):
        # The file as it is on disk; empty when it is missing or locked, so a restore can still replace it.
        try:
            return self.path.read_bytes()
        except OSError:
            return b''

    def read(self):
        raw = self.path.read_bytes()
        config = validate_config(config_store.migrate(json.loads(raw)))
        revision = hashlib.sha256(raw).hexdigest()
        with self.lock:  # GET handlers run on several server threads
            self.served[revision] = copy.deepcopy(config)
            while len(self.served) > 16:
                del self.served[next(iter(self.served))]
        return {'config': self.assets.heal(config), 'revision': revision}

    def rebase(self, data, raw):
        """`data` on top of a file changed only in what the tray menu writes (display.brightness and
        notifications) since the editor read it: the editor keeps its edits, and the tray's value stays
        for each one the editor did not change itself. Anything else conflicts."""
        base = self.served.get(data.get('revision'))
        try:
            disk = config_store.migrate(json.loads(raw))
        except (ValueError, TypeError, KeyError, AttributeError):
            disk = None
        def without_tray(config):
            config, taken = copy.deepcopy(config), {}
            if not isinstance(config, dict):
                return config, taken
            display = config.get('display')
            if isinstance(display, dict) and 'brightness' in display:
                taken['brightness'] = display.pop('brightness')
                if display == {}:
                    del config['display']
            if 'notifications' in config:
                taken['notifications'] = config.pop('notifications')
            return config, taken
        if base is None or disk is None or without_tray(base)[0] != without_tray(disk)[0]:
            raise Conflict('The configuration was changed in another window. Reload before saving.')
        config = copy.deepcopy(data['config'])
        if isinstance(config, dict):
            mine, before, tray = without_tray(config)[1], without_tray(base)[1], without_tray(disk)[1]
            for key in ('brightness', 'notifications'):
                if mine.get(key, Conflict) != before.get(key, Conflict):
                    continue  # changed in the editor: the editor's value wins
                target = config.setdefault('display', {}) if key == 'brightness' else config
                if not isinstance(target, dict):
                    continue
                if key in tray:
                    target[key] = tray[key]
                else:
                    target.pop(key, None)
        return dict(data, config=config, revision=hashlib.sha256(raw).hexdigest())

    def read_for_editor(self):
        """read(), or the bundled defaults with an `error` when profiles.json is broken or from a newer Tessera.

        The editor needs some configuration to open at all, and opening is how the user reaches Restore backup.
        The revision is the broken file's, and save() refuses to overwrite it except by a restore.
        """
        try:
            return self.read()
        except (ValueError, TypeError, KeyError, AttributeError) as exc:
            raw = self._raw()
            defaults = validate_config(config_store.migrate(json.loads(seed_path(ROOT / 'host').read_bytes())))
            return {'config': defaults, 'revision': hashlib.sha256(raw).hexdigest(),
                    'error': f'profiles.json could not be read ({str(exc)[:200]}). Restore a backup or fix the file.'}

    def save(self, data, force_backup=False):
        with self.lock:
            raw = self._raw()
            if data.get('revision') != hashlib.sha256(raw).hexdigest():
                data = self.rebase(data, raw)
            try:
                previous = self.read()
            except (OSError, ValueError, TypeError, KeyError, AttributeError) as exc:
                # A broken (or newer) file may only be replaced by a restore, which keeps its bytes below.
                if not force_backup:
                    raise ValueError('profiles.json could not be read, so it is not overwritten. Restore a backup or fix the file.') from exc
                previous = None
            config = config_store.migrate(data['config'])
            validate_config(config)
            # Bound editor-only fields before they reach the shared action engine.
            for name, profile in config['profiles'].items():
                if not name.strip() or len(name) > 100:
                    raise ValueError('Use a profile name of 1-100 characters')
                if any(not isinstance(item, str) for item in profile.get('match', [])):
                    raise ValueError('Program rules must be text')
                for page, buttons in profile['pages'].items():
                    if not page.strip() or len(page) > 100:
                        raise ValueError('Use a page name of 1-100 characters')
                    for button in buttons:
                        icon = button.get('icon', 'ok')
                        if not isinstance(icon, str):
                            raise ValueError('The icon must be a name')
                        if icon.startswith('lc:') and icon not in icon_ids():
                            raise ValueError('The icon is not in the installed icon pack')
                        for action in button.get('actions', []):
                            if action['type'] == 'delay' and type(action.get('ms', 100)) is not int:
                                raise ValueError('The delay must be a whole number of milliseconds')
            config_store.backup(self.path, force=force_backup)
            backup = self.path.with_name(self.path.stem + '-previous.local.json')
            if previous is not None:
                save_profiles(previous['config'], backup)
            elif raw:
                backup.write_bytes(raw)  # the unreadable file, kept byte for byte
            if self._raw() not in (raw, b''):
                # The tray, the host or the terminal saved during the checks above (the lock only holds this
                # program back), so this save starts over against their file and keeps or refuses their change.
                return self.save(data, force_backup)
            save_profiles(config, self.path)
            return self.read()

    def status(self):
        result = self.dashboard() if self.dashboard else self.controller.status()
        return dict(result, autostart=autostart_enabled(), host_version=self.version())

    def programs(self):
        return {'programs': installed_programs()}

    def program_details(self, target, allowed_only=True):
        if not isinstance(target, str) or not target.strip() or len(target) > 2048:
            raise ValueError('Choose a valid program')
        programs = installed_programs()
        allowed = {item['target'] for item in programs}
        if allowed_only and target not in allowed:
            raise ValueError('The program is not in the local program list')
        info = load('programs').describe(target)
        matched = next((item for item in programs if item['target'] == target), None)
        try:
            icon = self.assets.import_program_icon(target)['id']
        except (ValueError, OSError):
            icon = 'folder'
        return {'name': matched['name'] if matched else info['name'], 'target': target, 'process': info['process'],
                'icon': icon, 'reuse': bool(info['process'])}

    def icon_preferences(self, data=None):
        path = self.path.with_name('icon-library.local.json')
        if data is None:
            try:
                data = json.loads(path.read_text(encoding='utf-8'))
            except (OSError, ValueError):
                data = {}
            if not isinstance(data, dict):
                data = {}
            return {key: [value for value in (data.get(key, []) if isinstance(data.get(key, []), list) else [])
                          if isinstance(value, str) and value in icon_ids()][:limit]
                    for key, limit in (('favorites', 512), ('recent', 24))}
        result = {}
        for key, limit in (('favorites', 512), ('recent', 24)):
            values = data.get(key, [])
            if not isinstance(values, list) or len(values) > limit or any(not isinstance(v, str) or v not in icon_ids() for v in values):
                raise ValueError('Invalid icon list')
            result[key] = list(dict.fromkeys(values))
        with self.lock:
            temporary = path.with_suffix('.tmp')
            temporary.write_text(json.dumps(result), encoding='utf-8')
            temporary.replace(path)
        return result

    # --- firmware installation -----------------------------------------------------------
    def firmware_folders(self):
        return [ROOT / 'dist', ROOT / 'firmware', ROOT / 'host/firmware']

    def firmware_list(self):
        status = self.status().get('device', {})
        version_file = ROOT / 'VERSION'
        return {'packages': firmware_update.find_packages(self.firmware_folders(), SUPPORTED_PROTOCOLS),
                'device': {'firmware': status.get('firmware'), 'protocol': status.get('protocol'), 'board': status.get('board'),
                           'connected': bool(status.get('connected'))},
                'host': version_file.read_text(encoding='utf-8').strip() if version_file.is_file() else None,
                'job': dict(self.firmware_job)}

    @staticmethod
    def identify_panel(port):
        # get_info of the panel on `port`; None when it stays silent; PackageError for another device.
        try:
            panel = PanelSerial(port, lambda *_: None)
        except DeviceRejected as exc:
            if exc.kind == 'silent':
                return None
            if exc.kind == 'protocol':  # for example the Wi-Fi beta: only a full install replaces it
                info = exc.info or {}
                return {'boardId': info.get('boardId', firmware_update.BOARD_ID), 'firmwareVersion': None, 'protocolUnknown': True}
            raise firmware_update.PackageError(str(exc)) from exc
        except OSError as exc:
            raise firmware_update.InstallError(f'{port} could not be opened: {exc}') from exc
        info = dict(panel.info)
        panel.close()
        return info

    def install_firmware(self, data):
        path, mode, force = data.get('package'), data.get('mode', 'app'), data.get('force', False)
        if not isinstance(path, str) or mode not in ('app', 'full') or type(force) is not bool:
            raise ValueError('Choose a firmware package and an install mode')
        package = firmware_update.load_package(Path(path), SUPPORTED_PROTOCOLS)
        if not self.firmware_lock.acquire(blocking=False):
            raise ValueError('A firmware installation is already running')
        self.firmware_job = {'state': 'running', 'stage': 'checking', 'percent': 0, 'version': package.version}
        threading.Thread(target=self.run_firmware_install, args=(package, mode, force),
                         name='firmware-install', daemon=True).start()
        return {'message': f'Installing firmware {package.version} ...'}

    def firmware_port(self):
        # The first candidate is only TESSERA_PORT/COM4 when no panel is remembered, so it is not trusted: the port
        # whose device answers as a panel wins. Without an answer (a blank panel) only a lone Espressif port is used,
        # so "Install anyway" never writes to another device or to a second ESP32.
        import host_runtime
        try:
            installed = host_runtime._installed_ports()
            espressif = sorted(host_runtime._espressif_ports())
        except (ImportError, OSError):
            installed, espressif = {}, []
        ports = [port for port in host_runtime.candidate_ports(os.environ.get('TESSERA_PORT', host_runtime.DEFAULT_PORT),
                                                               ROOT / 'host/deck-device.local.json', installed, espressif)
                 if port in installed]
        rejected = set()
        for port in ports:
            try:
                if self.identify_panel(port) is not None:
                    return port
            except firmware_update.PackageError:
                rejected.add(port)  # another device answered: never flash it, not even as the lone Espressif port
            except firmware_update.InstallError:
                continue  # a port that is busy: try the next one
        if len(espressif) == 1 and espressif[0] not in rejected:
            return espressif[0]
        if not ports:
            raise firmware_update.InstallError('No USB port was found. Connect the panel with the USB cable.')
        raise firmware_update.InstallError(f'No Tessera panel answered on {", ".join(ports)}. Unplug the other '
                                           'USB serial devices, or connect only the panel, and try again.')

    def run_firmware_install(self, package, mode, force):
        was_running = bool(self.controller.processes())
        outcome = {'state': 'failed', 'error': 'The install was interrupted'}
        try:
            # the tray greys out Start host and holds its "host is not running" notice while this file exists
            try:
                FIRMWARE_FLAG_PATH.write_text(json.dumps({'pid': os.getpid()}), encoding='utf-8')
            except OSError:
                pass  # the editor still refuses Start; a missing flag must not block the install
            if was_running:
                self.controller.stop()  # the host is the only owner of the USB port

            def progress(stage, percent):
                self.firmware_job = dict(self.firmware_job, stage=stage, percent=round(percent))

            result = firmware_update.install(package, self.firmware_port(), self.identify_panel, mode, force, progress)
            outcome = {'state': 'done', 'stage': 'done', 'percent': 100, 'result': result}
        except Exception as exc:  # whatever went wrong, the job must not stay "running" forever
            outcome = {'state': 'failed', 'error': str(exc) or type(exc).__name__}
        finally:
            # the outcome is published after the restart, so the dialog never says the host is back before it is
            try:
                FIRMWARE_FLAG_PATH.unlink(missing_ok=True)  # before the restart, which the flag would refuse
                if was_running:
                    self.controller.start()
                    outcome['restarted'] = True
            except Exception as exc:
                outcome['restart_error'] = str(exc) or type(exc).__name__
            self.firmware_job = dict(self.firmware_job, **outcome)
            self.firmware_lock.release()

    def dry_run(self, data):
        # What pressing a button would do, explained without doing any of it.
        groups = {key: data.get(key) for key in ('actions', 'hold_actions', 'double_actions') if data.get(key) is not None}
        if not groups or any(not isinstance(value, list) or len(value) > 50
                             or any(not isinstance(item, dict) for item in value) for value in groups.values()):
            raise ValueError('Send the button actions as lists of at most 50 steps')
        status = self.status()
        variables = status.get('variables') or {}
        return {key: preview(value, variables, plugins=status.get('plugins')) for key, value in groups.items()}

    def version(self):
        version_file = ROOT / 'VERSION'
        return version_file.read_text(encoding='utf-8').strip() if version_file.is_file() else '0.0.0'

    def check_updates(self):
        try:
            self.last_release = updates.check(self.version(), board=self.status().get('device', {}).get('board'))
        except OSError as exc:
            raise ValueError('GitHub could not be reached. Check your internet connection.') from exc
        return self.last_release

    def download_firmware(self):
        if not self.last_release:
            raise ValueError('Check for updates first')
        try:
            path = updates.download_firmware(self.last_release, ROOT / 'firmware')
        except OSError as exc:
            raise ValueError('The download failed. Check your internet connection and try again.') from exc
        return {'path': str(path), 'message': f'Downloaded and verified {path.name}. Choose it in the firmware list.'}

    def install_host_update(self):
        """Download the program of the release the check found and unpack it over this folder. Profiles, icons and
        backups are not in a release and stay. The running programs keep the old code until they are started again."""
        if not self.last_release:
            raise ValueError('Check for updates first')
        if not self.last_release.get('newer'):
            raise ValueError('This is already the newest version')
        import tempfile
        try:
            with tempfile.TemporaryDirectory() as folder:
                written = updates.install_host(updates.download_host(self.last_release, Path(folder)), ROOT)
        except PermissionError as exc:
            raise ValueError(f'A file is in use and could not be replaced: {Path(exc.filename or "").name}. '
                             'Quit Tessera from the tray icon, start it again and update once more.') from exc
        except OSError as exc:
            raise ValueError('The update could not be downloaded or written. Check your internet connection and try again.') from exc
        except zipfile.BadZipFile as exc:
            raise ValueError('The update file cannot be read as a zip; nothing was changed.') from exc
        latest = self.last_release['latest']
        self.restart_soon()
        return {'version': latest, 'files': written,
                'message': f'Tessera {latest} is in place and starts again now. '
                           'Then update the panel here if this dialog offers newer firmware.'}

    @staticmethod
    def restart_soon():
        """Start Tessera again from the files that were just unpacked: its own process, so it outlives this one."""
        from process_flags import DETACHED, NO_WINDOW
        subprocess.Popen([sys.executable, str(ROOT / 'host/setup_tool.py'), 'restart'], cwd=str(ROOT),
                         creationflags=NO_WINDOW | DETACHED, start_new_session=not IS_WINDOWS,
                         stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    def export_diagnostics(self):
        try:
            config = self.read()['config']
        except (OSError, ValueError, TypeError, KeyError, AttributeError):
            config = None  # a broken profile file is when the bundle is needed most
        target = diagnostics.build(ROOT / 'diagnostics', config, self.status(), self.version(),
                                   ROOT / 'host/deck.local.log')
        open_path(target.parent)
        return {'path': str(target), 'message': f'Saved {target.name} in the diagnostics folder. It contains no button contents.'}

    def claude_hooks(self, data):
        """Read (no `events`/`permission` in data) or change the Claude Code hooks that feed the agents screen."""
        import claude_setup
        if 'events' not in data and 'permission' not in data:
            return claude_setup.state()
        python = venv_python(ROOT)
        return claude_setup.update(data.get('events'), data.get('permission'), python if python.is_file() else Path(sys.executable),
                                   ROOT / 'host/deckctl.py')

    def plugin_list(self):
        # Installed plugins with their configuration and, when the host runs, their live state.
        manifests, problems = plugins.discover(ROOT / 'plugins')
        live = {item['id']: item for item in self.status().get('plugins', [])}
        configured = self.read()['config'].get('plugins', {})
        rows = []
        for manifest in manifests:
            entry = configured.get(manifest.id, {})
            enabled = bool(entry.get('enabled'))
            state = live.get(manifest.id, {})
            rows.append({'id': manifest.id, 'name': manifest.name, 'version': manifest.version,
                         'permissions': sorted(manifest.permissions), 'settings': manifest.settings, 'enabled': enabled,
                         'values': entry.get('settings', {}),
                         'state': state.get('state', 'starting' if enabled else 'disabled') if enabled else 'disabled',
                         'error': state.get('error', '')})
        return {'plugins': rows, 'problems': problems}

    def restore_backup(self, name):
        # Put a backup back in place; the configuration it replaces is backed up first.
        config = config_store.read_backup(self.path, name)
        validate_config(config)
        # The raw hash, not read(): the file being replaced may be the broken one this restore is for.
        return self.save({'config': config, 'revision': hashlib.sha256(self._raw()).hexdigest()}, force_backup=True)

    SETUP_KEYS = {'welcome_done': bool, 'key_edited': bool, 'key_pressed': bool, 'firmware_hint_dismissed': str}

    def setup_state(self, changes=None):
        """First-run flags in setup.local.json. The first read writes the file, so the answer stays put:
        a deck that still equals the starter set is a first run, an edited one (an upgrade) is not."""
        path = self.path.with_name('setup.local.json')
        with self.lock:
            try:
                state = json.loads(path.read_text(encoding='utf-8'))
                if not isinstance(state, dict):
                    raise ValueError
            except (OSError, ValueError):
                seed = seed_path(self.path.parent)
                state = {'welcome_done': not seed.exists() or self._raw() != seed.read_bytes()}
                changes = changes or {}
            state = {key: value for key, value in state.items() if type(value) is self.SETUP_KEYS.get(key)}
            if changes is not None:
                for key, value in changes.items():
                    if type(value) is not self.SETUP_KEYS.get(key):
                        raise ValueError('Unknown setup setting')
                state.update(changes)
                temporary = path.with_suffix('.tmp')
                temporary.write_text(json.dumps(state), encoding='utf-8')
                temporary.replace(path)
            return state

    def command(self, command, data):
        if command == 'setup-state':
            return self.setup_state()
        if command == 'setup-done':
            return self.setup_state(data)
        if command == 'host-log':
            lines = data.get('lines')
            return {'log': diagnostics.log_tail(ROOT / 'host/deck.local.log', lines if isinstance(lines, int) else 200)}
        if command == 'update-check':
            return self.check_updates()
        if command == 'update-download-firmware':
            return self.download_firmware()
        if command == 'update-install-host':
            return self.install_host_update()
        if command == 'diagnostics':
            return self.export_diagnostics()
        if command == 'claude-hooks':
            return self.claude_hooks(data)
        if command == 'plugins':
            return self.plugin_list()
        if command == 'backups':
            return {'backups': config_store.list_backups(self.path)}
        if command == 'restore-backup':
            return self.restore_backup(data.get('name'))
        if command == 'keep-backup':
            return {'name': config_store.keep_backup(self.path, data.get('name'), data.get('keep') is True)}
        if command == 'dryrun':
            return self.dry_run(data)
        if command in ('iconify-search', 'iconify-svg'):
            try:
                if command == 'iconify-search':
                    return {'icons': iconify.search(str(data.get('query', '')))}
                return {'svg': iconify.svg(str(data.get('id', '')), str(data.get('color', '#FFFFFF')))}
            except OSError as exc:
                raise ValueError('The icon service could not be reached. Check your internet connection.') from exc
        if command == 'weather-search':
            try:
                return {'places': ambient.search_places(str(data.get('query', '')))}
            except OSError as exc:
                raise ValueError('The city search could not be reached. Check your internet connection.') from exc
        if command == 'firmware-list':
            return self.firmware_list()
        if command == 'firmware-install':
            return self.install_firmware(data)
        if command == 'firmware-progress':
            return {'job': dict(self.firmware_job)}
        if command == 'review':
            config = validate_config(data.get('config') or {})
            return {'findings': review(config)}
        if command == 'sanitize':
            return {'config': strip_executable(validate_config(data.get('config') or {}))}
        if command in ('activate', 'run-key'):
            config = self.read()['config']
            profile, page = data.get('profile'), data.get('page')
            if profile not in config['profiles'] or page not in config['profiles'][profile]['pages']:
                raise ValueError('Choose a valid profile and page')
            sent = {'profile': profile, 'page': page}
            if command == 'run-key':  # Run now in the editor: the host shows the page and presses the key, as the panel would
                button = data.get('button')
                if type(button) is not int or not 1 <= button <= 18:
                    raise ValueError('Choose a key from 1 to 18')
                if not self.status().get('device', {}).get('connected'):
                    raise ValueError('Connect the panel and start the host first. The host runs the key.')
                sent.update(press=button, at=time.time())
            path = ROOT / 'host/deck-command.local.json'
            temporary = path.with_suffix('.tmp')
            with self.lock:
                temporary.write_text(json.dumps(sent), encoding='utf-8')
                temporary.replace(path)
            if command == 'run-key':
                return {'message': f'Key {button} was sent to the host. The panel shows this page and runs it.'}
            return {'message': 'The page was sent to the host. The panel updates when USB is connected.'}
        if command in ('start', 'stop'):
            if self.firmware_job.get('state') == 'running':
                # a host started between the panel check and esptool takes the COM port and breaks the flash
                raise ValueError('The panel firmware is being installed. The host starts again when it is done.')
            output = []
            with self.lock:
                getattr(self.controller, command)(emit=output.append)
            return {'message': 'The host has started.' if command == 'start' else 'The host has stopped.'}
        if command == 'terminal':
            subprocess.Popen([sys.executable, str(ROOT / 'host/tessera_terminal.py')], cwd=ROOT,
                             creationflags=NEW_CONSOLE)
            return {'message': 'The deck terminal has been opened.'}
        if command == 'autostart':
            enabled = data.get('enabled')
            if type(enabled) is not bool:
                raise ValueError('Choose whether automatic startup is on or off')
            set_autostart(enabled)
            return {'message': ('The USB host starts automatically at sign-in.' if enabled
                                else 'Automatic startup is turned off.')}
        if command == 'pick':
            kind = data.get('kind', 'file')
            if kind not in ('file', 'program', 'script'):
                raise ValueError('Unknown file picker')
            result = subprocess.run([sys.executable, str(ROOT / 'host/editor_file_picker.py'), kind],
                                    capture_output=True, text=True, encoding='utf-8', timeout=180,
                                    env=dict(os.environ, PYTHONUTF8='1'),
                                    creationflags=NO_WINDOW)
            if result.returncode:
                raise ValueError('The file picker could not be opened. You can paste the path into the field.')
            path = result.stdout.strip()
            if kind == 'program' and path:
                return self.program_details(path, allowed_only=False)
            return {'path': path}
        if command == 'edit-script':
            from action_runner import edit_script
            edit_script(str(data.get('path', '')))
            return {'message': 'The script was opened in your editor.'}
        if command == 'program':
            return self.program_details(data.get('target', ''))
        raise ValueError('Unknown command')


LAUNCH_CODE_SECONDS = 600  # an address nobody opened stops working; --no-browser prints one for you or a test


def make_server(editor, port=0, token=None):
    # Three kinds of key, so none is a long-lived bearer secret that a browser hands out:
    # - token: the launcher's key. It stays in the private record file and travels only in the X-Deck-Token header.
    # - launch codes: one-time codes in the address the window opens (#code). A copy left in the browser's history
    #   or on its command line is worthless once the page has used it.
    # - sessions: what a page gets for its code. It keeps it in sessionStorage, which is per port, and sends it as
    #   the X-Deck-Session header. Cookies are shared by every port on 127.0.0.1, so a page another account serves
    #   on a free port would receive them; the cookie therefore only opens the icon previews, which an <img> needs.
    token = token or secrets.token_urlsafe(32)
    launches = {}  # code -> time it was issued
    sessions = set()
    previews = set()
    keys_lock = threading.Lock()

    def launch_code():
        now = time.monotonic()
        with keys_lock:
            for code, issued in list(launches.items()):
                if now - issued > LAUNCH_CODE_SECONDS:
                    del launches[code]
            while len(launches) >= 16:
                del launches[next(iter(launches))]
            code = secrets.token_urlsafe(32)
            launches[code] = now
            return code

    def redeem(code):
        code = code.encode('utf-8', 'replace')
        with keys_lock:
            issued = None
            for known_code in list(launches):  # constant-time compares; a code works once
                if secrets.compare_digest(known_code.encode(), code):
                    issued = launches.pop(known_code)
            if issued is None or time.monotonic() - issued > LAUNCH_CODE_SECONDS:
                return None
            session, preview = secrets.token_urlsafe(32), secrets.token_urlsafe(32)
            sessions.add(session)
            previews.add(preview)
            return session, preview

    def known(keys, supplied):
        supplied = supplied.encode('utf-8', 'replace')  # str raises on non-ASCII
        with keys_lock:
            return bool(supplied) and any(secrets.compare_digest(key.encode(), supplied) for key in keys)

    class Handler(BaseHTTPRequestHandler):
        timeout = REQUEST_TIMEOUT  # a client that stalls before or during its request must not hold a thread forever

        def log_message(self, *_):
            pass  # Never log user actions, paths or session tokens.

        def headers_common(self, cache=False):
            # An image's name is the hash of its bytes, so it never changes; everything else is live.
            self.send_header('Cache-Control', 'private, max-age=86400, immutable' if cache else 'no-store')
            self.send_header('X-Content-Type-Options', 'nosniff')
            self.send_header('Referrer-Policy', 'no-referrer')
            self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; object-src 'none'; base-uri 'none'")

        def json(self, value, code=200, cookie=None):
            raw = json.dumps(value, ensure_ascii=False, allow_nan=False).encode('utf-8')
            self.send_response(code)
            self.headers_common()
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', str(len(raw)))
            if cookie:
                self.send_header('Set-Cookie', f'deck_preview_{self.server.server_port}={cookie}; HttpOnly; SameSite=Strict; Path=/api/image/')
            self.end_headers()
            self.wfile.write(raw)

        def allowed(self):
            host = f'127.0.0.1:{self.server.server_port}'
            if self.headers.get('Host') != host:
                self.json({'error': 'Invalid local address'}, 403)
                return False
            origin = self.headers.get('Origin')
            if origin and origin != 'http://' + host:
                self.json({'error': 'Invalid origin'}, 403)
                return False
            return True

        def authenticated(self):
            return known(sessions, self.headers.get('X-Deck-Session', ''))

        def may_preview(self):
            cookie = SimpleCookie()
            try:
                cookie.load(self.headers.get('Cookie', ''))
                name = f'deck_preview_{self.server.server_port}'
                supplied = cookie[name].value if name in cookie else ''
            except Exception:
                supplied = ''
            return known(previews, supplied)

        def do_GET(self):
            if not self.allowed():
                return
            if self.path.startswith('/api/image/'):
                if not self.may_preview():
                    return self.json({'error': 'Invalid session'}, 401)
                try:
                    raw = editor.assets.preview(self.path.removeprefix('/api/image/'))
                except (ValueError, OSError):
                    return self.json({'error': 'The image does not exist'}, 404)
                self.send_response(200)
                self.headers_common(cache=True)
                self.send_header('Content-Type', 'image/png')
                self.send_header('Content-Length', str(len(raw)))
                self.end_headers()
                return self.wfile.write(raw)
            if self.path in ('/api/config', '/api/status', '/api/icons', '/api/action-packs', '/api/export', '/api/processes', '/api/programs'):
                if not self.authenticated():
                    return self.json({'error': 'Open the editor from Tessera.cmd'}, 401)
                try:
                    if self.path == '/api/export':
                        config = editor.read()['config']
                        shared, secrets_used = redact_secrets(config)
                        return self.json(dict(shared, assets=editor.assets.export(config), redacted=secrets_used,
                                              left_out=export_left_out(config)))
                    if self.path == '/api/processes':
                        import psutil
                        names = set()
                        for process in psutil.process_iter(['name']):
                            name = process.info.get('name')
                            if name:
                                names.add(name.lower())
                        return self.json({'names': sorted(names)})
                    if self.path == '/api/programs':
                        return self.json(editor.programs())
                    if self.path == '/api/action-packs':
                        return self.json(action_pack_catalog())
                    return self.json(editor.read_for_editor() if self.path == '/api/config' else dict(icon_catalog(), preferences=editor.icon_preferences()) if self.path == '/api/icons' else editor.status())
                except ValueError as exc:
                    return self.json({'error': str(exc) or 'Could not read the local configuration'}, 400)
                except (OSError, TypeError):
                    return self.json({'error': 'Could not read the local configuration'}, 400)
            files = {'/': 'index.html', '/core.js': 'core.js', '/app.js': 'app.js', '/dialogs.js': 'dialogs.js',
                     '/style.css': 'style.css',
                     '/streamdeck.css': 'streamdeck.css', '/cockpit.css': 'cockpit.css', '/logo-mark.svg': 'logo-mark.svg'}
            if self.path not in files:
                return self.json({'error': 'Not found'}, 404)
            file = WEB / files[self.path]
            raw = file.read_bytes()
            self.send_response(200)
            self.headers_common()
            self.send_header('Content-Type', {'.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css',
                                              '.svg': 'image/svg+xml'}[file.suffix] + '; charset=utf-8')
            self.send_header('Content-Length', str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

        def do_POST(self):
            if not self.allowed():
                return
            session = self.path == '/api/session'
            launch = self.headers.get('X-Deck-Launch')
            if session:
                if launch is not None:  # the page trades its one-time code for a session
                    keys = redeem(launch)
                    if not keys:
                        return self.json({'error': 'Invalid session'}, 403)
                elif not secrets.compare_digest(self.headers.get('X-Deck-Token', '').encode('utf-8', 'replace'), token.encode('utf-8')):
                    return self.json({'error': 'Invalid session'}, 403)
            elif not self.authenticated() or self.headers.get('X-Deck-Request') != '1':
                return self.json({'error': 'Invalid session'}, 403)
            try:
                length = int(self.headers.get('Content-Length', 0))
                if not 0 <= length <= (12 * 1024 * 1024 if self.path == '/api/image' else 1024 * 1024):
                    return self.json({'error': 'The configuration is too large'}, 413)
                if self.headers.get_content_type() != 'application/json':
                    return self.json({'error': 'Expected JSON'}, 415)
                data = json.loads(self.rfile.read(length), parse_constant=lambda _: (_ for _ in ()).throw(ValueError('Invalid number')))
                if not isinstance(data, dict):
                    raise ValueError('Invalid configuration')
                if session:
                    if launch is not None:
                        return self.json({'ok': True, 'session': keys[0]}, cookie=keys[1])
                    # the launcher asks for a code when it opens a window on this editor
                    return self.json(dict(ok=True, launch=launch_code()) if data.get('launch') is True else {'ok': True})
                if self.path == '/api/config':
                    return self.json(editor.save(data))
                if self.path == '/api/icon-preferences':
                    return self.json(editor.icon_preferences(data))
                if self.path == '/api/image':
                    return self.json(editor.assets.import_image(data['data']))
                if self.path.startswith('/api/command/'):
                    return self.json(editor.command(self.path.removeprefix('/api/command/'), data))
                return self.json({'error': 'Not found'}, 404)
            except Conflict as exc:
                self.json({'error': str(exc)}, 409)
            except (ValueError, KeyError, TypeError, AttributeError, RecursionError) as exc:
                self.json({'error': str(exc) if isinstance(exc, ValueError) else 'Invalid configuration'}, 400)
            except RuntimeError as exc:  # for example the host could not start; RecursionError is caught above
                self.json({'error': str(exc)}, 400)
            except (OSError, subprocess.SubprocessError) as exc:
                self.json({'error': f'The operation could not be completed: {exc}'}, 400)

    server = ExclusiveServer(('127.0.0.1', port), Handler)
    server.daemon_threads = True
    server.token = token
    server.launch_url = lambda: f'http://127.0.0.1:{server.server_port}/#{launch_code()}'
    server.editor = editor
    return server


def show_running_editor(record, build, open_if_hidden=False):
    """Bring the running editor to the front. False when there is none yet; an editor of another build is stopped.

    The editor's server answers a moment before its window is on screen. Opening a window of our own then (the
    old behaviour) is how a double click made two; the caller waits and asks again instead.
    """
    import psutil
    try:
        previous = json.loads(record.read_text())
        process = psutil.Process(previous['pid'])
        command = process.cmdline()
        address = urllib.parse.urlsplit(previous['url'])
        own_process = len(command) > 1 and Path(command[1]).resolve() == Path(__file__).resolve()
        local_address = address.scheme == 'http' and address.hostname == '127.0.0.1' and address.port and address.path == '/'
        if not (own_process and local_address and abs(process.create_time() - previous['created']) < .01):
            return False
        request = urllib.request.Request(previous['url'] + 'api/session', data=b'{}',
                                         headers={'Content-Type': 'application/json', 'X-Deck-Token': previous['token']})
        with urllib.request.urlopen(request, timeout=2) as response:
            if response.status != 200:
                return False
        if previous.get('build') == build:
            def launch_url():  # a one-time code: the record's token never goes into an address
                request = urllib.request.Request(previous['url'] + 'api/session', data=b'{"launch": true}',
                                                 headers={'Content-Type': 'application/json', 'X-Deck-Token': previous['token']})
                with urllib.request.urlopen(request, timeout=2) as response:
                    return previous['url'] + '#' + json.loads(response.read())['launch']
            if previous.get('browser'):  # the editor runs in a browser tab, which has no window of its own to raise
                webbrowser.open(launch_url())
                return True
            if activate_window(previous['pid']):
                return True
            if open_if_hidden:
                open_window(launch_url)
                return True
            return False
        # A launcher reopening an updated editor must not reuse a stale API server. The independent USB host stays up.
        process.terminate()
        process.wait(timeout=3)
    except (OSError, ValueError, KeyError, TypeError, psutil.Error):
        pass
    return False


def main():
    load('processes').name_process('Tessera')  # so that `killall Tessera` finds it
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--terminal', action='store_true')
    parser.add_argument('--editor', action='store_true', help='Open the graphical drag-and-drop editor')
    parser.add_argument('--check', action='store_true')
    parser.add_argument('--no-browser', action='store_true')
    parser.add_argument('--port', type=int, default=0)
    parser.add_argument('--profiles', type=Path)
    args = parser.parse_args()
    if args.terminal or args.check:
        return subprocess.call([sys.executable, str(ROOT / 'host/tessera_terminal.py')]
                               + (['--check'] if args.check else []), cwd=ROOT)
    controller = Controller()
    controller.install_adapters()
    record = ROOT / 'host/editor.local.json'
    build = editor_build_id()
    # One editor window: a second start (a double click on the tray icon, a click while the first is still
    # starting) waits for the first one and brings its window to the front instead of opening another.
    lock = InstanceLock(ROOT / 'host/editor.local.lock')
    if not args.profiles and not args.no_browser:
        deadline = time.monotonic() + 20
        while not lock.acquire():
            if show_running_editor(record, build) or time.monotonic() > deadline:
                return
            time.sleep(.3)
        if show_running_editor(record, build, open_if_hidden=True):  # an editor from before the lock existed
            lock.release()
            return
    if hasattr(signal, 'SIGTERM') and not IS_WINDOWS:  # "Quit" in the tray stops an editor in a browser tab: shut down normally
        def terminate(*_):
            raise KeyboardInterrupt
        signal.signal(signal.SIGTERM, terminate)
    server = make_server(Editor(args.profiles, controller), args.port)
    url = f'http://127.0.0.1:{server.server_port}/'
    if not args.profiles:
        import psutil
        from control_api import write_private
        details = {'pid': os.getpid(), 'created': psutil.Process().create_time(), 'url': url, 'token': server.token, 'build': build}

        def write_record():
            temporary = record.with_suffix('.tmp')
            write_private(temporary, json.dumps(details))  # the token opens the editor's API: other accounts must not read it
            os.replace(temporary, record)
        write_record()
    print('The Tessera editor is open. Keep this window open.', flush=True)
    if args.no_browser:  # no window opens: this address (with a one-time code) is the way in, for you or a test
        print(f'Open {server.launch_url()}', flush=True)
    server_thread = None
    try:
        if not args.no_browser:
            server_thread = threading.Thread(target=server.serve_forever, daemon=True)
            server_thread.start()
            if open_window(server.launch_url):
                server.shutdown()
                server_thread.join(timeout=3)
                return
            if not args.profiles:  # no window of our own: the next start opens another browser tab at once
                details['browser'] = True
                write_record()
            while server_thread.is_alive():
                server_thread.join(timeout=.5)
        else:
            server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
        lock.release()
        if not args.profiles:
            try:
                if json.loads(record.read_text()).get('pid') == os.getpid():
                    record.unlink(missing_ok=True)
            except (OSError, ValueError):
                pass


if __name__ == '__main__':
    raise SystemExit(main())
