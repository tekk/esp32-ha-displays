"""Local control API: lets scripts, hooks and AI tools drive the panel.

Listens on 127.0.0.1 only. Every request needs the per-run token that is written to
deck-api.local.json (readable by the same Windows user only), and browser requests
(anything with an Origin header) are rejected so a web page cannot reach it. Each token is rate-limited, and every
call that changes something is logged with the caller's grant name.
"""

import atexit
import hashlib
import hmac
import json
import os
import re
import secrets
import socket
import threading
import time
from platform_support import load
from action_runner import Busy
import permission
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

MAX_BODY = 64 * 1024
VARIABLE_NAME = re.compile(r'[A-Za-z0-9_.-]{1,64}')
MAX_VALUE = 200
# Per token: a runaway script or plugin is slowed down instead of flooding the panel's work queue.
RATE_PER_SECOND = 20
RATE_BURST = 40
# A client that sends its headers or body slowly may hold a thread only this long (seconds).
REQUEST_TIMEOUT = 10
# The whole request (headers and body) must arrive within this many seconds, however slowly the bytes trickle in.
REQUEST_DEADLINE = 15
MAX_CONNECTIONS = 64
# Calls without a valid token are logged at most this often, so a flood of them cannot push the audit trail out.
UNKNOWN_LOG_SECONDS = 10
MAX_NONCE = 128
# A message on the panel: two lines of the banner hold about this many characters; it shows for 1 to 30 seconds.
NOTIFY_LEVELS = ('info', 'ok', 'warn', 'error')
NOTIFY_MAX_TEXT = 100
NOTIFY_SECONDS = (1, 30)
NOTIFY_DEFAULT_SECONDS = 6


def proof(token: str, nonce: str) -> str:
    """What the host answers to a client's nonce: shows that the reply comes from the holder of the token.

    A process that took over the port of a crashed host can answer a request, but it cannot make this proof, so the
    permission hook never takes its "allow" for the panel's.
    """
    return hmac.new(token.encode('utf-8'), nonce.encode('utf-8'), hashlib.sha256).hexdigest()


class ApiError(ValueError):
    """A request the API rejects with HTTP 400."""


class Forbidden(ApiError):
    """A request the caller's token does not allow (HTTP 403)."""


@dataclass(frozen=True)
class Grant:
    """What one token may do: routes (None = everything), a variable-name prefix, and the two read routes."""
    name: str
    routes: frozenset | None = None
    prefix: str | None = None
    events: bool = True
    read: bool = True


def make_private(path) -> None:
    """Let only the owner read the token file: other accounts on a shared PC must not be able to drive the panel."""
    load('files').make_private(path)


def _button(data) -> int:
    value = data.get('button')
    if type(value) is not int or not 1 <= value <= 18:
        raise ApiError('button must be a whole number from 1 to 18')
    return value


class ExclusiveServer(ThreadingHTTPServer):
    # http.server turns SO_REUSEADDR on, and on Windows that lets a second socket bind a port that is in use.
    # Port 0 never needs it; exclusive use keeps another process from taking the port over while the host runs.
    allow_reuse_address = False
    connections = threading.BoundedSemaphore(MAX_CONNECTIONS)

    def process_request(self, request, client_address):
        if not self.connections.acquire(blocking=False):  # every thread is busy: refuse instead of piling up threads
            self.shutdown_request(request)
            return
        super().process_request(request, client_address)

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self.connections.release()

    def server_bind(self):
        if hasattr(socket, 'SO_EXCLUSIVEADDRUSE'):
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        super().server_bind()


def write_private(path, text: str) -> None:
    """Write `text` to a file only this account can read. The file is private before the text is in it."""
    path = Path(path)
    path.write_text('', encoding='utf-8')
    make_private(path)
    path.write_text(text, encoding='utf-8')


class ControlServer:
    def __init__(self, daemon, info_path):
        self.daemon = daemon
        self.info_path = Path(info_path)
        self.token = secrets.token_urlsafe(32)
        self.grants = {self.token: Grant('owner')}
        self.grant_lock = threading.Lock()
        self.server: ThreadingHTTPServer | None = None
        self.buckets: dict[str, tuple[float, float]] = {}  # token -> (calls left, when counted)
        self.clock = time.monotonic
        self.unknown_logged, self.unknown_skipped = float('-inf'), 0
        self.routes = {'var': self.set_variable, 'vars': self.set_variables, 'press': self.press, 'page': self.show_page,
                       'state': self.set_state, 'feedback': self.feedback, 'display': self.display,
                       'permission': self.ask_permission, 'notify': self.notify}

    # --- scoped tokens for plugins -----------------------------------------------------
    def add_grant(self, name, routes, prefix=None, events=False, read=False) -> str:
        token = secrets.token_urlsafe(32)
        with self.grant_lock:
            self.grants[token] = Grant(name, frozenset(routes), prefix, events, read)
        return token

    def remove_grant(self, token) -> None:
        with self.grant_lock:
            if token != self.token:
                self.grants.pop(token, None)
                self.buckets.pop(token, None)

    def grant_for(self, supplied):
        with self.grant_lock:
            found = None
            supplied = supplied.encode('utf-8', 'replace')  # compare_digest raises on non-ASCII str: answer 401 instead
            for token, grant in self.grants.items():
                if secrets.compare_digest(supplied, token.encode()):
                    found = grant
            return found

    def allow(self, token) -> bool:
        """Token bucket: RATE_BURST calls at once, then RATE_PER_SECOND."""
        now = self.clock()
        with self.grant_lock:
            left, then = self.buckets.get(token, (RATE_BURST, now))
            left = min(RATE_BURST, left + (now - then) * RATE_PER_SECOND)
            allowed = left >= 1
            self.buckets[token] = (left - 1 if allowed else left, now)
            return allowed

    def audit(self, who, method, path, code) -> None:
        # Who changed what, never the body: values and texts can hold private data. Successful variable
        # updates are skipped: the AI adapters send them every few seconds and would bury everything else.
        log = getattr(self.daemon, 'log', None)
        if not callable(log) or (path == '/v1/vars' and code < 400):
            return
        suffix = ''
        if who == 'unknown':
            now = self.clock()
            with self.grant_lock:
                if now - self.unknown_logged < UNKNOWN_LOG_SECONDS:
                    self.unknown_skipped += 1
                    return
                self.unknown_logged = now
                if self.unknown_skipped:
                    suffix, self.unknown_skipped = f' (and {self.unknown_skipped} more like it)', 0
        log(f'API {who} {method} {path} -> {code}{suffix}')

    @staticmethod
    def check_scope(grant, route, data):
        if grant.routes is not None and route not in grant.routes:
            raise Forbidden(f'This token may not use {route}')
        if grant.prefix and route in ('var', 'vars'):
            names = [data.get('name')] if route == 'var' else list(data.get('set') or {}) if isinstance(data.get('set'), dict) else []
            if any(not isinstance(name, str) or not name.startswith(grant.prefix) for name in names):
                raise Forbidden(f'Variables of this plugin must start with {grant.prefix}')

    def events(self, query, grant):
        try:
            since = int(query.get('since', ['0'])[0])
            wait = float(query.get('wait', ['0'])[0])
        except ValueError as exc:
            raise ApiError('since must be a whole number and wait a number of seconds') from exc
        plugin = None if grant.name == 'owner' else grant.name
        events, last = self.daemon.events.since(since, plugin, wait, with_last=True)
        return {'events': events, 'last': last}

    # --- request handlers: validate, then queue work for the daemon's worker thread ---
    def set_variable(self, data):
        name, value = data.get('name'), data.get('value', '')
        if not isinstance(name, str) or not VARIABLE_NAME.fullmatch(name):
            raise ApiError('name must be 1-64 letters, digits, dots, dashes or underscores')
        if not isinstance(value, (str, int, float)) or isinstance(value, bool) or len(str(value)) > MAX_VALUE:
            raise ApiError(f'value must be text or a number of at most {MAX_VALUE} characters')
        self.daemon.submit(('var', name, str(value)))

    def set_variables(self, data):
        # Several variables in one request, queued all-or-nothing (used by the AI tool adapters).
        values = data.get('set')
        if not isinstance(values, dict) or not 1 <= len(values) <= 20:
            raise ApiError('set must be an object with 1 to 20 variables')
        jobs = []
        for name, value in values.items():
            if not isinstance(name, str) or not VARIABLE_NAME.fullmatch(name):
                raise ApiError('name must be 1-64 letters, digits, dots, dashes or underscores')
            if not isinstance(value, (str, int, float)) or isinstance(value, bool) or len(str(value)) > MAX_VALUE:
                raise ApiError(f'value must be text or a number of at most {MAX_VALUE} characters')
            jobs.append(('var', name, str(value)))
        self.daemon.submit(*jobs)

    def press(self, data):
        self.daemon.submit(('api-press', _button(data)))

    def show_page(self, data):
        config = self.daemon.config['profiles']
        profile = data.get('profile', self.daemon.profile)
        if profile not in config:
            raise ApiError(f'Unknown profile: {profile}. Profiles: {", ".join(config)}')
        page = data.get('page', next(iter(config[profile]['pages'])))
        if page not in config[profile]['pages']:
            raise ApiError(f'Unknown page: {page}. Pages of {profile}: {", ".join(config[profile]["pages"])}')
        self.daemon.submit(('wake',), ('profile', profile), ('page', page))

    def set_state(self, data):
        value = data.get('state', 'next')
        if value != 'next' and (type(value) is not int or not 0 <= value <= 7):
            raise ApiError("state must be 'next' or a whole number from 0 to 7")
        self.daemon.submit(('state', _button(data), value))

    def feedback(self, data):
        if type(data.get('ok', True)) is not bool:
            raise ApiError('ok must be true or false')
        self.daemon.submit(('feedback', _button(data), data.get('ok', True)))

    def display(self, data):
        action = data.get('action')
        if action not in ('wake', 'dim'):
            raise ApiError("action must be 'wake' or 'dim'")
        self.daemon.submit((action,))

    def notify(self, data):
        # One line of text: a newline would end the panel's command early, and lone surrogates cannot be sent as UTF-8.
        text, level = data.get('text'), data.get('level', 'info')
        seconds = data.get('seconds', NOTIFY_DEFAULT_SECONDS)
        if not isinstance(text, str) or not text.strip() or len(text) > NOTIFY_MAX_TEXT or not text.isprintable():
            raise ApiError(f'text must be 1 to {NOTIFY_MAX_TEXT} printable characters on one line')
        if level not in NOTIFY_LEVELS:
            raise ApiError(f'level must be one of {", ".join(NOTIFY_LEVELS)}')
        if type(seconds) is not int or not NOTIFY_SECONDS[0] <= seconds <= NOTIFY_SECONDS[1]:
            raise ApiError(f'seconds must be a whole number from {NOTIFY_SECONDS[0]} to {NOTIFY_SECONDS[1]}')
        self.daemon.submit(('notify', text.strip(), level, seconds))

    def ask_permission(self, data):
        # Unlike the other routes this one waits: the answer is a touch on the panel (or nobody answers).
        agent, text = data.get('agent'), data.get('text')
        if (agent not in permission.AGENT_IDS or not isinstance(text, str) or not 1 <= len(text) <= permission.MAX_TEXT
                or not permission.printable(text)):
            raise ApiError('permission needs a known agent and a short, printable text')
        return {'ok': True, 'decision': self.daemon.ask_permission(agent, text)}

    def snapshot(self):
        daemon = self.daemon
        return {'profile': daemon.profile, 'page': daemon.page, 'connected': daemon.panel is not None
                and not daemon.connection_failed.is_set(), 'dimmed': daemon.dimmed, 'locked': daemon.locked,
                'variables': dict(daemon.custom_vars), 'agents': dict(daemon.agents),
                'profile_locked': daemon.profile_locked is True,
                'profiles': {name: list(profile.get('pages', {})) for name, profile in daemon.config.get('profiles', {}).items()},
                'queue': {'pending': daemon.jobs.qsize(), 'capacity': daemon.jobs.maxsize,
                          'dropped': daemon.dropped_jobs, 'slow_running': len(daemon.slow_running)}}

    # --- HTTP plumbing ---------------------------------------------------------------
    def make_handler(self):
        api = self

        class Handler(BaseHTTPRequestHandler):
            timeout = REQUEST_TIMEOUT  # a stalled client must not pin a thread forever

            def log_message(self, *_):
                pass

            def setup(self):
                super().setup()
                self.expiry = threading.Timer(REQUEST_DEADLINE, self.expire)
                self.expiry.daemon = True
                self.expiry.start()

            def expire(self):  # the timeout above counts each read: a client that trickles bytes in is cut off here
                try:
                    self.connection.shutdown(socket.SHUT_RDWR)
                except OSError:
                    pass

            def finish(self):
                self.expiry.cancel()
                super().finish()

            def reply(self, code, payload):
                if self.command != 'GET':
                    api.audit(getattr(self, 'caller', 'unknown'), self.command, urlparse(self.path).path[:64], code)
                raw = json.dumps(payload).encode('utf-8')
                self.send_response(code)
                self.send_header('Content-Type', 'application/json; charset=utf-8')
                self.send_header('Content-Length', str(len(raw)))
                self.send_header('Cache-Control', 'no-store')
                nonce = self.headers.get('X-Deck-Nonce', '')
                if getattr(self, 'token', None) and 0 < len(nonce) <= MAX_NONCE:
                    self.send_header('X-Deck-Proof', proof(self.token, nonce))
                self.end_headers()
                self.wfile.write(raw)

            def authorized(self):
                host = f'127.0.0.1:{self.server.server_port}'
                if self.headers.get('Host') != host or self.headers.get('Origin'):
                    self.reply(403, {'error': 'Forbidden'})
                    return None
                token = self.headers.get('X-Deck-Token', '')
                grant = api.grant_for(token)
                if grant is None:
                    self.reply(401, {'error': 'Invalid token'})
                    return None
                self.caller, self.token = grant.name, token
                if not api.allow(token):
                    self.reply(429, {'error': 'Too many requests', 'retry': True})
                    return None
                return grant

            def do_GET(self):
                self.expiry.cancel()  # the request has arrived: a long wait for events is the server's doing
                grant = self.authorized()
                if grant is None:
                    return
                url = urlparse(self.path)
                if url.path == '/v1/state':
                    return self.reply(200, api.snapshot()) if grant.read else self.reply(403, {'error': 'This token may not read the state'})
                if url.path == '/v1/events':
                    if not grant.events:
                        return self.reply(403, {'error': 'This token may not read events'})
                    try:
                        return self.reply(200, api.events(parse_qs(url.query), grant))
                    except ApiError as exc:
                        return self.reply(400, {'error': str(exc)})
                self.reply(404, {'error': 'Not found'})

            def do_POST(self):
                grant = self.authorized()
                if grant is None:
                    return
                route = self.path.removeprefix('/v1/') if self.path.startswith('/v1/') else None
                handler = api.routes.get(route)
                if handler is None:
                    return self.reply(404, {'error': 'Not found'})
                try:
                    length = int(self.headers.get('Content-Length', 0))
                    if not 0 <= length <= MAX_BODY:
                        return self.reply(413, {'error': 'Request too large'})
                    body = self.rfile.read(length)
                    self.expiry.cancel()
                    data = json.loads(body or b'{}')
                    if not isinstance(data, dict):
                        raise ApiError('The body must be a JSON object')
                    api.check_scope(grant, route, data)
                    result = handler(data)
                except Busy as exc:
                    return self.reply(503, {'error': str(exc), 'retry': True})
                except Forbidden as exc:
                    return self.reply(403, {'error': str(exc)})
                except (ValueError, TypeError) as exc:
                    return self.reply(400, {'error': str(exc)})
                self.reply(200, result if isinstance(result, dict) else {'ok': True, 'queued': True})

        return Handler

    def start(self):
        self.server = ExclusiveServer(('127.0.0.1', 0), self.make_handler())
        self.server.daemon_threads = True
        self.server.handle_error = lambda request, client_address: None  # a client that hangs up is not an error
        threading.Thread(target=self.server.serve_forever, daemon=True).start()
        info = {'pid': os.getpid(), 'port': self.server.server_port, 'token': self.token}
        temporary = self.info_path.with_suffix('.tmp')
        write_private(temporary, json.dumps(info))
        os.replace(temporary, self.info_path)
        atexit.register(self.remove_own_info)  # a normal exit without stop() leaves no stale file

    def remove_own_info(self):
        try:
            if json.loads(self.info_path.read_text(encoding='utf-8')).get('pid') == os.getpid():
                self.info_path.unlink()
        except (OSError, ValueError, AttributeError):
            pass

    def stop(self):
        if self.server is not None:
            self.server.shutdown()
            self.server.server_close()
            self.server = None
        self.info_path.unlink(missing_ok=True)
