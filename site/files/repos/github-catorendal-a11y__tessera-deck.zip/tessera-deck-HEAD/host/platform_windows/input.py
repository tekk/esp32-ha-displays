"""Windows input and focus: synthetic keys and mouse, the foreground window and bringing a program to the front."""
import ctypes
import os
import time

import psutil

from input_common import (CHILD_NAMES_SECONDS, IS_WINDOWS, MOUSE_OPERATIONS, WINDOW_OPERATIONS, child_names,  # noqa: F401
                          dry_hotkey, matches_foreground, split_hotkey)

VK = {'ctrl': 0x11, 'control': 0x11, 'shift': 0x10, 'alt': 0x12,
      'win': 0x5b, 'meta': 0x5b, 'enter': 13, 'return': 13, 'tab': 9,
      'esc': 27, 'escape': 27, 'space': 32, 'backspace': 8, 'delete': 46,
      'home': 36, 'end': 35, 'pageup': 33, 'pagedown': 34,
      'left': 37, 'up': 38, 'right': 39, 'down': 40,
      'comma': 0xbc, 'period': 0xbe, 'slash': 0xbf, 'grave': 0xc0,
      'lbracket': 0xdb, 'rbracket': 0xdd, 'minus': 0xbd, 'equals': 0xbb,
      'semicolon': 0xba, 'quote': 0xde, 'backslash': 0xdc,
      'insert': 45, 'printscreen': 44, 'apps': 0x5d, 'capslock': 20,
      'volumemute': 0xad, 'volumedown': 0xae, 'volumeup': 0xaf,
      'playpause': 0xb3, 'medianext': 0xb0, 'mediaprev': 0xb1, 'mediastop': 0xb2}
VK.update({c: ord(c.upper()) for c in 'abcdefghijklmnopqrstuvwxyz0123456789'})
VK.update({f'numpad{i}': 0x60 + i for i in range(10)})
VK.update({f'f{i}': 0x6f + i for i in range(1, 25)})
# Navigation keys must carry KEYEVENTF_EXTENDEDKEY or some apps read them as numpad keys.
EXTENDED_VK = frozenset({33, 34, 35, 36, 37, 38, 39, 40, 44, 45, 46, 0x5b, 0x5d})
KEYEVENTF_EXTENDEDKEY, KEYEVENTF_KEYUP = 1, 2



def parse_hotkey(combo):
    return [VK[name] for name in split_hotkey(combo)]


if IS_WINDOWS:
    from ctypes import wintypes
    user32 = ctypes.WinDLL('user32', use_last_error=True)
    kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)

    class KEYBDINPUT(ctypes.Structure):
        _fields_ = [('wVk', wintypes.WORD), ('wScan', wintypes.WORD),
                    ('dwFlags', wintypes.DWORD), ('time', wintypes.DWORD),
                    ('dwExtraInfo', ctypes.c_size_t)]

    class MOUSEINPUT(ctypes.Structure):
        _fields_ = [('dx', wintypes.LONG), ('dy', wintypes.LONG),
                    ('mouseData', wintypes.DWORD), ('dwFlags', wintypes.DWORD),
                    ('time', wintypes.DWORD), ('dwExtraInfo', ctypes.c_size_t)]

    class INPUTUNION(ctypes.Union):
        _fields_ = [('ki', KEYBDINPUT), ('mi', MOUSEINPUT)]

    class INPUT(ctypes.Structure):
        _anonymous_ = ('u',)
        _fields_ = [('type', wintypes.DWORD), ('u', INPUTUNION)]

    user32.SendInput.argtypes = [wintypes.UINT, ctypes.POINTER(INPUT), ctypes.c_int]
    user32.SendInput.restype = wintypes.UINT
    user32.GetForegroundWindow.restype = wintypes.HWND
    user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
    user32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
    user32.GetWindowTextLengthW.restype = ctypes.c_int
    user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
    user32.GetWindowTextW.restype = ctypes.c_int
    kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
    kernel32.OpenProcess.restype = wintypes.HANDLE
    kernel32.QueryFullProcessImageNameW.argtypes = [wintypes.HANDLE, wintypes.DWORD,
                                                  wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]
    kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
    # 64-bit handles: without these ctypes would cut them to a 32-bit int
    user32.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
    user32.PostMessageW.argtypes = [wintypes.HWND, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
    user32.GetWindowLongW.argtypes = [wintypes.HWND, ctypes.c_int]
    user32.SetWindowPos.argtypes = [wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int,
                                    ctypes.c_int, ctypes.c_int, wintypes.UINT]
    user32.OpenClipboard.argtypes = [wintypes.HWND]
    user32.SetClipboardData.argtypes = [wintypes.UINT, wintypes.HANDLE]
    user32.SetClipboardData.restype = wintypes.HANDLE
    kernel32.GlobalAlloc.argtypes = [wintypes.UINT, ctypes.c_size_t]
    kernel32.GlobalAlloc.restype = wintypes.HGLOBAL
    kernel32.GlobalLock.argtypes = [wintypes.HGLOBAL]
    kernel32.GlobalLock.restype = ctypes.c_void_p
    kernel32.GlobalUnlock.argtypes = [wintypes.HGLOBAL]
    kernel32.GlobalFree.argtypes = [wintypes.HGLOBAL]


def _key(vk=0, scan=0, flags=0):
    if not IS_WINDOWS:
        raise OSError('Hotkeys and typing need Windows')
    value = INPUT(type=1)
    value.ki = KEYBDINPUT(vk, scan, flags, 0, 0)
    if user32.SendInput(1, ctypes.byref(value), ctypes.sizeof(value)) != 1:
        raise OSError('Windows refused the key press (check the permissions of Tessera)')


MOUSE_FLAGS = {'left': (0x2, 0x4), 'right': (0x8, 0x10), 'middle': (0x20, 0x40)}


def _mouse(flags, dx=0, dy=0, data=0):
    if not IS_WINDOWS:
        raise OSError('Mouse actions need Windows')
    value = INPUT(type=0)
    value.mi = MOUSEINPUT(dx, dy, data & 0xFFFFFFFF, flags, 0, 0)
    if user32.SendInput(1, ctypes.byref(value), ctypes.sizeof(value)) != 1:
        raise OSError('Windows refused the mouse input (check the permissions of Tessera)')


def send_mouse(op, x=0, y=0, amount=0, press=None):
    # click: left, right, middle, double; scroll: `amount` notches (positive up); move: relative pixels;
    # moveto: absolute screen position in pixels.
    press = press or _mouse
    if op in MOUSE_FLAGS or op == 'double':
        down, up = MOUSE_FLAGS['left' if op == 'double' else op]
        for _ in range(2 if op == 'double' else 1):
            press(down)
            press(up)
    elif op == 'scroll':
        press(0x800, data=amount * 120)
    elif op == 'move':
        press(0x1, x, y)
    elif op == 'moveto':
        # with the virtual-desk flag 0..65535 spans every monitor, so scale with the virtual screen, not the primary one
        left, top, width, height = (user32.GetSystemMetrics(index) for index in (76, 77, 78, 79))
        press(0x8001 | 0x4000, round((x - left) * 65535 / max(1, width - 1)), round((y - top) * 65535 / max(1, height - 1)))
    else:
        raise ValueError(f'Unknown mouse operation: {op}')


def _extended_flag(vk):
    return KEYEVENTF_EXTENDEDKEY if vk in EXTENDED_VK else 0


def send_hotkey(combo):
    pressed = []
    try:
        for vk in parse_hotkey(combo):
            _key(vk=vk, flags=_extended_flag(vk))
            pressed.append(vk)
    finally:
        for vk in reversed(pressed):
            _key(vk=vk, flags=KEYEVENTF_KEYUP | _extended_flag(vk))


TEXT_KEYS = {'\n': 0x0D, '\t': 0x09}  # a unicode U+000A is no Enter for browsers and chat boxes: press the real key


def send_text(text, pause=0.0, wait=time.sleep):
    # `pause` seconds between characters makes the typing look and behave like a person typing.
    # `wait` returning true (a set stop event's wait) ends the typing early.
    chars = text.replace('\r\n', '\n').replace('\r', '\n')
    for n, char in enumerate(chars):
        if char in TEXT_KEYS:
            _key(vk=TEXT_KEYS[char])
            _key(vk=TEXT_KEYS[char], flags=KEYEVENTF_KEYUP)
        else:
            raw = char.encode('utf-16-le')
            for i in range(0, len(raw), 2):
                code = int.from_bytes(raw[i:i+2], 'little')
                _key(scan=code, flags=4)
                _key(scan=code, flags=6)
        if pause and n + 1 < len(chars) and wait(pause):
            break


FRAME_HOST = 'applicationframehost.exe'
# Windows surfaces that take focus for a moment (search, Start, notifications, Alt+Tab, the lock screen): they say
# nothing about which program you are working in, so they never end or start an automatic profile switch.
NEUTRAL_EXES = frozenset({'searchhost.exe', 'searchapp.exe', 'startmenuexperiencehost.exe', 'shellexperiencehost.exe',
                          'textinputhost.exe', 'lockapp.exe', 'shellhost.exe'})
NEUTRAL_EXPLORER_TITLES = frozenset({'', 'task switching', 'task view'})
TESSERA_WINDOW_EXES = frozenset({'python.exe', 'pythonw.exe', 'msedgewebview2.exe'})


def is_neutral_window(context):
    exe, title = context.get('exe', ''), context.get('title', '')
    if exe in NEUTRAL_EXES:
        return True
    if exe == 'explorer.exe':
        return title in NEUTRAL_EXPLORER_TITLES
    return exe in TESSERA_WINDOW_EXES and title.startswith('tessera')


def real_app_exe(exe, child_exes):
    """Store (UWP) apps are drawn inside ApplicationFrameHost; the program behind the frame is the app that matters."""
    if exe != FRAME_HOST:
        return exe
    return next((name for name in child_exes if name and name != FRAME_HOST), exe)


def child_process_names(hwnd):
    names = []
    callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    @callback_type
    def visit(child, _):
        owner = wintypes.DWORD()
        user32.GetWindowThreadProcessId(child, ctypes.byref(owner))
        try:
            names.append(psutil.Process(owner.value).name().lower())
        except (psutil.Error, OSError):
            pass
        return True

    user32.EnumChildWindows(hwnd, visit, 0)
    return names


def foreground_context():
    if not IS_WINDOWS:
        return {'exe': '', 'title': '', 'processes': []}
    hwnd = user32.GetForegroundWindow()
    return window_context(hwnd) if hwnd else {'exe': '', 'title': '', 'processes': []}


def window_context(hwnd):
    pid = wintypes.DWORD()
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    length = min(max(user32.GetWindowTextLengthW(hwnd), 0), 4096)
    title_buffer = ctypes.create_unicode_buffer(length + 1)
    user32.GetWindowTextW(hwnd, title_buffer, len(title_buffer))
    title = title_buffer.value.lower()
    handle = kernel32.OpenProcess(0x1000, False, pid.value)
    if not handle:
        return {'exe': '', 'title': title, 'processes': []}
    exe = ''
    try:
        buf = ctypes.create_unicode_buffer(32768)
        size = wintypes.DWORD(len(buf))
        if kernel32.QueryFullProcessImageNameW(handle, 0, buf, ctypes.byref(size)):
            exe = os.path.basename(buf.value).lower()
    finally:
        kernel32.CloseHandle(handle)
    if exe == FRAME_HOST:
        exe = real_app_exe(exe, child_process_names(hwnd))
    processes = [exe] if exe else []
    processes += [name for name in child_names(pid.value) if name not in processes]
    return {'exe': exe, 'title': title, 'processes': processes}




def bring_to_front(user32, hwnd):
    """Show a window in front. Only a minimized window is restored: SW_RESTORE on a maximized one would shrink it."""
    if user32.IsIconic(hwnd):
        user32.ShowWindow(hwnd, 9)
    user32.SetForegroundWindow(hwnd)
    if user32.GetForegroundWindow() == hwnd:
        return
    # Windows refuses a background program the foreground and flashes the taskbar button instead. A key press on
    # the panel is the user's own request, so borrow the right from the thread that owns the window in front.
    front = user32.GetWindowThreadProcessId(user32.GetForegroundWindow(), None)
    mine = kernel32.GetCurrentThreadId() if IS_WINDOWS else 0
    attached = bool(front) and front != mine and bool(user32.AttachThreadInput(mine, front, True))
    try:
        user32.BringWindowToTop(hwnd)
        user32.SetForegroundWindow(hwnd)
    finally:
        if attached:
            user32.AttachThreadInput(mine, front, False)
    if user32.GetForegroundWindow() != hwnd:  # last resort: a tap on Alt counts as the user's input
        user32.keybd_event(0x12, 0, 0, 0)
        user32.SetForegroundWindow(hwnd)
        user32.keybd_event(0x12, 0, 2, 0)


def focus_existing_process(process_name):
    """Restore the first visible window owned by process_name."""
    hwnd = process_window(process_name)
    if not hwnd:
        return False
    bring_to_front(user32, hwnd)
    return True


def process_window(process_name):
    """The first visible, titled window owned by process_name, or None."""
    if not IS_WINDOWS or not process_name:
        return None
    wanted = process_name.lower()
    pids = set()
    try:
        for process in psutil.process_iter(['pid', 'name']):
            if (process.info.get('name') or '').lower() == wanted:
                pids.add(process.info['pid'])
    except (psutil.Error, OSError):
        return None
    if not pids:
        return None
    found = []
    callback_type = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    @callback_type
    def visit(hwnd, _):
        owner = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(owner))
        if owner.value in pids and user32.IsWindowVisible(hwnd) and user32.GetWindowTextLengthW(hwnd):
            found.append(hwnd)
            return False
        return True

    user32.EnumWindows(visit, 0)
    return found[0] if found else None




SHOW_COMMANDS = {'minimize': 6, 'maximize': 3, 'restore': 9}  # SW_MINIMIZE, SW_MAXIMIZE, SW_RESTORE
WM_CLOSE, GWL_EXSTYLE, WS_EX_TOPMOST = 0x10, -20, 0x8
SWP_KEEP = 0x1 | 0x2 | 0x10  # SWP_NOSIZE | SWP_NOMOVE | SWP_NOACTIVATE: only the z-order changes


def window_action(op, process=''):
    """Do `op` to the first window of `process`, or to the window in front. Returns False when there is none."""
    if op not in WINDOW_OPERATIONS:
        raise ValueError(f'Unknown window operation: {op}')
    if not IS_WINDOWS:
        return False
    hwnd = process_window(process) if process else user32.GetForegroundWindow()
    if not hwnd:
        return False
    if op in SHOW_COMMANDS:
        user32.ShowWindow(hwnd, SHOW_COMMANDS[op])
    elif op == 'close':
        user32.PostMessageW(hwnd, WM_CLOSE, 0, 0)  # like its own close button: the program may still ask to save
    elif op == 'topmost':
        on_top = user32.GetWindowLongW(hwnd, GWL_EXSTYLE) & WS_EX_TOPMOST
        user32.SetWindowPos(hwnd, -2 if on_top else -1, 0, 0, 0, 0, SWP_KEEP)  # HWND_NOTOPMOST / HWND_TOPMOST
    else:
        bring_to_front(user32, hwnd)
        if op == 'next_monitor':
            send_hotkey('win+shift+right')  # Windows' own move keeps the window's size and snap state right
    return True


CF_UNICODETEXT, GMEM_MOVEABLE = 13, 0x2


def set_clipboard(text, tries=10, wait=time.sleep):
    """Put `text` on the Windows clipboard; another program can hold it open for a moment, so try a few times."""
    if not IS_WINDOWS:
        raise OSError('The clipboard action needs Windows')
    data = (text.replace('\r\n', '\n').replace('\n', '\r\n') + '\0').encode('utf-16-le')
    for _ in range(tries):
        if user32.OpenClipboard(None):
            break
        wait(0.02)
    else:
        raise OSError('The clipboard is busy in another program')
    try:
        user32.EmptyClipboard()
        handle = kernel32.GlobalAlloc(GMEM_MOVEABLE, len(data))
        pointer = kernel32.GlobalLock(handle) if handle else None
        if not pointer:
            raise OSError('No memory for the clipboard text')
        ctypes.memmove(pointer, data, len(data))
        kernel32.GlobalUnlock(handle)
        if not user32.SetClipboardData(CF_UNICODETEXT, handle):  # on success the clipboard owns the memory
            kernel32.GlobalFree(handle)
            raise OSError('Windows did not take the clipboard text')
    finally:
        user32.CloseClipboard()
