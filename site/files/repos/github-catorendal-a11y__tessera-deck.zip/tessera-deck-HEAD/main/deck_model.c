#include "deck_model.h"

#include <string.h>

#include "cJSON.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"

static const char *TAG = "deck_model";

static SemaphoreHandle_t s_lock;
static deck_button_t s_buttons[DECK_MAX_BUTTONS];
static int s_button_count;
static uint32_t s_buttons_version = 1;
static uint32_t s_live_version = 1;
static deck_context_t s_context = {"LOCAL", "MAIN", false};
static uint32_t s_context_version = 1;

static deck_event_t s_events[DECK_EVENT_RING];
static int s_event_next; /* next write slot */
static int s_event_last_id;

/* Pending key feedback: a small FIFO so two confirmations inside one UI
 * tick (a key that presses another key) both flash. */
#define DECK_FEEDBACK_QUEUE 8
static struct {
    int button_id;
    deck_feedback_t kind;
    uint32_t seq;
} s_feedback[DECK_FEEDBACK_QUEUE];
static int s_feedback_head, s_feedback_count;
static uint32_t s_feedback_seq;

static bool s_dimmed;
static uint32_t s_wake_seq;
static int64_t s_host_seen_ms = -1;

/* Copy at most dst_size-1 bytes and always NUL-terminate; returns false
 * when the source was truncated so callers can log it. */
static bool copy_text(char *dst, size_t dst_size, const char *src)
{
    if (!src) return false;
    size_t len = strlen(src);
    bool full = len < dst_size;
    if (!full) {
        len = dst_size - 1;
        while (len > 0 && ((unsigned char)src[len] & 0xC0) == 0x80) --len;
    }
    memcpy(dst, src, len);
    dst[len] = '\0';
    /* LVGL does not render control characters; flatten them. */
    for (size_t i = 0; i < len; ++i) {
        unsigned char c = (unsigned char)dst[i];
        if (c < 0x20) dst[i] = ' ';
    }
    return full;
}

static void model_lock(void)
{
    if (s_lock) xSemaphoreTake(s_lock, portMAX_DELAY);
}

static void model_unlock(void)
{
    if (s_lock) xSemaphoreGive(s_lock);
}

static void deck_model_defaults(void);
void deck_model_init(void)
{
    if (!s_lock) s_lock = xSemaphoreCreateMutex();
    model_lock();
    model_unlock();
    deck_model_defaults();
    ESP_LOGI(TAG, "model ready (%d buttons)", s_button_count);
}

static void deck_model_defaults(void)
{
    /* A practical starter deck for a dev panel; the host script can
     * replace the whole set at runtime over POST /api/deck/config.
     * Colors use accent green, muted gray and error red. */
    static const deck_button_t defaults[] = {
        {1, "Build", "bolt", 0x35D07F},
        {2, "Run", "play", 0x35D07F},
        {3, "Test", "ok", 0x35D07F},
        {4, "Deploy", "upload", 0x35D07F},
        {5, "Git", "edit", 0x35D07F},
        {6, "Sync", "loop", 0x35D07F},
        {7, "Pause", "pause", 0xA3B2BC},
        {8, "Stop", "stop", 0xFF7070},
        {9, "Log", "list", 0x35D07F},
        {10, "Alert", "bell", 0xFF7070},
        {11, "Clean", "trash", 0xA3B2BC},
        {12, "Home", "home", 0x35D07F},
    };
    model_lock();
    s_button_count = (int)(sizeof(defaults) / sizeof(defaults[0]));
    memcpy(s_buttons, defaults, sizeof(defaults));
    s_buttons_version++;
    model_unlock();
}

int deck_model_button_count(void)
{
    model_lock();
    int count = s_button_count;
    model_unlock();
    return count;
}

bool deck_model_get_button(int index, deck_button_t *out)
{
    if (!out || index < 0) return false;
    model_lock();
    bool ok = index < s_button_count;
    if (ok) *out = s_buttons[index];
    model_unlock();
    return ok;
}

/* Same tile layout; label text, color and gauge values may differ. */
static bool same_structure(const deck_button_t *a, const deck_button_t *b)
{
    deck_button_t x = *a, y = *b;
    x.gauge_percent = y.gauge_percent = 0;
    memset(x.gauge_text, 0, sizeof(x.gauge_text));
    memset(y.gauge_text, 0, sizeof(y.gauge_text));
    memset(x.label, 0, sizeof(x.label));
    memset(y.label, 0, sizeof(y.label));
    memset(x.sub, 0, sizeof(x.sub));
    memset(y.sub, 0, sizeof(y.sub));
    x.progress = y.progress = 0;
    x.color = y.color = 0;
    return memcmp(&x, &y, sizeof(x)) == 0;
}

bool deck_model_replace_buttons(const deck_button_t *buttons, int count)
{
    if (!buttons || count < 0 || count > DECK_MAX_BUTTONS) return false;
    model_lock();
    /* The host re-pushes the whole layout on every refresh (dynamic titles,
     * page switches). Identical content must not re-render the grid, and
     * changing gauge values must not tear down the tile under a finger. */
    if (count == s_button_count) {
        bool same = true;
        for (int i = 0; same && i < count; ++i) same = same_structure(&s_buttons[i], &buttons[i]);
        if (same) {
            if (memcmp(s_buttons, buttons, sizeof(deck_button_t) * (size_t)count) != 0) {
                memcpy(s_buttons, buttons, sizeof(deck_button_t) * (size_t)count);
                s_live_version++;
            }
            model_unlock();
            return true;
        }
    }
    s_button_count = count;
    memcpy(s_buttons, buttons, sizeof(deck_button_t) * (size_t)count);
    s_buttons_version++;
    model_unlock();
    return true;
}

uint32_t deck_model_buttons_version(void)
{
    return s_buttons_version; /* atomic-enough read of a uint32 */
}

uint32_t deck_model_live_version(void)
{
    return s_live_version;
}

void deck_model_set_context(const char *profile, const char *page, bool can_go_back)
{
    deck_context_t next = {};
    copy_text(next.profile, sizeof(next.profile), profile ? profile : "LOCAL");
    copy_text(next.page, sizeof(next.page), page ? page : "MAIN");
    next.can_go_back = can_go_back;
    model_lock();
    if (memcmp(&next, &s_context, sizeof(next)) != 0) {
        s_context = next;
        ++s_context_version;
    }
    model_unlock();
}

deck_context_t deck_model_context(void)
{
    model_lock(); deck_context_t copy=s_context; model_unlock(); return copy;
}

uint32_t deck_model_context_version(void) { return s_context_version; }

static uint32_t record_event(int button_id, bool hold, uint32_t layout)
{
    model_lock();
    if (layout && layout != s_buttons_version) {
        model_unlock();
        ESP_LOGI(TAG, "press for button id %d dropped: the layout changed under the finger", button_id);
        return 0;
    }
    deck_button_t *button = NULL;
    for (int i = 0; i < s_button_count; ++i) {
        if (s_buttons[i].id == button_id) {
            button = &s_buttons[i];
            break;
        }
    }
    if (!button) {
        model_unlock();
        ESP_LOGW(TAG, "press for unknown button id %d", button_id);
        return 0;
    }
    deck_event_t *slot = &s_events[s_event_next];
    s_event_next = (s_event_next + 1) % DECK_EVENT_RING;
    slot->id = ++s_event_last_id;
    slot->button_id = button_id;
    slot->hold = hold;
    copy_text(slot->label, sizeof(slot->label), button->label);
    slot->timestamp_ms = esp_timer_get_time() / 1000;
    uint32_t id = (uint32_t)slot->id;
    char label[sizeof(slot->label)];
    memcpy(label, slot->label, sizeof(label));
    model_unlock();
    /* Log from the local copy: another task may recycle the ring slot once unlocked. */
    ESP_LOGI(TAG, "deck event #%u: %s (%d)", (unsigned)id, label, button_id);
    return id;
}

uint32_t deck_model_record_press(int button_id)
{
    return record_event(button_id, false, 0);
}

uint32_t deck_model_record_hold(int button_id)
{
    return record_event(button_id, true, 0);
}

uint32_t deck_model_record_touch(int button_id, bool hold, uint32_t layout)
{
    return record_event(button_id, hold, layout);
}

int deck_model_events_since(int since_id, deck_event_t *out, int max_out)
{
    if (!out || max_out <= 0) return 0;
    model_lock();
    int written = 0;
    /* Ring holds the newest DECK_EVENT_RING events; walk oldest first. */
    for (int i = DECK_EVENT_RING; i > 0 && written < max_out; --i) {
        const deck_event_t *slot = &s_events[(s_event_next + DECK_EVENT_RING - i) % DECK_EVENT_RING];
        if (slot->id <= 0 || slot->id <= since_id) continue;
        out[written++] = *slot;
    }
    model_unlock();
    return written;
}

int deck_model_last_event_id(void)
{
    model_lock();
    int id = s_event_last_id;
    model_unlock();
    return id;
}

void deck_model_request_feedback(int button_id, deck_feedback_t kind)
{
    model_lock();
    if (s_feedback_count == DECK_FEEDBACK_QUEUE) { /* drop the oldest */
        s_feedback_head = (s_feedback_head + 1) % DECK_FEEDBACK_QUEUE;
        --s_feedback_count;
    }
    int at = (s_feedback_head + s_feedback_count) % DECK_FEEDBACK_QUEUE;
    s_feedback[at].button_id = button_id;
    s_feedback[at].kind = kind;
    s_feedback[at].seq = ++s_feedback_seq;
    ++s_feedback_count;
    model_unlock();
}

uint32_t deck_model_take_feedback(int *button_id, deck_feedback_t *kind)
{
    model_lock();
    uint32_t seq = 0;
    if (s_feedback_count) {
        seq = s_feedback[s_feedback_head].seq;
        if (button_id) *button_id = s_feedback[s_feedback_head].button_id;
        if (kind) *kind = s_feedback[s_feedback_head].kind;
        s_feedback_head = (s_feedback_head + 1) % DECK_FEEDBACK_QUEUE;
        --s_feedback_count;
    }
    model_unlock();
    return seq;
}

void deck_model_set_dimmed(bool dimmed)
{
    model_lock(); s_dimmed = dimmed; model_unlock();
}

bool deck_model_dimmed(void)
{
    model_lock(); bool dimmed = s_dimmed; model_unlock(); return dimmed;
}

static int s_screen_request = -1;
static deck_screen_t s_screen = DECK_SCREEN_DECK;
static bool s_touch_return;
static char s_ambient[DECK_AMBIENT_MAX + 1];
static uint32_t s_ambient_version = 1;

void deck_model_request_screen(deck_screen_t screen)
{
    model_lock(); s_screen_request = screen; model_unlock();
}

int deck_model_take_screen_request(void)
{
    model_lock(); int request = s_screen_request; s_screen_request = -1; model_unlock();
    return request;
}

void deck_model_set_screen(deck_screen_t screen)
{
    model_lock(); s_screen = screen; model_unlock();
}

deck_screen_t deck_model_screen(void)
{
    model_lock(); deck_screen_t screen = s_screen; model_unlock(); return screen;
}

void deck_model_note_touch_return(void)
{
    model_lock(); s_touch_return = true; model_unlock();
}

bool deck_model_take_touch_return(void)
{
    model_lock(); bool value = s_touch_return; s_touch_return = false; model_unlock();
    return value;
}

void deck_model_set_ambient(const char *line)
{
    model_lock();
    if (strncmp(s_ambient, line ? line : "", sizeof(s_ambient)) != 0) {
        copy_text(s_ambient, sizeof(s_ambient), line ? line : "");
        ++s_ambient_version;
    }
    model_unlock();
}

void deck_model_ambient(char *out, size_t size)
{
    model_lock(); copy_text(out, size, s_ambient); model_unlock();
}

uint32_t deck_model_ambient_version(void)
{
    model_lock(); uint32_t version = s_ambient_version; model_unlock();
    return version;
}

static bool s_locked;
static int s_brightness = 100, s_brightness_wanted = -1;
static bool s_brightness_save;

void deck_model_set_locked(bool locked)
{
    model_lock(); s_locked = locked; model_unlock();
}

bool deck_model_locked(void)
{
    model_lock(); bool locked = s_locked; model_unlock(); return locked;
}

void deck_model_set_brightness(int level)
{
    model_lock(); s_brightness = level; model_unlock();
}

int deck_model_brightness(void)
{
    model_lock(); int level = s_brightness; model_unlock(); return level;
}

void deck_model_request_brightness(int level, bool save)
{
    if (level < 1 || level > 100) return;
    /* A save stays pending until main takes it, even if a later drag step only previews. */
    model_lock(); s_brightness = s_brightness_wanted = level; s_brightness_save = s_brightness_save || save; model_unlock();
}

bool deck_model_take_brightness_request(int *level, bool *save)
{
    model_lock();
    const bool pending = s_brightness_wanted >= 0;
    if (pending) { *level = s_brightness_wanted; *save = s_brightness_save; s_brightness_wanted = -1; s_brightness_save = false; }
    model_unlock();
    return pending;
}

void deck_model_request_wake(void)
{
    model_lock(); s_dimmed = false; ++s_wake_seq; model_unlock();
}

uint32_t deck_model_wake_sequence(void)
{
    model_lock(); uint32_t seq = s_wake_seq; model_unlock(); return seq;
}

void deck_model_note_host(void)
{
    int64_t now = esp_timer_get_time() / 1000;
    model_lock(); s_host_seen_ms = now; model_unlock();
}

bool deck_model_host_linked(int64_t timeout_ms)
{
    int64_t now = esp_timer_get_time() / 1000;
    model_lock(); int64_t seen = s_host_seen_ms; model_unlock();
    return seen >= 0 && now - seen <= timeout_ms;
}

static const char *text_of(const cJSON *item, const char *key);

static bool parse_color_hex(const char *text, uint32_t *out)
{
    if (!text) return false;
    while (*text == ' ') ++text;
    if (text[0] == '#') ++text;
    if (strlen(text) != 6) return false;
    uint32_t value = 0;
    for (int i = 0; i < 6; ++i) {
        char c = text[i];
        int digit = c >= '0' && c <= '9' ? c - '0' :
                    c >= 'a' && c <= 'f' ? c - 'a' + 10 :
                    c >= 'A' && c <= 'F' ? c - 'A' + 10 : -1;
        if (digit < 0) return false;
        value = (value << 4) | (uint32_t)digit;
    }
    *out = value;
    return true;
}

bool deck_model_buttons_from_json(const char *json_text, deck_button_t *out,
                                  int max_out, int *count)
{
    if (!json_text || !out || max_out <= 0 || !count) return false;
    cJSON *json = cJSON_Parse(json_text);
    if (!json) return false;
    const cJSON *buttons = cJSON_GetObjectItemCaseSensitive(json, "buttons");
    bool valid = cJSON_IsArray(buttons) && cJSON_GetArraySize(buttons) <= max_out;
    int parsed = 0;
    for (cJSON *item = valid ? buttons->child : NULL; item && parsed < max_out;
         item = item->next) {
        const cJSON *id = cJSON_GetObjectItemCaseSensitive(item, "id");
        const cJSON *label = cJSON_GetObjectItemCaseSensitive(item, "label");
        const cJSON *icon = cJSON_GetObjectItemCaseSensitive(item, "icon");
        const cJSON *color = cJSON_GetObjectItemCaseSensitive(item, "color");
        if (!cJSON_IsNumber(id) || id->valuedouble < 1 || id->valuedouble > DECK_MAX_BUTTONS ||
            id->valuedouble != (int)id->valuedouble ||
            !cJSON_IsString(label) || label->valuestring[0] == '\0') {
            valid = false;
            break;
        }
        for (int previous = 0; previous < parsed; ++previous)
            if (out[previous].id == (int)id->valuedouble) valid = false;
        if (!valid) break;
        memset(&out[parsed], 0, sizeof(out[parsed]));
        out[parsed].id = (int)id->valuedouble;
        copy_text(out[parsed].label, sizeof(out[parsed].label), label->valuestring);
        snprintf(out[parsed].icon, sizeof(out[parsed].icon), "%s",
                 cJSON_IsString(icon) && icon->valuestring[0] ? icon->valuestring : "ok");
        uint32_t color_value = 0x35D07F;
        if (color && (!cJSON_IsString(color) || !parse_color_hex(color->valuestring, &color_value))) {
            valid = false;
            break;
        }
        out[parsed].color = color_value;
        const cJSON *gauge = cJSON_GetObjectItemCaseSensitive(item, "gauge");
        if (cJSON_IsObject(gauge)) {
            const cJSON *percent = cJSON_GetObjectItemCaseSensitive(gauge, "p");
            const cJSON *gauge_text = cJSON_GetObjectItemCaseSensitive(gauge, "t");
            if (!cJSON_IsNumber(percent) || !cJSON_IsString(gauge_text)) {valid = false; break;}
            out[parsed].has_gauge = true;
            out[parsed].gauge_percent = (uint8_t)(percent->valuedouble < 0 ? 0 : percent->valuedouble > 100 ? 100 : percent->valuedouble);
            copy_text(out[parsed].gauge_text, sizeof(out[parsed].gauge_text), gauge_text->valuestring);
            const cJSON *badge = cJSON_GetObjectItemCaseSensitive(gauge, "b");
            if (cJSON_IsString(badge)) snprintf(out[parsed].gauge_badge, sizeof(out[parsed].gauge_badge), "%s", badge->valuestring);
        }
        const cJSON *title = cJSON_GetObjectItemCaseSensitive(item, "title");
        const cJSON *size = cJSON_GetObjectItemCaseSensitive(title, "size");
        const cJSON *position = cJSON_GetObjectItemCaseSensitive(title, "position");
        if (cJSON_IsNumber(size)) {
            if (size->valueint != 16 && size->valueint != 20 && size->valueint != 24 && size->valueint != 28) {valid=false;break;}
            out[parsed].title_size=size->valueint;
        }
        out[parsed].title_bold=cJSON_IsTrue(cJSON_GetObjectItemCaseSensitive(title,"bold"));
        {
            const cJSON *span = cJSON_GetObjectItemCaseSensitive(item, "span");
            out[parsed].span = 1;
            if (span) {
                if (!cJSON_IsNumber(span) || span->valuedouble < 1 || span->valuedouble > 3) {valid = false; break;}
                out[parsed].span = (uint8_t)span->valueint;
            }
            copy_text(out[parsed].sub, sizeof(out[parsed].sub), text_of(item, "sub"));
            const cJSON *progress = cJSON_GetObjectItemCaseSensitive(item, "progress");
            if (cJSON_IsNumber(progress)) {
                out[parsed].has_progress = true;
                out[parsed].progress = (uint8_t)(progress->valuedouble < 0 ? 0 : progress->valuedouble > 100 ? 100 : progress->valuedouble);
            }
            out[parsed].ring = cJSON_IsTrue(cJSON_GetObjectItemCaseSensitive(item, "ring"));
        }
        out[parsed].has_hold=cJSON_IsTrue(cJSON_GetObjectItemCaseSensitive(item,"hold"));
        out[parsed].has_double=cJSON_IsTrue(cJSON_GetObjectItemCaseSensitive(item,"double"));
        {const cJSON *confirm=cJSON_GetObjectItemCaseSensitive(item,"cf");out[parsed].confirm=cJSON_IsTrue(confirm)||(cJSON_IsNumber(confirm)&&confirm->valueint==1);}
        {
            const struct {const char *key; uint8_t bit; uint32_t *target;} styles[] = {
                {"bg", DECK_STYLE_BG, &out[parsed].bg}, {"text_color", DECK_STYLE_TEXT, &out[parsed].text},
                {"border", DECK_STYLE_BORDER, &out[parsed].border}};
            for (size_t s = 0; s < sizeof(styles) / sizeof(styles[0]); ++s) {
                const cJSON *value = cJSON_GetObjectItemCaseSensitive(item, styles[s].key);
                if (!value) continue;
                if (!cJSON_IsString(value) || !parse_color_hex(value->valuestring, styles[s].target)) {valid = false; break;}
                out[parsed].style |= styles[s].bit;
            }
            if (!valid) break;
        }
        if (cJSON_IsString(position)) {
            if (!strcmp(position->valuestring,"top")) out[parsed].title_position=1;
            else if (!strcmp(position->valuestring,"middle")) out[parsed].title_position=2;
            else if (!strcmp(position->valuestring,"hidden")) out[parsed].title_position=3;
            else if (strcmp(position->valuestring,"bottom")) {valid=false;break;}
        }
        ++parsed;
    }
    cJSON_Delete(json);
    if (!valid) return false;
    *count = parsed;
    return true;
}


/* ---- Cockpit screens: agents, mixer, PC status -------------------------------------------------- */
static deck_agent_t s_agents[DECK_AGENTS_MAX];
static deck_fader_t s_faders[DECK_FADERS_MAX];
static deck_stat_t s_stats[DECK_STATS_MAX];
static int s_agent_count, s_fader_count, s_stat_count;
static uint32_t s_agents_version = 1, s_faders_version = 1, s_stats_version = 1;

#define DECK_LINE_QUEUE 8
#define DECK_LINE_MAX 96
static char s_lines[DECK_LINE_QUEUE][DECK_LINE_MAX];
static int s_line_head, s_line_count;

/* An id travels back to the host inside a JSON string, so it may not contain what would end that string. */
static bool id_is_safe(const char *id)
{
    if (!id || !id[0] || strlen(id) > DECK_ID_MAX) return false;
    for (const char *c = id; *c; ++c) {
        if ((unsigned char)*c < 0x20 || *c == '"' || *c == '\\') return false;
    }
    return true;
}

static const char *text_of(const cJSON *item, const char *key)
{
    const cJSON *value = cJSON_GetObjectItemCaseSensitive(item, key);
    return cJSON_IsString(value) ? value->valuestring : "";
}

static uint8_t percent_of(const cJSON *item, const char *key)
{
    const cJSON *value = cJSON_GetObjectItemCaseSensitive(item, key);
    if (!cJSON_IsNumber(value) || value->valuedouble < 0) return 0;
    return (uint8_t)(value->valuedouble > 100 ? 100 : value->valuedouble);
}

/* Parses {"<key>":[...]} with at most `max` entries; NULL when the text is not that. */
static cJSON *list_from_json(const char *json_text, const char *key, int max, const cJSON **list)
{
    cJSON *json = json_text ? cJSON_Parse(json_text) : NULL;
    *list = json ? cJSON_GetObjectItemCaseSensitive(json, key) : NULL;
    if (!cJSON_IsArray(*list) || cJSON_GetArraySize(*list) > max) {
        cJSON_Delete(json);
        return NULL;
    }
    return json;
}

bool deck_model_agents_from_json(const char *json_text)
{
    const cJSON *list = NULL;
    cJSON *json = list_from_json(json_text, "agents", DECK_AGENTS_MAX, &list);
    if (!json) return false;
    deck_agent_t parsed[DECK_AGENTS_MAX];
    memset(parsed, 0, sizeof(parsed));
    int count = 0;
    bool valid = true;
    for (const cJSON *item = list->child; item; item = item->next) {
        const char *id = text_of(item, "id"), *state = text_of(item, "state");
        if (!id_is_safe(id) || !text_of(item, "name")[0]) { valid = false; break; }
        copy_text(parsed[count].id, sizeof(parsed[count].id), id);
        copy_text(parsed[count].name, sizeof(parsed[count].name), text_of(item, "name"));
        copy_text(parsed[count].text, sizeof(parsed[count].text), text_of(item, "text"));
        copy_text(parsed[count].sub, sizeof(parsed[count].sub), text_of(item, "sub"));
        copy_text(parsed[count].at, sizeof(parsed[count].at), text_of(item, "at"));
        const cJSON *asks = cJSON_GetObjectItemCaseSensitive(item, "q");
        parsed[count].asks = cJSON_IsNumber(asks) && asks->valueint == 1;
        parsed[count].state = !strcmp(state, "waiting") ? DECK_AGENT_WAITING :
                              !strcmp(state, "working") ? DECK_AGENT_WORKING : DECK_AGENT_IDLE;
        ++count;
    }
    cJSON_Delete(json);
    if (!valid) return false;
    model_lock();
    if (count != s_agent_count || memcmp(parsed, s_agents, sizeof(parsed)) != 0) {
        memcpy(s_agents, parsed, sizeof(parsed));
        s_agent_count = count;
        ++s_agents_version;
    }
    model_unlock();
    return true;
}

bool deck_model_faders_from_json(const char *json_text)
{
    const cJSON *list = NULL;
    cJSON *json = list_from_json(json_text, "faders", DECK_FADERS_MAX, &list);
    if (!json) return false;
    deck_fader_t parsed[DECK_FADERS_MAX];
    memset(parsed, 0, sizeof(parsed));
    int count = 0;
    bool valid = true;
    for (const cJSON *item = list->child; item; item = item->next) {
        const char *id = text_of(item, "id");
        uint32_t color = 0x58E09B;
        const cJSON *shade = cJSON_GetObjectItemCaseSensitive(item, "color");
        if (!id_is_safe(id) || (shade && (!cJSON_IsString(shade) || !parse_color_hex(shade->valuestring, &color)))) {
            valid = false;
            break;
        }
        copy_text(parsed[count].id, sizeof(parsed[count].id), id);
        copy_text(parsed[count].name, sizeof(parsed[count].name), text_of(item, "name"));
        parsed[count].level = percent_of(item, "level");
        parsed[count].muted = cJSON_IsTrue(cJSON_GetObjectItemCaseSensitive(item, "muted"));
        parsed[count].mic = cJSON_IsTrue(cJSON_GetObjectItemCaseSensitive(item, "mic"));
        parsed[count].color = color;
        ++count;
    }
    cJSON_Delete(json);
    if (!valid) return false;
    model_lock();
    if (count != s_fader_count || memcmp(parsed, s_faders, sizeof(parsed)) != 0) {
        memcpy(s_faders, parsed, sizeof(parsed));
        s_fader_count = count;
        ++s_faders_version;
    }
    model_unlock();
    return true;
}

bool deck_model_stats_from_json(const char *json_text)
{
    const cJSON *list = NULL;
    cJSON *json = list_from_json(json_text, "stats", DECK_STATS_MAX, &list);
    if (!json) return false;
    deck_stat_t parsed[DECK_STATS_MAX];
    memset(parsed, 0, sizeof(parsed));
    int count = 0;
    bool valid = true;
    for (const cJSON *item = list->child; item; item = item->next) {
        uint32_t color = 0x58E09B;
        const cJSON *shade = cJSON_GetObjectItemCaseSensitive(item, "color");
        if (shade && (!cJSON_IsString(shade) || !parse_color_hex(shade->valuestring, &color))) { valid = false; break; }
        copy_text(parsed[count].name, sizeof(parsed[count].name), text_of(item, "name"));
        copy_text(parsed[count].value, sizeof(parsed[count].value), text_of(item, "value"));
        copy_text(parsed[count].unit, sizeof(parsed[count].unit), text_of(item, "unit"));
        parsed[count].percent = percent_of(item, "p");
        parsed[count].warn = cJSON_IsTrue(cJSON_GetObjectItemCaseSensitive(item, "warn"));
        parsed[count].color = color;
        ++count;
    }
    cJSON_Delete(json);
    if (!valid) return false;
    model_lock();
    if (count != s_stat_count || memcmp(parsed, s_stats, sizeof(parsed)) != 0) {
        memcpy(s_stats, parsed, sizeof(parsed));
        s_stat_count = count;
        ++s_stats_version;
    }
    model_unlock();
    return true;
}

int deck_model_agents(deck_agent_t *out, int max_out)
{
    if (!out) return 0;
    model_lock();
    int count = s_agent_count < max_out ? s_agent_count : max_out;
    if (count > 0) memcpy(out, s_agents, sizeof(deck_agent_t) * (size_t)count);
    model_unlock();
    return count;
}

int deck_model_faders(deck_fader_t *out, int max_out)
{
    if (!out) return 0;
    model_lock();
    int count = s_fader_count < max_out ? s_fader_count : max_out;
    if (count > 0) memcpy(out, s_faders, sizeof(deck_fader_t) * (size_t)count);
    model_unlock();
    return count;
}

int deck_model_stats(deck_stat_t *out, int max_out)
{
    if (!out) return 0;
    model_lock();
    int count = s_stat_count < max_out ? s_stat_count : max_out;
    if (count > 0) memcpy(out, s_stats, sizeof(deck_stat_t) * (size_t)count);
    model_unlock();
    return count;
}

uint32_t deck_model_agents_version(void) { return s_agents_version; }
uint32_t deck_model_faders_version(void) { return s_faders_version; }
uint32_t deck_model_stats_version(void) { return s_stats_version; }

static int s_view_request = -1;

void deck_model_request_view(int view)
{
    model_lock(); s_view_request = view; model_unlock();
}

int deck_model_take_view_request(void)
{
    model_lock(); int request = s_view_request; s_view_request = -1; model_unlock();
    return request;
}

void deck_model_queue_line(const char *line)
{
    if (!line || strlen(line) >= DECK_LINE_MAX) return;
    model_lock();
    if (s_line_count == DECK_LINE_QUEUE) { /* drop the oldest: the newest touch matters most */
        s_line_head = (s_line_head + 1) % DECK_LINE_QUEUE;
        --s_line_count;
    }
    strcpy(s_lines[(s_line_head + s_line_count) % DECK_LINE_QUEUE], line);
    ++s_line_count;
    model_unlock();
}

bool deck_model_take_line(char *out, size_t size)
{
    bool found = false;
    model_lock();
    if (s_line_count && out && size >= DECK_LINE_MAX) {
        strcpy(out, s_lines[s_line_head]);
        s_line_head = (s_line_head + 1) % DECK_LINE_QUEUE;
        --s_line_count;
        found = true;
    }
    model_unlock();
    return found;
}

/* ---- Messages from the host --------------------------------------------------------------------- */
static char s_notice[DECK_NOTICE_MAX + 1];
static int s_notice_level, s_notice_seconds;
static bool s_notice_pending;

bool deck_model_notice_from_line(const char *args)
{
    static const char *const levels[] = {"info", "ok", "warn", "error"};
    const char *space = args ? strchr(args, ' ') : NULL;
    if (!space) return false;
    int level = -1;
    for (int i = 0; i < 4; ++i)
        if ((size_t)(space - args) == strlen(levels[i]) && !strncmp(args, levels[i], (size_t)(space - args))) level = i;
    int seconds = 0;
    const char *at = space + 1;
    for (; *at >= '0' && *at <= '9' && seconds <= DECK_NOTICE_SECONDS_MAX; ++at) seconds = seconds * 10 + (*at - '0');
    if (level < 0 || at == space + 1 || *at != ' ' || seconds < 1 || seconds > DECK_NOTICE_SECONDS_MAX || !at[1])
        return false;
    model_lock();
    copy_text(s_notice, sizeof(s_notice), at + 1); /* cut on a character boundary, control characters flattened */
    s_notice_level = level;
    s_notice_seconds = seconds;
    s_notice_pending = true;
    model_unlock();
    return true;
}

bool deck_model_take_notice(char *text, size_t size, int *level, int *seconds)
{
    model_lock();
    const bool fresh = s_notice_pending && text && size;
    if (fresh) {
        copy_text(text, size, s_notice);
        if (level) *level = s_notice_level;
        if (seconds) *seconds = s_notice_seconds;
        s_notice_pending = false;
    }
    model_unlock();
    return fresh;
}

/* ---- The rail ----------------------------------------------------------------------------------- */
static deck_rail_item_t s_rail[DECK_RAIL_MAX];
static int s_rail_count;
static uint32_t s_rail_version = 1;

bool deck_model_rail_from_json(const char *json_text)
{
    const cJSON *list = NULL;
    cJSON *json = list_from_json(json_text, "rail", DECK_RAIL_MAX, &list);
    if (!json) return false;
    deck_rail_item_t parsed[DECK_RAIL_MAX];
    memset(parsed, 0, sizeof(parsed));
    static const char *const kinds[] = {"keys", "agents", "mixer", "status", "page", "act"};
    int count = 0;
    bool valid = true;
    for (const cJSON *item = list->child; item; item = item->next) {
        const char *kind = text_of(item, "k");
        int found = -1;
        for (int i = 0; i < 6; ++i) if (!strcmp(kind, kinds[i])) found = i;
        if (found < 0) { valid = false; break; }
        parsed[count].kind = (uint8_t)found;
        if (found == 5) {  /* a shortcut that runs steps on the PC: only its icon is drawn */
            copy_text(parsed[count].icon, sizeof(parsed[count].icon), text_of(item, "i"));
        } else if (found == 4) {
            if (!text_of(item, "p")[0] || !text_of(item, "g")[0]) { valid = false; break; }
            copy_text(parsed[count].icon, sizeof(parsed[count].icon), text_of(item, "i"));
            copy_text(parsed[count].profile, sizeof(parsed[count].profile), text_of(item, "p"));
            copy_text(parsed[count].page, sizeof(parsed[count].page), text_of(item, "g"));
        }
        ++count;
    }
    cJSON_Delete(json);
    if (!valid) return false;
    model_lock();
    if (count != s_rail_count || memcmp(parsed, s_rail, sizeof(parsed)) != 0) {
        memcpy(s_rail, parsed, sizeof(parsed));
        s_rail_count = count;
        ++s_rail_version;
    }
    model_unlock();
    return true;
}

int deck_model_rail(deck_rail_item_t *out, int max_out)
{
    if (!out) return 0;
    model_lock();
    int count = s_rail_count < max_out ? s_rail_count : max_out;
    if (count > 0) memcpy(out, s_rail, sizeof(deck_rail_item_t) * (size_t)count);
    model_unlock();
    return count;
}

uint32_t deck_model_rail_version(void) { return s_rail_version; }
