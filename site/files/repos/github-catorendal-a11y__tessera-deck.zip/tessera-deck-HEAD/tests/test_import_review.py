"""Import review, secret redaction and safe variable substitution in shell and HTTP actions."""
import copy
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import Mock, patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'host'))
import tesserad as deck
import host_support  # noqa: E402
from import_review import export_left_out, redact_secrets, review, strip_executable
from tessera_app import Editor


def bundle():
    return {'default_profile': 'Main', 'profiles': {'Main': {'match': [], 'pages': {'First': [
        {'id': 1, 'label': 'Safe', 'actions': [{'type': 'hotkey', 'keys': 'ctrl+c'}]},
        {'id': 2, 'label': 'Run', 'actions': [{'type': 'shell', 'command': 'del /q C:\\temp\\*'}]},
        {'id': 3, 'label': 'Web', 'actions': [{'type': 'http', 'url': 'https://example.com/hook', 'method': 'POST',
                                               'body': 'x', 'headers': {'Authorization': 'Bearer secret123',
                                                                      'Content-Type': 'application/json'}}]},
        {'id': 4, 'label': 'Docs', 'actions': [{'type': 'open', 'target': 'https://example.com'}],
         'hold_actions': [{'type': 'open', 'target': 'C:\\Tools\\thing.exe'}]},
        {'id': 5, 'label': 'Toggle', 'actions': [], 'states': [
            {'label': 'A', 'actions': [{'type': 'shell', 'command': 'echo a'}]},
            {'label': 'B', 'actions': [{'type': 'hotkey', 'keys': 'ctrl+v'}]}]}]}}},
        'triggers': [{'when': {'type': 'startup'}, 'actions': [{'type': 'shell', 'command': 'calc'}]}]}


class ReviewTests(unittest.TestCase):
    def test_everything_that_executes_code_or_reaches_the_network_is_listed_with_its_location(self):
        findings = review(bundle())
        by_where = {(f['where'], f['kind']): f for f in findings}
        self.assertEqual(by_where[("Profile 'Main' / page 'First' / button 2 'Run'", 'shell')]['risk'], 'high')
        self.assertEqual(by_where[("Profile 'Main' / page 'First' / button 3 'Web'", 'http')]['risk'], 'medium')
        locations = {f['where'] for f in findings}
        self.assertIn("Profile 'Main' / page 'First' / button 4 'Docs' (long press)", locations)
        self.assertIn("Profile 'Main' / page 'First' / button 5 'Toggle' state 1", locations)
        automatic = [f for f in findings if f['automatic']]
        self.assertEqual([(f['kind'], f['risk']) for f in automatic], [('shell', 'high')])
        self.assertFalse(any("button 1 'Safe'" in where for where in locations))
        self.assertFalse(any('https://example.com' in f['detail'] for f in findings if f['kind'] == 'open'))

    def test_an_http_action_that_sends_an_environment_variable_in_a_header_is_high_risk(self):
        action = {'type': 'http', 'url': 'https://example.com/hook',
                  'headers': {'Authorization': 'Bearer $(env:GITHUB_TOKEN)'}}
        config = {'profiles': {'P': {'pages': {'A': [{'id': 1, 'label': 'X', 'actions': [action]}]}}}}
        finding = [f for f in review(config) if f['kind'] == 'http'][0]
        self.assertEqual(finding['risk'], 'high')
        self.assertIn('sends $(env:GITHUB_TOKEN)', finding['detail'])

    def test_the_bundled_default_profiles_have_no_web_calls_no_automatic_rules_and_only_launch_commands(self):
        config = json.loads((ROOT / 'host/profiles.default.json').read_text(encoding='utf-8'))
        findings = review(config)
        self.assertFalse([f for f in findings if f['kind'] == 'http' or f['automatic']])
        self.assertTrue(all(f['detail'].startswith('runs the command: start ""')
                            for f in findings if f['kind'] == 'shell'))

    def test_strip_executable_removes_commands_requests_launches_and_automatic_rules(self):
        safe = strip_executable(bundle())
        self.assertEqual(review(safe), [])
        self.assertEqual(safe['triggers'], [])
        page = safe['profiles']['Main']['pages']['First']
        self.assertEqual(page[0]['actions'], [{'type': 'hotkey', 'keys': 'ctrl+c'}])
        self.assertEqual(page[3]['actions'], [{'type': 'open', 'target': 'https://example.com'}])
        deck.validate_config(safe)

    def test_a_command_inside_a_timer_is_listed_and_stripped(self):
        config = bundle()
        config['profiles']['Main']['pages']['First'][0]['actions'].append(
            {'type': 'timer', 'name': 'tea', 'op': 'start', 'seconds': 60, 'actions': [{'type': 'shell', 'command': 'calc'}]})
        found = [item for item in review(config) if 'timer' in item['where']]
        self.assertEqual([(item['kind'], item['risk']) for item in found], [('shell', 'high')])
        self.assertIn("when timer 'tea' ends", found[0]['where'])
        timer = strip_executable(config)['profiles']['Main']['pages']['First'][0]['actions'][-1]
        self.assertEqual(timer['actions'], [])

    def test_text_typed_after_a_hotkey_is_listed_and_stripped(self):
        config = bundle()
        keys = config['profiles']['Main']['pages']['First']
        keys[0]['actions'] = [{'type': 'hotkey', 'keys': 'win+r'}, {'type': 'text', 'text': 'powershell -c calc'},
                              {'type': 'hotkey', 'keys': 'enter'}]
        found = [item for item in review(config) if 'types text' in item['detail']]
        self.assertEqual([(item['kind'], item['risk']) for item in found], [('hotkey', 'medium')])
        safe = strip_executable(config)['profiles']['Main']['pages']['First'][0]['actions']
        self.assertEqual([action['type'] for action in safe], ['hotkey', 'hotkey'], 'the typed command is gone')
        keys[0]['actions'] = [{'type': 'text', 'text': 'Kind regards'}]  # a text snippet on its own stays
        self.assertEqual(strip_executable(config)['profiles']['Main']['pages']['First'][0]['actions'], keys[0]['actions'])

    def test_a_rail_shortcut_with_a_command_is_listed_and_stripped(self):
        config = bundle()
        config['panel'] = {'shortcuts': [{'type': 'actions', 'label': 'Build', 'icon': 'lc:e0ff', 'actions': [{'type': 'shell', 'command': 'calc'}]}]}
        self.assertIn('Rail shortcut 1', ' '.join(item['where'] for item in review(config)))
        self.assertEqual(strip_executable(config)['panel']['shortcuts'], [], 'a step shortcut without steps is dropped')
        deck.validate_config(strip_executable(config))

    def test_plugin_commands_and_an_enabled_plugins_block_are_listed_and_stripped(self):
        config = bundle()
        config['profiles']['Main']['pages']['First'][0]['actions'].append(
            {'type': 'plugin', 'plugin': 'home-assistant', 'command': 'toggle', 'args': {'entity': 'lock.front'}})
        config['triggers'][0]['actions'].append({'type': 'plugin', 'plugin': 'home-assistant', 'command': 'toggle'})
        config['plugins'] = {'home-assistant': {'enabled': True, 'settings': {'url': 'http://elsewhere'}},
                             'obs': {'enabled': False}}
        found = {(f['kind'], f['risk'], f['automatic']): f for f in review(config) if f['kind'] in ('plugin', 'plugins')}
        self.assertIn('runs plugin home-assistant.toggle', found[('plugin', 'medium', False)]['detail'])
        self.assertIn(('plugin', 'high', True), found)
        self.assertIn('url', found[('plugins', 'medium', False)]['detail'])
        self.assertEqual(len(found), 3)
        safe = strip_executable(config)
        self.assertEqual(review(safe), [])
        self.assertNotIn('plugins', safe)
        self.assertEqual(safe['profiles']['Main']['pages']['First'][0]['actions'], [{'type': 'hotkey', 'keys': 'ctrl+c'}])

    def test_original_bundle_is_not_modified_by_review_strip_or_redaction(self):
        original = bundle()
        snapshot = copy.deepcopy(original)
        review(original)
        strip_executable(original)
        redact_secrets(original)
        self.assertEqual(original, snapshot)

    def test_export_replaces_credentials_with_environment_references(self):
        shared, names = redact_secrets(bundle())
        headers = shared['profiles']['Main']['pages']['First'][2]['actions'][0]['headers']
        self.assertEqual(headers['Authorization'], '$(env:TESSERA_AUTHORIZATION)')
        self.assertEqual(headers['Content-Type'], 'application/json')
        self.assertEqual(names, ['TESSERA_AUTHORIZATION'])
        self.assertNotIn('secret123', json.dumps(shared))

    def test_export_replaces_any_credential_header_and_address_field(self):
        config = bundle()
        action = config['profiles']['Main']['pages']['First'][2]['actions'][0]
        action['headers'] = {'Private-Token': 'glpat-abc', 'Accept': 'text/plain'}
        action['url'] = 'https://hooks.example/x?id=7&token=abc&api_key=def&q=$(var:q)&key=$(env:MINE)#top'
        shared, names = redact_secrets(config)
        action = shared['profiles']['Main']['pages']['First'][2]['actions'][0]
        self.assertEqual(action['headers'], {'Private-Token': '$(env:TESSERA_PRIVATE_TOKEN)', 'Accept': 'text/plain'})
        self.assertEqual(action['url'], 'https://hooks.example/x?id=7&token=$(env:TESSERA_TOKEN)'
                                        '&api_key=$(env:TESSERA_API_KEY)&q=$(var:q)&key=$(env:MINE)#top')
        self.assertEqual(names, ['TESSERA_API_KEY', 'TESSERA_PRIVATE_TOKEN', 'TESSERA_TOKEN'])
        self.assertNotIn('glpat-abc', json.dumps(shared))
        self.assertNotIn('=abc', json.dumps(shared))

    def test_export_names_what_it_leaves_out(self):
        config = bundle()
        self.assertEqual(export_left_out(config), [])
        config['calendar'] = {'url': 'https://example.invalid/basic.ics'}
        config['plugins'] = {'obs': {'enabled': True, 'settings': {'host': 'localhost', 'password': 'x', 'api_key': 'y'}}}
        self.assertEqual(export_left_out(config), ['the calendar address', 'plugin obs: password', 'plugin obs: api_key'])
        shared, _ = redact_secrets(config)
        self.assertNotIn('calendar', shared)
        self.assertEqual(shared['plugins']['obs']['settings'], {'host': 'localhost'})


class EditorCommandTests(unittest.TestCase):
    def test_editor_reviews_and_sanitizes_a_bundle(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'profiles.json'
            path.write_text(json.dumps(bundle()))
            editor = Editor(path, dashboard=lambda: {'running': False, 'device': {}})
            findings = editor.command('review', {'config': bundle()})['findings']
            self.assertGreaterEqual(len(findings), 5)
            safe = editor.command('sanitize', {'config': bundle()})['config']
            self.assertEqual(review(safe), [])
            with self.assertRaises(ValueError):
                editor.command('review', {'config': {'profiles': {}}})


class SubstitutionTests(unittest.TestCase):
    def daemon(self):
        daemon = host_support.test_daemon(port='TEST', no_focus=True)
        daemon.panel, daemon.log, daemon.publish_runtime = Mock(), Mock(), Mock()
        return daemon

    def test_shell_commands_refuse_values_that_could_change_the_command(self):
        daemon = self.daemon()
        daemon.custom_vars['name'] = 'build & del *'
        with self.assertRaises(ValueError):
            daemon.substitute('echo $(var:name)', 'shell')
        daemon.custom_vars['name'] = 'release-1.2'
        self.assertEqual(daemon.substitute('echo $(var:name)', 'shell'), 'echo release-1.2')
        daemon.custom_vars['bad'] = 'a"b'
        with self.assertRaises(ValueError):
            daemon.run_action({'type': 'shell', 'command': 'echo $(var:bad)'})

    def test_urls_percent_encode_variable_values_but_text_labels_stay_plain(self):
        daemon = self.daemon()
        daemon.custom_vars['q'] = 'a b&c=d/é'
        self.assertEqual(daemon.substitute('https://x.test/?q=$(var:q)', 'url'),
                         'https://x.test/?q=a%20b%26c%3Dd%2F%C3%A9')
        self.assertEqual(daemon.substitute('Hello $(var:q)'), 'Hello a b&c=d/é')

    def test_http_headers_and_body_expand_environment_credentials_at_run_time(self):
        daemon = self.daemon()
        seen = {}

        def fake_urlopen(request, timeout):
            seen['headers'] = dict(request.header_items())
            seen['body'] = request.data
            response = Mock()
            response.__enter__ = Mock(return_value=Mock(read=Mock(return_value=b'')))
            response.__exit__ = Mock(return_value=False)
            return response

        with patch.dict(os.environ, {'TESSERA_TOKEN': 'tok-1'}), \
                patch.object(deck.WEB_OPENER, 'open', fake_urlopen):
            daemon.run_action({'type': 'http', 'url': 'http://127.0.0.1/x', 'method': 'POST',
                               'headers': {'Authorization': 'Bearer $(env:TESSERA_TOKEN)'},
                               'body': '{"k":"$(env:TESSERA_TOKEN)","missing":"$(env:NOPE_NOT_SET)"}'})
        self.assertEqual(seen['headers']['Authorization'], 'Bearer tok-1')
        self.assertEqual(seen['body'], b'{"k":"tok-1","missing":""}')


if __name__ == '__main__':
    unittest.main()
