"""Host tests, part two: runtime status, sensors, toggle keys, the control API, focus, reloads and triggers."""
from platform_windows import input as win_input
import copy
import json
from pathlib import Path
import sys
import tempfile
import threading
import time
import types
import unittest
from io import BytesIO
from unittest.mock import Mock, call, patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'host'))
from platform_marks import windows_only  # noqa: E402
import psutil
import tesserad as deck
from system_stats import select_hwinfo_metrics
from deck_assets import Assets
from deck_control import Controller, autostart_enabled, set_autostart, startup_line
from host_support import HostCase, test_daemon


class HostRuntimeTests(HostCase):
    def test_runtime_file_publishes_live_gauges_for_the_active_page(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'profiles.json'
            path.write_text((ROOT / 'host/profiles.default.json').read_text(encoding='utf-8'), encoding='utf-8')
            daemon = test_daemon(path)
            daemon.panel = Mock()
            daemon.log = Mock()
            daemon.page = 'status'
            daemon.stats.raw = {'cpu_load': 42.0, 'cpu_temp': 91.0}
            daemon.publish_runtime(True, force=True)
            published = json.loads(daemon.runtime_path.read_text(encoding='utf-8'))
            self.assertEqual(published['gauges']['1'], {'p': 42, 't': '42%', 'b': 'lc:e038', 'color': '#35D07F'})
            self.assertEqual(published['gauges']['3']['color'], '#FF7070')
            self.assertEqual(published['gauges']['7'], {'p': 0, 't': '--', 'b': 'lc:e038', 'color': '#4A5A63'})
            daemon.page = 'main'
            daemon.publish_runtime(True, force=True)
            self.assertEqual(json.loads(daemon.runtime_path.read_text(encoding='utf-8'))['gauges'], {})

    def test_runtime_file_publishes_widget_text_for_the_editor_tile(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'profiles.json'
            config = json.loads((ROOT / 'host/profiles.default.json').read_text(encoding='utf-8'))
            profile = config['default_profile']
            page = next(iter(config['profiles'][profile]['pages']))
            config['profiles'][profile]['pages'][page] = [{'id': 1, 'label': 'Clock', 'icon': 'ok', 'span': 2, 'live': 'clock', 'actions': []},
                                                          {'id': 4, 'label': 'Mute', 'icon': 'ok', 'actions': []}]
            config['display'] = dict(config.get('display', {}), clock='24h')  # not this PC's own Windows format
            path.write_text(json.dumps(config), encoding='utf-8')
            daemon = test_daemon(path)
            daemon.panel, daemon.log = Mock(), Mock()
            daemon.profile, daemon.page = profile, page
            daemon.publish_runtime(True, force=True)
            widgets = json.loads(daemon.runtime_path.read_text(encoding='utf-8'))['widgets']
            self.assertEqual(list(widgets), ['1'])  # a normal key is not a widget
            self.assertRegex(widgets['1']['label'], r'^\d\d:\d\d$')

    def test_libre_hardware_monitor_tree_maps_to_the_right_cpu_and_gpu_metrics(self):
        from lhm_reader import flatten_sensor_tree
        def sensor(text, sensor_id, value):
            return {'Text': text, 'SensorId': sensor_id, 'Value': value, 'Children': []}
        tree = {'Text': 'Sensor', 'Children': [{'Text': 'PC', 'Children': [
            {'Text': 'AMD Ryzen 7 7800X3D', 'Children': [
                {'Text': 'Powers', 'Children': [sensor('Package', '/amdcpu/0/power/0', '26,5 W')]},
                {'Text': 'Clocks', 'Children': [sensor('Cores (Average)', '/amdcpu/0/clock/9', '3874,0 MHz'),
                                                 sensor('Bus Speed', '/amdcpu/0/clock/8', '100,0 MHz')]},
                {'Text': 'Temperatures', 'Children': [sensor('Core (Tctl/Tdie)', '/amdcpu/0/temperature/2', '57,8 °C')]}]},
            {'Text': 'AMD Radeon(TM) Graphics', 'Children': [
                {'Text': 'Temperatures', 'Children': [sensor('GPU VR SoC', '/gpu-amd/0/temperature/1', '41,0 °C')]}]},
            {'Text': 'AMD Radeon RX 6950 XT', 'Children': [
                {'Text': 'Powers', 'Children': [sensor('GPU Package', '/gpu-amd/5/power/0', '48,0 W')]},
                {'Text': 'Clocks', 'Children': [sensor('GPU Core', '/gpu-amd/5/clock/0', '313,0 MHz')]},
                {'Text': 'Temperatures', 'Children': [sensor('GPU Core', '/gpu-amd/5/temperature/0', '46,0 °C'),
                                                      sensor('GPU Hot Spot', '/gpu-amd/5/temperature/2', '56,0 °C')]},
                {'Text': 'Fans', 'Children': [sensor('GPU Fan', '/gpu-amd/5/fan/0', '301 RPM')]}]}]}]}
        metrics = select_hwinfo_metrics(flatten_sensor_tree(tree))
        self.assertEqual(metrics['cpu_temp'], 57.8)
        self.assertEqual(metrics['cpu_power'], 26.5)  # not the GPU's package power
        self.assertEqual(metrics['cpu_clock'], 3874.0)
        self.assertEqual(metrics['gpu_temp'], 46.0)
        self.assertEqual(metrics['gpu_power'], 48.0)
        self.assertEqual(metrics['gpu_clock'], 313.0)
        self.assertEqual(metrics['gpu_fan'], 301.0)

    def toggle_daemon(self):
        daemon = self.daemon()
        page = daemon.config['profiles']['main']['pages']['main']
        page[0]['states'] = [{'label': 'Mic on', 'color': '#35D07F'}, {'label': 'Mic off', 'color': '#FF7070'}]
        page[0]['actions'] = []
        page[1]['actions'] = [{'type': 'state', 'button': page[0]['id'], 'state': 1}]
        daemon.push_page = Mock()
        return daemon, page

    def test_state_action_validates_button_and_state(self):
        config = deck.Daemon.load_profiles(ROOT / 'host/profiles.default.json')
        button = config['profiles']['main']['pages']['main'][0]
        for good in ({'type': 'state', 'button': 3, 'state': 1}, {'type': 'state', 'button': 18, 'state': 'next'},
                     {'type': 'state', 'button': 1}):
            button['actions'] = [good]
            deck.validate_config(config)
        for bad in ({'type': 'state'}, {'type': 'state', 'button': 0}, {'type': 'state', 'button': '2'},
                    {'type': 'state', 'button': True}, {'type': 'state', 'button': 2, 'state': 8},
                    {'type': 'state', 'button': 2, 'state': -1}, {'type': 'state', 'button': 2, 'state': 'last'},
                    {'type': 'state', 'button': 2, 'state': 1.5}):
            with self.subTest(bad):
                button['actions'] = [bad]
                with self.assertRaises(ValueError):
                    deck.validate_config(config)

    def test_state_action_sets_another_buttons_state_and_updates_the_panel(self):
        daemon, page = self.toggle_daemon()
        self.assertEqual(daemon.current_buttons()[0]['label'], 'Mic on')
        self.assertTrue(daemon.dispatch_press(page[1]['id']))
        self.assertEqual(daemon.current_buttons()[0]['label'], 'Mic off')
        self.assertEqual(daemon.current_buttons()[0]['color'], '#FF7070')
        daemon.push_page.assert_called()
        page[1]['actions'] = [{'type': 'state', 'button': page[0]['id'], 'state': 0}]
        daemon.dispatch_press(page[1]['id'])
        self.assertEqual(daemon.current_buttons()[0]['label'], 'Mic on')

    def test_state_next_cycles_and_unknown_targets_fail_cleanly(self):
        daemon, page = self.toggle_daemon()
        page[1]['actions'] = [{'type': 'state', 'button': page[0]['id'], 'state': 'next'}]
        for expected in ('Mic off', 'Mic on', 'Mic off'):
            daemon.dispatch_press(page[1]['id'])
            self.assertEqual(daemon.current_buttons()[0]['label'], expected)
        page[1]['actions'] = [{'type': 'state', 'button': page[2]['id'], 'state': 0}]
        self.assertFalse(daemon.dispatch_press(page[1]['id']))
        self.assertIn('no states', daemon.last_action['error'])
        page[1]['actions'] = [{'type': 'state', 'button': 17, 'state': 0}]
        page[:] = [b for b in page if b['id'] != 17]
        self.assertFalse(daemon.dispatch_press(page[1]['id']))
        self.assertIn('does not exist', daemon.last_action['error'])

    def test_state_action_on_its_own_button_replaces_the_automatic_toggle(self):
        daemon, page = self.toggle_daemon()
        page[0]['actions'] = [{'type': 'state', 'button': page[0]['id'], 'state': 0}]
        daemon.button_states[('main', 'main', page[0]['id'])] = 1
        daemon.dispatch_press(page[0]['id'])
        self.assertEqual(daemon.current_buttons()[0]['label'], 'Mic on')
        page[0]['actions'] = []
        daemon.dispatch_press(page[0]['id'])
        self.assertEqual(daemon.current_buttons()[0]['label'], 'Mic off')

    def test_variables_render_empty_until_set_and_set_by_api_jobs(self):
        daemon = self.daemon()
        daemon.push_page = Mock()
        self.assertEqual(daemon.substitute('Claude $(var:claude)'), 'Claude ')
        daemon.handle_job(('var', 'claude', 'working'))
        self.assertEqual(daemon.substitute('Claude $(var:claude)'), 'Claude working')
        daemon.push_page.assert_called()

    def test_status_variable_colors_the_button(self):
        daemon = self.daemon()
        button = daemon.config['profiles']['main']['pages']['main'][0]
        button['status'] = {'var': 'claude', 'colors': {'working': '#FFB74D', 'waiting': '#FF7070'}}
        deck.validate_config(daemon.config)
        base = daemon.current_buttons()[0]['color']
        daemon.custom_vars['claude'] = 'waiting'
        self.assertEqual(daemon.current_buttons()[0]['color'], '#FF7070')
        daemon.custom_vars['claude'] = 'other'
        self.assertEqual(daemon.current_buttons()[0]['color'], base)
        for bad in ({'var': ''}, {'var': 'x', 'colors': {'a': 'red'}}, {'var': 'x', 'colors': 'no'}, 'x'):
            with self.subTest(bad):
                button['status'] = bad
                with self.assertRaises(ValueError):
                    deck.validate_config(daemon.config)

    def test_api_jobs_press_state_feedback_and_dim(self):
        daemon, page = self.toggle_daemon()
        page[1]['actions'] = [{'type': 'delay', 'ms': 0}]
        daemon.dimmed = True
        daemon.handle_job(('api-press', page[1]['id']))
        self.assertFalse(daemon.dimmed)
        self.assertEqual(daemon.last_action['label'], page[1]['label'])
        daemon.handle_job(('state', page[0]['id'], 'next'))
        self.assertEqual(daemon.current_buttons()[0]['label'], 'Mic off')
        daemon.handle_job(('feedback', 3, False))
        daemon.panel.feedback.assert_called_with(3, False)
        daemon.handle_job(('dim',))
        self.assertTrue(daemon.dimmed)

    def api_server(self):
        from control_api import ControlServer
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        daemon = self.daemon()
        daemon.submit = Mock()
        daemon.connection_failed = threading.Event()
        info = Path(directory.name) / 'api.json'
        server = ControlServer(daemon, info)
        server.start()
        self.addCleanup(server.stop)
        return daemon, server, info

    def api_call(self, info, method, path, data=None, headers=None):
        import urllib.error
        import urllib.request
        saved = json.loads(info.read_text(encoding='utf-8'))
        request = urllib.request.Request(f'http://127.0.0.1:{saved["port"]}{path}', method=method,
            data=None if data is None else json.dumps(data).encode(),
            headers=dict({'X-Deck-Token': saved['token'], 'Content-Type': 'application/json'}, **(headers or {})))
        try:
            with urllib.request.urlopen(request, timeout=3) as reply:
                return reply.status, json.loads(reply.read())
        except urllib.error.HTTPError as error:
            with error:
                return error.code, json.loads(error.read())

    def test_control_api_queues_validated_commands_for_the_daemon(self):
        daemon, server, info = self.api_server()
        self.assertEqual(self.api_call(info, 'POST', '/v1/var', {'name': 'claude', 'value': 'working'})[0], 200)
        daemon.submit.assert_called_with(('var', 'claude', 'working'))
        self.api_call(info, 'POST', '/v1/press', {'button': 3})
        daemon.submit.assert_called_with(('api-press', 3))
        self.api_call(info, 'POST', '/v1/state', {'button': 2, 'state': 1})
        daemon.submit.assert_called_with(('state', 2, 1))
        self.api_call(info, 'POST', '/v1/feedback', {'button': 4, 'ok': False})
        daemon.submit.assert_called_with(('feedback', 4, False))
        self.api_call(info, 'POST', '/v1/display', {'action': 'dim'})
        daemon.submit.assert_called_with(('dim',))
        self.api_call(info, 'POST', '/v1/page', {'profile': 'coding', 'page': 'git'})
        daemon.submit.assert_called_with(('wake',), ('profile', 'coding'), ('page', 'git'))

    def test_control_api_rejects_bad_input_and_unauthorised_callers(self):
        daemon, server, info = self.api_server()
        for path, body in (('/v1/var', {'name': 'bad name'}), ('/v1/var', {'name': 'x', 'value': 'v' * 201}),
                           ('/v1/press', {'button': 0}), ('/v1/press', {'button': '3'}),
                           ('/v1/state', {'button': 2, 'state': 8}), ('/v1/feedback', {'button': 2, 'ok': 'yes'}),
                           ('/v1/display', {'action': 'explode'}), ('/v1/page', {'profile': 'nope'}),
                           ('/v1/page', {'page': 'nope'}), ('/v1/nothing', {})):
            with self.subTest(path=path, body=body):
                self.assertIn(self.api_call(info, 'POST', path, body)[0], (400, 404))
        daemon.submit.assert_not_called()
        self.assertEqual(self.api_call(info, 'POST', '/v1/press', {'button': 1}, {'X-Deck-Token': 'wrong'})[0], 401)
        self.assertEqual(self.api_call(info, 'POST', '/v1/press', {'button': 1}, {'Origin': 'http://evil.example'})[0], 403)
        self.assertEqual(self.api_call(info, 'POST', '/v1/press', {'button': 1}, {'Host': 'evil.example'})[0], 403)
        daemon.submit.assert_not_called()

    def test_control_api_reports_state_and_removes_its_info_file_on_stop(self):
        daemon, server, info = self.api_server()
        daemon.custom_vars['claude'] = 'idle'
        status, state = self.api_call(info, 'GET', '/v1/state')
        self.assertEqual(status, 200)
        self.assertEqual((state['profile'], state['variables']), (daemon.profile, {'claude': 'idle'}))
        server.stop()
        self.assertFalse(info.exists())

    def test_deckctl_talks_to_the_host_and_fails_cleanly_without_one(self):
        import deckctl
        daemon, server, info = self.api_server()
        self.assertEqual(deckctl.main(['var', 'claude', 'waiting'], info), 0)
        daemon.submit.assert_called_with(('var', 'claude', 'waiting'))
        self.assertEqual(deckctl.main(['state', '3', '2'], info), 0)
        daemon.submit.assert_called_with(('state', 3, 1))
        self.assertEqual(deckctl.main(['alert', '5'], info), 0)
        daemon.submit.assert_called_with(('feedback', 5, False))
        self.assertEqual(deckctl.main(['press', '99'], info), 1)
        missing = Path(tempfile.mkdtemp()) / 'none.json'
        self.assertEqual(deckctl.main(['wake'], missing), 1)

    def test_unicode_labels_match_the_firmware_byte_limit(self):
        daemon = self.daemon()
        daemon.config['profiles']['main']['pages']['main'][0]['label'] = 'é' * 20
        label = daemon.current_buttons()[0]['label']
        self.assertEqual(label, 'é' * 12)

    def test_folder_and_back_restore_previous_page(self):
        daemon = self.daemon()
        daemon.panel.push_buttons = Mock()
        daemon.panel.send_line = Mock()
        daemon.switch_page('system', folder=True)
        self.assertEqual((daemon.page, daemon.folder_stack), ('system', ['main']))
        daemon.run_action({'type': 'back'})
        self.assertEqual((daemon.page, daemon.folder_stack), ('main', []))

    def test_pinned_button_overrides_same_slot_on_every_page(self):
        daemon = self.daemon()
        daemon.config['profiles']['main']['pinned'] = [
            {'id': 18, 'label': 'Pinned', 'icon': 'home', 'color': '#35D07F', 'actions': []}]
        daemon.page = 'system'
        button = next(item for item in daemon.current_buttons() if item['id'] == 18)
        self.assertEqual(button['label'], 'Pinned')

    def test_toggle_advances_only_after_success(self):
        daemon = self.daemon()
        button = daemon.config['profiles']['main']['pages']['main'][0]
        button['actions'] = []
        button['states'] = [{'label': 'Off'}, {'label': 'On'}]
        self.assertTrue(daemon.dispatch_press(button['id']))
        self.assertEqual(daemon.current_buttons()[0]['label'], 'On')
        button['actions'] = [{'type': 'shell', 'command': 'synthetic'}]
        with patch.object(deck.subprocess, 'run', return_value=types.SimpleNamespace(returncode=1)):
            self.assertFalse(daemon.dispatch_press(button['id']))
        self.assertEqual(daemon.current_buttons()[0]['label'], 'On')

    def test_custom_image_is_normalized_and_content_addressed(self):
        import base64
        from PIL import Image
        with tempfile.TemporaryDirectory() as directory:
            profile = Path(directory) / 'profiles.json'
            output = BytesIO()
            Image.new('RGBA', (180, 90), '#35D07F').save(output, format='PNG')
            result = Assets(profile).import_image(base64.b64encode(output.getvalue()).decode())
            self.assertRegex(result['id'], r'^im:[0-9a-f]{12}$')
            self.assertEqual((result['width'], result['height'], result['frames']), (72, 72, 1))
            self.assertTrue(Assets(profile).read(result['id']).startswith(b'ADI1'))
            # Importing the same picture again (editor and daemon both do) leaves the files alone: the daemon
            # may be sending them, and an in-place rewrite could hand it a half-written image.
            with patch('deck_assets.write_atomic') as write:
                self.assertEqual(Assets(profile).import_image(base64.b64encode(output.getvalue()).decode())['id'], result['id'])
            write.assert_not_called()
            self.assertEqual(sorted(file.suffix for file in (Path(directory) / 'assets').iterdir()), ['.adimg', '.png'])

    def test_invalid_image_has_a_clean_validation_error(self):
        import base64
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaisesRegex(ValueError, 'could not be read'):
                Assets(Path(directory) / 'profiles.json').import_image(
                    base64.b64encode(b'not an image').decode())

    def test_only_png_jpeg_gif_and_webp_reach_a_decoder(self):
        import base64
        from io import BytesIO
        from PIL import Image
        for kind in ('TGA', 'BMP'):  # Pillow can read them, but its other decoders are not exposed to dropped files
            output = BytesIO()
            Image.new('RGB', (8, 8), 'red').save(output, kind)
            with tempfile.TemporaryDirectory() as directory, self.assertRaisesRegex(ValueError, 'could not be read'):
                Assets(Path(directory) / 'profiles.json').import_image(base64.b64encode(output.getvalue()).decode())

    def test_failed_actions_give_negative_feedback(self):
        daemon = self.daemon()
        daemon.run_action = Mock(side_effect=RuntimeError('blocked'))
        self.assertFalse(daemon.dispatch_press(1))
        daemon.panel.feedback.assert_called_with(1, False)
        self.assertEqual(daemon.last_action['label'], 'Explorer')
        self.assertFalse(daemon.last_action['ok'])
        self.assertEqual(daemon.last_action['error'], 'blocked')

    def test_failed_shell_reports_exit_status(self):
        daemon = self.daemon()
        with patch.object(deck.subprocess, 'run', return_value=types.SimpleNamespace(returncode=7)):
            with self.assertRaises(RuntimeError):
                daemon.run_action({'type': 'shell', 'command': 'synthetic'})

    def test_recursive_press_is_bounded(self):
        daemon = self.daemon()
        daemon.config['profiles']['main']['pages']['main'][0]['actions'] = [{'type': 'press', 'id': 1}]
        self.assertFalse(daemon.dispatch_press(1))
        self.assertEqual(daemon.active_press, [])

    def test_triggers_of_same_type_do_not_fire_each_other(self):
        daemon = self.daemon()
        daemon.config['triggers'] = [
            {'when': {'type': 'interval', 'seconds': 5}, 'actions': [{'type': 'text', 'text': 'a'}]},
            {'when': {'type': 'interval', 'seconds': 10}, 'actions': [{'type': 'text', 'text': 'b'}]}]
        daemon.trigger_tick(100)
        self.assertTrue(daemon.jobs.empty())
        daemon.trigger_tick(105)
        self.assertEqual(daemon.jobs.get_nowait()[1][0]['text'], 'a')
        self.assertTrue(daemon.jobs.empty())

    def test_variable_trigger_with_a_value_runs_only_when_it_becomes_that_value(self):
        daemon = self.daemon()
        daemon.config['triggers'] = [
            {'when': {'type': 'variable', 'name': 'claude', 'value': 'waiting'}, 'actions': [{'type': 'text', 'text': 'w'}]},
            {'when': {'type': 'variable', 'name': 'claude'}, 'actions': [{'type': 'text', 'text': 'any'}]}]
        ran = lambda: [daemon.jobs.get_nowait()[1][0]['text'] for _ in range(daemon.jobs.qsize())]
        for value, expected in (('working', ['any']), ('waiting', ['w', 'any']), ('waiting', []), ('idle', ['any']), ('waiting', ['w', 'any'])):
            daemon.custom_vars['claude'] = value
            daemon.trigger_tick(1)
            self.assertEqual(ran(), expected, value)

    def test_focus_returns_to_default(self):
        daemon = self.daemon()
        daemon.args.no_focus = False
        daemon.profile = 'coding'
        daemon.auto_profile = 'coding'
        context = {'exe': 'notepad.exe', 'title': 'Notepad', 'processes': ['notepad.exe']}
        with patch.object(deck, 'foreground_context', return_value=context):
            daemon.focus_tick()
        self.assertEqual(daemon.jobs.get_nowait(), ('focus-profile', 'main'))

    def test_long_press_runs_the_hold_actions_and_is_flagged_in_the_layout(self):
        daemon = self.daemon()
        button = next(b for b in daemon.config['profiles']['main']['pages']['main'] if b['id'] == 1)
        button['hold_actions'] = [{'type': 'set', 'variable': 'held', 'value': 'yes'}]
        button['actions'] = [{'type': 'set', 'variable': 'held', 'value': 'no'}]
        daemon.profile, daemon.page = 'main', 'main'
        self.assertTrue(next(b for b in daemon.current_buttons() if b['id'] == 1)['hold'])
        self.assertNotIn('hold', next(b for b in daemon.current_buttons() if b['id'] == 2))
        daemon.handle_job(('press', 1, None, True))
        self.assertEqual(daemon.custom_vars['held'], 'yes')
        daemon.handle_job(('press', 1, None, False))
        self.assertEqual(daemon.custom_vars['held'], 'no')
        button['hold_actions'] = [{'type': 'hotkey', 'keys': 'not-a-key'}]
        with self.assertRaises(ValueError):
            deck.validate_config(daemon.config)

    def test_focus_returns_to_the_profile_that_was_active_before_the_auto_switch(self):
        daemon = self.daemon()
        daemon.args.no_focus = False
        daemon.profile = 'Codex'
        daemon.config['profiles']['coding']['match'] = ['code.exe']
        with patch.object(deck, 'foreground_context',
                          return_value={'exe': 'code.exe', 'title': 'Editor', 'processes': ['code.exe']}):
            daemon.focus_tick()
        self.assertEqual(daemon.jobs.get_nowait(), ('focus-profile', 'coding'))
        daemon.profile = 'coding'
        with patch.object(deck, 'foreground_context',
                          return_value={'exe': 'notepad.exe', 'title': 'Notepad', 'processes': ['notepad.exe']}):
            daemon.focus_tick()
        self.assertEqual(daemon.jobs.get_nowait(), ('focus-profile', 'Codex'))
        self.assertIsNone(daemon.profile_before_auto)

    def test_manual_home_is_not_immediately_overridden_by_focus(self):
        daemon = self.daemon()
        daemon.args.no_focus = False
        daemon.foreground = {'exe': 'chatgpt.exe', 'title': 'ChatGPT', 'processes': ['chatgpt.exe']}
        daemon.config['profiles']['coding']['match'] = ['chatgpt.exe']
        daemon.switch_profile('main')
        with patch.object(deck, 'foreground_context', return_value=daemon.foreground):
            daemon.focus_tick()
        self.assertTrue(daemon.jobs.empty())
        changed = {'exe': 'notepad.exe', 'title': 'Notepad', 'processes': ['notepad.exe']}
        with patch.object(deck, 'foreground_context', return_value=changed):
            daemon.focus_tick()
        self.assertEqual(daemon.manual_focus_exe, '')

    def test_home_returns_to_default_first_page(self):
        daemon = self.daemon()
        daemon.profile = 'main'
        daemon.page = 'system'
        daemon.folder_stack = ['main']
        daemon.run_action({'type': 'home'})
        self.assertEqual((daemon.profile, daemon.page, daemon.folder_stack), ('main', 'main', []))
        daemon.panel.push_buttons.assert_called()

    def test_home_from_another_profile_sends_the_first_page_once(self):
        daemon = self.daemon()
        daemon.switch_profile('coding')
        daemon.panel.reset_mock()
        daemon.run_action({'type': 'home'})
        self.assertEqual((daemon.profile, daemon.page), ('main', 'main'))
        daemon.panel.push_buttons.assert_called_once()

    def test_auto_profile_switching_can_be_disabled(self):
        daemon = self.daemon()
        daemon.args.no_focus = False
        daemon.config['auto_profiles'] = False
        with patch.object(deck, 'foreground_context') as foreground:
            daemon.focus_tick()
        foreground.assert_not_called()
        self.assertTrue(daemon.jobs.empty())

    def test_open_action_focuses_existing_process(self):
        daemon = self.daemon()
        action = {'type': 'open', 'target': 'example.exe', 'process': 'example.exe', 'reuse': True}
        with patch.object(deck, 'IS_WINDOWS', True), \
             patch.object(deck, 'focus_existing_process', return_value=True) as focus, \
             patch.object(deck.os, 'startfile', create=True) as start:
            daemon.run_action(action)
        focus.assert_called_once_with('example.exe')
        start.assert_not_called()

    @windows_only
    def test_open_action_expands_environment_variables_in_paths_only(self):
        daemon = self.daemon()
        with patch.dict(deck.os.environ, {'TESSERA_TEST_SECRET': 'secret123'}), patch.object(deck, 'IS_WINDOWS', True), \
             patch.object(deck.os, 'startfile', create=True) as start:
            daemon.run_action({'type': 'open', 'target': 'https://example.com/?t=%TESSERA_TEST_SECRET%'})
            daemon.run_action({'type': 'open', 'target': r'%TESSERA_TEST_SECRET%\notes.txt'})
        self.assertEqual([call.args[0] for call in start.call_args_list],
                         ['https://example.com/?t=%TESSERA_TEST_SECRET%', r'secret123\notes.txt'])

    def test_terminal_profiles_match_child_process_or_title(self):
        context = {'exe': 'windowsterminal.exe', 'title': 'Claude - prosjekt',
                   'processes': ['windowsterminal.exe', 'openconsole.exe', 'claude.exe']}
        self.assertTrue(deck.matches_foreground('process:claude.exe', context))
        self.assertTrue(deck.matches_foreground('title:claude', context))
        self.assertFalse(deck.matches_foreground('process:codex.exe', context))

    def test_focus_selects_terminal_child_profile(self):
        daemon = self.daemon()
        daemon.args.no_focus = False
        daemon.config['profiles']['coding']['match'] = ['process:claude.exe']
        context = {'exe': 'windowsterminal.exe', 'title': 'Terminal',
                   'processes': ['windowsterminal.exe', 'claude.exe']}
        with patch.object(deck, 'foreground_context', return_value=context):
            daemon.focus_tick()
        self.assertEqual(daemon.jobs.get_nowait(), ('focus-profile', 'coding'))

    def test_agent_status_variables_follow_running_processes(self):
        daemon = self.daemon()
        processes = [types.SimpleNamespace(info={'name': 'claude.exe'}),
                     types.SimpleNamespace(info={'name': 'ZCode.exe'})]
        with patch.object(psutil, 'process_iter', return_value=processes):
            daemon.agent_tick(1)
        self.assertEqual(daemon.agents, {'codex': False, 'claude': True, 'zcode': True})
        self.assertEqual(daemon.substitute('Claude $(agent:claude)'), 'Claude ON')

    def test_invalid_profile_reload_preserves_accepted_config(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'profiles.json'
            original = (ROOT / 'host/profiles.default.json').read_text(encoding='utf-8')
            path.write_text(original, encoding='utf-8')
            daemon = test_daemon(path)
            daemon.log = Mock()
            accepted = copy.deepcopy(daemon.config)
            path.write_text('{', encoding='utf-8')
            daemon.profile_stamp = -1
            daemon.reload_profiles()
            self.assertEqual(accepted, daemon.config)

    def test_saving_only_display_settings_keeps_toggle_states_folder_and_dimming(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'profiles.json'
            config = json.loads((ROOT / 'host/profiles.default.json').read_text(encoding='utf-8'))
            path.write_text(json.dumps(config), encoding='utf-8')
            daemon = test_daemon(path)
            daemon.log = Mock()
            daemon.enqueue = Mock()
            daemon.button_states[('main', 'main', 1)] = 1
            daemon.folder_stack.append('main')
            daemon.dimmed = True
            config['display'] = dict(config.get('display', {}), brightness=40)  # the panel's brightness slider
            path.write_text(json.dumps(config), encoding='utf-8')
            daemon.profile_stamp = -1
            daemon.reload_profiles()
            self.assertEqual(daemon.button_states, {('main', 'main', 1): 1})
            self.assertEqual(daemon.folder_stack, ['main'])
            self.assertNotIn(call(('brightness',)), daemon.enqueue.call_args_list)
            config['profiles']['main']['pages']['main'][0]['label'] = 'Changed'
            path.write_text(json.dumps(config), encoding='utf-8')
            daemon.profile_stamp = -1
            daemon.reload_profiles()
            self.assertEqual((daemon.button_states, daemon.folder_stack), ({}, []))

    def test_missing_profile_file_does_not_stop_daemon(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'profiles.json'
            path.write_text((ROOT / 'host/profiles.default.json').read_text(encoding='utf-8'), encoding='utf-8')
            daemon = test_daemon(path)
            daemon.log = Mock()
            accepted = copy.deepcopy(daemon.config)
            path.unlink()
            daemon.reload_profiles()
            self.assertEqual(accepted, daemon.config)
            daemon.log.assert_called_once()

    def test_windows_venv_launcher_tracks_actual_interpreter(self):
        with tempfile.TemporaryDirectory() as directory:
            controller = Controller()
            controller.pid_path = Path(directory) / 'owner.json'
            controller.pid_path.write_text(json.dumps({'pid': 10, 'created': 100}))
            launcher = Mock()
            launcher.pid = 10
            launcher.create_time.return_value = 100
            launcher.cmdline.return_value = ['python.exe', str(ROOT / 'host/tesserad.py')]
            actual = Mock()
            actual.pid = 11
            actual.create_time.return_value = 101
            actual.cmdline.return_value = launcher.cmdline.return_value
            launcher.children.return_value = [actual]
            with patch('deck_control.psutil.Process', return_value=launcher):
                self.assertEqual(controller.processes(), [actual])
            self.assertEqual(json.loads(controller.pid_path.read_text())['pid'], 11)

    def test_reused_process_id_is_not_owned(self):
        with tempfile.TemporaryDirectory() as directory:
            controller = Controller()
            controller.pid_path = Path(directory) / 'owner.json'
            controller.pid_path.write_text(json.dumps({'pid': 10, 'created': 100}))
            controller.runtime_path = Path(directory) / 'runtime.json'  # no host reports from here
            process = Mock()
            process.create_time.return_value = 200
            process.cmdline.return_value = ['python.exe', str(ROOT / 'host/tesserad.py')]
            with patch('deck_control.psutil.Process', return_value=process):
                self.assertEqual(controller.processes(), [])

    def test_a_host_started_elsewhere_is_adopted_from_its_runtime_file(self):
        with tempfile.TemporaryDirectory() as directory:
            controller = Controller()
            controller.pid_path = Path(directory) / 'owner.json'
            controller.runtime_path = Path(directory) / 'runtime.json'
            controller.runtime_path.write_text(json.dumps({'pid': 42}))
            process = Mock()
            process.pid = 42
            process.create_time.return_value = 300
            process.cmdline.return_value = ['python.exe', str(ROOT / 'host/tesserad.py')]
            with patch('deck_control.psutil.Process', return_value=process):
                self.assertEqual(controller.processes(), [process])
            self.assertEqual(json.loads(controller.pid_path.read_text()), {'pid': 42, 'created': 300})
            process.cmdline.return_value = ['python.exe', 'something_else.py']  # the pid now belongs to another program
            controller.pid_path.unlink()
            with patch('deck_control.psutil.Process', return_value=process):
                self.assertEqual(controller.processes(), [])

    def test_controller_reports_confirmed_device_context(self):
        with tempfile.TemporaryDirectory() as directory:
            controller = Controller()
            controller.runtime_path = Path(directory) / 'runtime.json'
            process = Mock(pid=77)
            controller.processes = Mock(return_value=[process])
            controller.runtime_path.write_text(json.dumps({
                'pid': 77, 'updated': __import__('time').time(), 'connected': True,
                'port': 'COM4', 'profile': 'main', 'page': 'apps', 'buttons': 8, 'board': 'tessera-p4-crowpanel7',
                'last_action': {'id': 2, 'label': 'ChatGPT', 'ok': True, 'at': 10},
                'vars': {'claude': 'working'}, 'stats': {'cpu_temp': '58'}}))
            status = controller.status()
            self.assertTrue(status['device']['connected'])
            self.assertEqual((status['device']['profile'], status['device']['page']), ('main', 'apps'))
            self.assertEqual(status['device']['last_action']['label'], 'ChatGPT')
            self.assertEqual(status['device']['board'], 'tessera-p4-crowpanel7')  # the update check picks its package
            # The editor previews $(var:…) and $(stat:…) labels with these values.
            self.assertEqual((status['vars'], status['stats']), ({'claude': 'working'}, {'cpu_temp': '58'}))

    def test_controller_rejects_stale_runtime_status(self):
        with tempfile.TemporaryDirectory() as directory:
            controller = Controller()
            controller.runtime_path = Path(directory) / 'runtime.json'
            controller.processes = Mock(return_value=[Mock(pid=77)])
            controller.runtime_path.write_text(json.dumps({'pid': 77, 'updated': 1, 'connected': True}))
            self.assertFalse(controller.status()['device']['connected'])

    @windows_only
    def test_windows_autostart_script_can_be_enabled_and_removed(self):
        with tempfile.TemporaryDirectory() as directory:
            fake_root = Path(directory) / 'program'
            (fake_root / 'host/.venv/Scripts').mkdir(parents=True)
            (fake_root / 'host/.venv/Scripts/pythonw.exe').write_bytes(b'')  # a fresh checkout has no virtual environment
            with patch('deck_control.os.name', 'nt'), patch('deck_control.ROOT', fake_root):
                path = set_autostart(True, directory)
                self.assertTrue(autostart_enabled(directory))
                self.assertIn('tessera_tray.py', path.read_text(encoding='utf-16'))
                self.assertIn('pythonw.exe', path.read_text(encoding='utf-16'))
                set_autostart(False, directory)
                self.assertFalse(autostart_enabled(directory))

    @windows_only
    def test_start_with_windows_counts_only_a_script_for_this_folder(self):
        with tempfile.TemporaryDirectory() as directory:
            old_root, new_root = Path(directory) / 'tessera-1.0', Path(directory) / 'tessera-1.1'
            for root in (old_root, new_root):
                (root / 'host/.venv/Scripts').mkdir(parents=True)
                (root / 'host/.venv/Scripts/pythonw.exe').write_bytes(b'')
            with patch('deck_control.os.name', 'nt'):
                with patch('deck_control.ROOT', old_root):
                    path = set_autostart(True, directory)
                    self.assertTrue(autostart_enabled(directory))
                with patch('deck_control.ROOT', new_root):
                    self.assertFalse(autostart_enabled(directory))  # the tray menu does not tick a script for the old folder
                    set_autostart(True, directory)
                    self.assertTrue(autostart_enabled(directory))
                    self.assertNotIn(str(old_root / 'host'), path.read_text(encoding='utf-16'))
                    path.write_bytes(b'\x00')  # an unreadable script counts as off
                    self.assertFalse(autostart_enabled(directory))
                    path.write_text(f'{startup_line()}\r\n', encoding='utf-8')  # as 0.5-0.6.1 wrote it
                    self.assertTrue(autostart_enabled(directory))

    @windows_only
    def test_the_tray_asks_before_start_with_windows_moves_from_another_folder(self):
        try:
            import tessera_tray
        except ImportError:
            self.skipTest('pystray is not installed')
        from host_support import tray_app
        with tempfile.TemporaryDirectory() as directory:
            first_run = Path(directory) / 'tray-first-run.local.json'
            script = Path(directory) / 'Microsoft/Windows/Start Menu/Programs/Startup/Tessera.vbs'
            script.parent.mkdir(parents=True)
            script.write_text('a copy in another folder', encoding='utf-16')
            box = Mock(return_value=7)  # IDNO
            app = tray_app(Mock())
            with patch.object(tessera_tray, 'FIRST_RUN_PATH', first_run), patch('deck_control.os.name', 'nt'), \
                    patch.dict('os.environ', {'APPDATA': directory}), \
                    patch('ctypes.windll', Mock(user32=Mock(MessageBoxW=box)), create=True), \
                    patch.object(tessera_tray, 'set_autostart') as set_autostart:
                app.ask_about_autostart()
                app.ask_about_autostart()  # once per folder
                self.assertEqual(box.call_count, 1)
                self.assertIn('another folder. Start this copy instead?', box.call_args.args[1])
                self.assertIn(str(tessera_tray.ROOT), box.call_args.args[1])
                set_autostart.assert_not_called()
                self.assertEqual(script.read_text(encoding='utf-16'), 'a copy in another folder')
                first_run.write_text('{"asked": "autostart"}', encoding='utf-8')  # copied from the folder before
                app.ask_about_autostart()
                self.assertEqual(box.call_count, 2)
                first_run.unlink()
                box.return_value = 6  # IDYES
                app.ask_about_autostart()
                set_autostart.assert_called_once_with(True)
                first_run.unlink()
                script.unlink()
                app.ask_about_autostart()
                self.assertTrue(box.call_args.args[1].startswith('Start Tessera when you sign in to Windows?'))

    def test_the_tray_start_leaves_start_with_windows_alone(self):
        try:
            import tessera_tray
        except ImportError:
            self.skipTest('pystray is not installed')
        from host_support import tray_app
        app = tray_app(Mock())
        app.start_host, app.icon = Mock(), Mock()
        app.stop.set()  # the status poll ends at once
        with patch.object(tessera_tray, 'set_autostart') as set_autostart:
            app.run()
        set_autostart.assert_not_called()
        app.start_host.assert_called_once_with()
        app.icon.run.assert_called_once_with()

    def test_trigger_targets_must_be_text_so_a_bad_one_cannot_stop_the_host(self):
        config = json.loads((ROOT / 'host/profiles.default.json').read_text(encoding='utf-8'))
        for when in ({'type': 'file', 'path': ['x']}, {'type': 'file', 'path': 5},
                     {'type': 'file', 'path': 'a' + chr(0) + 'b'}, {'type': 'variable', 'name': ['x']},
                     {'type': 'variable', 'name': 'x', 'value': 1}):
            config['triggers'] = [{'when': when, 'actions': []}]
            with self.assertRaises(ValueError, msg=when):
                deck.validate_config(config)
        config['triggers'] = [{'when': {'type': 'variable', 'name': 'claude', 'value': 'waiting'}, 'actions': [{'type': 'back'}]}]
        deck.validate_config(config)  # a value that is text is fine

    def test_saving_the_configuration_does_not_rerun_a_daily_trigger(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'profiles.json'
            config = json.loads((ROOT / 'host/profiles.default.json').read_text(encoding='utf-8'))
            config['triggers'] = [{'when': {'type': 'daily', 'at': '09:00'}, 'actions': [{'type': 'back'}]}]
            path.write_text(json.dumps(config), encoding='utf-8')
            clock, day = ['08:59'], ['2026-11-13']
            fake_time = types.SimpleNamespace(time=time.time,  # only the trigger code sees this clock
                                        strftime=lambda pattern: day[0] if pattern == '%Y-%m-%d' else clock[0])
            with patch('daemon_ticks.time', fake_time):
                daemon = test_daemon(path)
                daemon.log = Mock()
                daemon.trigger_tick(1)
                self.assertTrue(daemon.jobs.empty(), 'not yet')
                clock[0] = '09:00'
                daemon.trigger_tick(2)
                self.assertEqual(daemon.jobs.get_nowait()[0], 'actions')
                config['display'] = {'brightness': 50}  # an unrelated change
                path.write_text(json.dumps(config), encoding='utf-8')
                daemon.profile_stamp = 0
                daemon.reload_profiles()
                while not daemon.jobs.empty():
                    daemon.jobs.get_nowait()
                daemon.trigger_tick(3)
                self.assertTrue(daemon.jobs.empty(), 'the trigger already ran today')
                clock[0] = '10:00'
                restarted = test_daemon(path)
                restarted.log = Mock()
                restarted.trigger_tick(4)
                restarted.trigger_tick(5)
                self.assertTrue(restarted.jobs.empty(), 'a host started after 09:00 does not run it again')
                day[0] = '2026-11-14'  # the PC was off at 09:00 and starts at 10:00
                late = test_daemon(path)
                late.log = Mock()
                late.trigger_tick(6)
                self.assertEqual(late.jobs.get_nowait()[0], 'actions', 'a missed daily run happens once')
                again = test_daemon(path)
                again.log = Mock()
                again.trigger_tick(7)
                self.assertTrue(again.jobs.empty(), 'and not again on the next restart')

    def test_moving_or_removing_a_trigger_does_not_rerun_the_others(self):
        """The editor's Automatic actions dialog moves and removes rules; a rule keeps its state wherever it ends up."""
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'profiles.json'
            config = json.loads((ROOT / 'host/profiles.default.json').read_text(encoding='utf-8'))
            other = {'when': {'type': 'variable', 'name': 'other'}, 'actions': [{'type': 'text', 'text': 'other'}]}
            waiting = {'when': {'type': 'variable', 'name': 'claude', 'value': 'waiting'}, 'actions': [{'type': 'text', 'text': 'w'}]}
            config['triggers'] = [other, waiting]
            path.write_text(json.dumps(config), encoding='utf-8')
            daemon = test_daemon(path)
            daemon.log = Mock()
            daemon.custom_vars['claude'] = 'waiting'
            daemon.trigger_tick(1)
            self.assertEqual(daemon.jobs.get_nowait()[1][0]['text'], 'w')
            for triggers in ([waiting, other], [waiting]):
                config['triggers'] = triggers
                path.write_text(json.dumps(config), encoding='utf-8')
                daemon.profile_stamp = 0
                daemon.reload_profiles()
                while not daemon.jobs.empty():
                    job = daemon.jobs.get_nowait()
                    self.assertNotEqual(job[0], 'actions', job)
                daemon.trigger_tick(2)
                self.assertTrue(daemon.jobs.empty(), triggers)

    def test_a_daily_run_a_full_queue_dropped_is_tried_again(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'profiles.json'
            config = json.loads((ROOT / 'host/profiles.default.json').read_text(encoding='utf-8'))
            config['triggers'] = [{'when': {'type': 'daily', 'at': '08:30'}, 'actions': [{'type': 'back'}]}]
            path.write_text(json.dumps(config), encoding='utf-8')
            clock = ['08:29']
            fake_time = types.SimpleNamespace(time=time.time,
                                              strftime=lambda pattern: '2026-11-16' if pattern == '%Y-%m-%d' else clock[0])
            with patch('daemon_ticks.time', fake_time):
                daemon = test_daemon(path)
                daemon.log = Mock()
                daemon.trigger_tick(1)
                clock[0] = '08:30'
                with patch.object(daemon, 'submit', side_effect=deck.Busy('The host is busy: the action queue is full')):
                    daemon.trigger_tick(2)
                self.assertNotIn('0:08:30', daemon.daily_runs(), 'a dropped run is not saved as done')
                daemon.trigger_tick(3)
                self.assertEqual(daemon.jobs.get_nowait()[0], 'actions')
                daemon.trigger_tick(4)
                self.assertTrue(daemon.jobs.empty(), 'and it runs once')
                self.assertEqual(daemon.daily_runs()['0:08:30'], '2026-11-16')

    def test_a_file_trigger_fires_when_its_file_first_appears(self):
        with tempfile.TemporaryDirectory() as directory:
            created, existing = Path(directory) / 'out.txt', Path(directory) / 'old.txt'
            existing.write_text('here before the host', encoding='utf-8')
            daemon = self.daemon()
            daemon.config['triggers'] = [{'when': {'type': 'file', 'path': str(name)}, 'actions': [{'type': 'text', 'text': name.name}]}
                                         for name in (created, existing)]
            daemon.trigger_tick(1)
            daemon.trigger_tick(2)
            self.assertTrue(daemon.jobs.empty())
            created.write_text('built', encoding='utf-8')
            daemon.trigger_tick(3)
            self.assertEqual(daemon.jobs.get_nowait()[1][0]['text'], 'out.txt')
            daemon.trigger_tick(4)
            self.assertTrue(daemon.jobs.empty())

    def test_a_save_whose_first_read_fails_is_read_again(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'profiles.json'
            config = json.loads((ROOT / 'host/profiles.default.json').read_text(encoding='utf-8'))
            path.write_text(json.dumps(config), encoding='utf-8')
            daemon = test_daemon(path)
            daemon.log = Mock()
            config['profiles']['main']['pages']['main'][0]['label'] = 'Saved'
            path.write_text(json.dumps(config), encoding='utf-8')
            daemon.profile_stamp = -1
            load = daemon.load_profiles
            daemon.load_profiles = Mock(side_effect=PermissionError(13, 'The file is in use'))  # a scanner has it open
            daemon.reload_profiles()
            daemon.load_profiles = load
            daemon.reload_profiles()
            self.assertEqual(daemon.config['profiles']['main']['pages']['main'][0]['label'], 'Saved')

    def test_startup_triggers_run_without_a_panel(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'profiles.json'
            path.write_text((ROOT / 'host/profiles.default.json').read_text(encoding='utf-8'), encoding='utf-8')
            daemon = test_daemon(path)
            daemon.log, daemon.pc.start, daemon.pc.stop = Mock(), Mock(), Mock()
            daemon.agent_scan_at = daemon.stats_scan_at = float('inf')
            daemon.open_panel = Mock(side_effect=OSError('No USB port found'))
            fired = []

            def fire(when):
                fired.append(when)
                daemon.stop.set()
            daemon.fire_trigger = fire
            timer = threading.Timer(5, daemon.stop.set)  # the loop would otherwise wait for a panel
            timer.start()
            self.addCleanup(timer.cancel)
            # the host's own files (stop and command) are looked for in the temporary folder
            with patch.object(deck, '__file__', str(Path(directory) / 'tesserad.py')), \
                    patch.object(deck, 'ControlServer'), \
                    patch.object(deck, 'PluginManager', return_value=Mock(**{'status.return_value': []})):
                daemon.run()
            self.assertEqual(fired, [{'type': 'startup'}])

    def test_a_command_file_held_open_by_a_scanner_waits_for_the_next_second(self):
        with tempfile.TemporaryDirectory() as directory:
            daemon = self.daemon()
            command = Path(directory) / 'deck-command.local.json'
            command.write_text(json.dumps({'profile': 'main', 'page': 'status'}), encoding='utf-8')
            with patch.object(deck.os, 'replace', side_effect=PermissionError(13, 'The file is in use')):
                daemon.take_command(command)  # the host goes on
            self.assertTrue(command.exists(), 'kept for the next try')
            self.assertTrue(daemon.jobs.empty())
            daemon.take_command(command)
            self.assertEqual([daemon.jobs.get_nowait() for _ in range(2)], [('wake',), ('show', 'main', 'status')])
            self.assertEqual(list(Path(directory).iterdir()), [])
            command.write_text('{', encoding='utf-8')
            daemon.take_command(command)
            self.assertTrue(daemon.jobs.empty(), 'an unreadable command is dropped')
            self.assertEqual(list(Path(directory).iterdir()), [])

    def test_a_lone_surrogate_from_the_api_cannot_stop_the_runtime_file(self):
        """Text a script cut in the middle of an emoji: the runtime file and the labels keep working."""
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'profiles.json'
            config = json.loads((ROOT / 'host/profiles.default.json').read_text(encoding='utf-8'))
            config['profiles']['main']['pages']['main'][0]['label'] = 'Now $(var:plugin.np)'
            path.write_text(json.dumps(config), encoding='utf-8')
            daemon = test_daemon(path)
            daemon.panel, daemon.log = Mock(), Mock()
            daemon.profile, daemon.page = 'main', 'main'
            daemon.handle_job(('var', 'plugin.np', 'ab\udc00'))
            daemon.publish_runtime(True, force=True)
            self.assertEqual(json.loads(daemon.runtime_path.read_text(encoding='utf-8'))['vars']['plugin.np'], 'ab?')
            self.assertEqual(daemon.current_buttons()[0]['label'], 'Now ab?')

    def test_a_profile_picked_through_the_api_is_not_undone_by_the_focus_rules(self):
        daemon = self.daemon()
        daemon.args.no_focus = False
        daemon.config['profiles']['coding']['match'] = ['code.exe']
        vscode = {'exe': 'code.exe', 'title': 'Editor', 'processes': ['code.exe']}
        with patch.object(deck, 'foreground_context', return_value=vscode):
            daemon.focus_tick()
            daemon.handle_job(daemon.jobs.get_nowait())
            self.assertEqual(daemon.profile, 'coding')
            for job in (('profile', 'main'), ('page', 'status')):  # deckctl page main status
                daemon.handle_job(job)
            daemon.focus_tick()
        self.assertTrue(daemon.jobs.empty())
        self.assertEqual((daemon.profile, daemon.page), ('main', 'status'))

    def test_a_slow_trigger_runs_beside_the_key_queue_and_never_twice_at_once(self):
        daemon = self.daemon()
        started, release = threading.Event(), threading.Event()

        def run_action(action):
            started.set()
            release.wait(5)
        daemon.run_action = run_action
        actions = [{'type': 'delay', 'ms': 1}]
        daemon.handle_job(('actions', actions))  # returns at once: the wait happens on the slow lane
        self.assertTrue(started.wait(5))
        daemon.handle_job(('actions', actions))
        self.assertIn('skipped', daemon.log.call_args[0][0])
        release.set()
        for _ in range(100):
            if not daemon.slow_running:
                break
            time.sleep(.02)
        self.assertFalse(daemon.slow_running)

    def test_without_a_panel_a_page_change_is_remembered_instead_of_failing(self):
        daemon = self.daemon()
        daemon.panel = None
        daemon.last_push = 'old'
        daemon.push_page(force=True)  # triggers, timers and profile switches keep working while unplugged
        self.assertIsNone(daemon.last_push, 'the page is sent in full when a panel connects')

    def test_focusing_a_maximized_window_does_not_shrink_it(self):
        user32 = Mock()
        user32.IsIconic.return_value = False  # maximized or normal: SW_RESTORE would un-maximize it
        user32.GetForegroundWindow.return_value = 7  # Windows let it through
        win_input.bring_to_front(user32, 7)
        user32.ShowWindow.assert_not_called()
        user32.SetForegroundWindow.assert_called_once_with(7)
        user32.IsIconic.return_value = True  # minimized: restore it first
        win_input.bring_to_front(user32, 7)
        user32.ShowWindow.assert_called_once_with(7, 9)

    def test_a_refused_focus_is_retried_instead_of_leaving_the_taskbar_flashing(self):
        user32 = Mock()
        user32.IsIconic.return_value = False
        user32.GetForegroundWindow.return_value = 3  # another window stays in front: Windows refused
        user32.GetWindowThreadProcessId.return_value = 55
        win_input.bring_to_front(user32, 7)
        user32.BringWindowToTop.assert_called_once_with(7)
        self.assertEqual(user32.AttachThreadInput.call_args_list[0].args[1:], (55, True))
        self.assertEqual(user32.AttachThreadInput.call_args_list[-1].args[1:], (55, False), 'the threads are detached again')
        self.assertEqual([call.args[0] for call in user32.keybd_event.call_args_list], [0x12, 0x12], 'Alt is pressed and released')


if __name__ == '__main__':
    unittest.main()
