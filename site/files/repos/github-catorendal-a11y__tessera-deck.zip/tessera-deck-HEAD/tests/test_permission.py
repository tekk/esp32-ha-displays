"""A tool's permission prompt answered on the panel: only a touch allows, and everything unclear falls back."""
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import io
import json
import os
from pathlib import Path
import socket
import sys
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'host'))
import cockpit
import deckctl
import permission
from control_api import ControlServer
from host_support import HostCase


def hook_event(**tool_input):
    return {'hook_event_name': 'PermissionRequest', 'tool_name': 'Bash', 'tool_input': tool_input}


class RequestTextTests(unittest.TestCase):
    def test_a_command_is_shown_as_it_will_run_and_the_description_is_left_out(self):
        self.assertEqual(permission.request_text(hook_event(command='npm test', description='Run the tests')), 'Bash: npm test')

    def test_every_other_argument_is_shown_so_nothing_is_approved_unseen(self):
        text = permission.request_text(hook_event(command='npm test', run_in_background=True))
        self.assertIn('"run_in_background":true', text)
        self.assertIn('"command":"npm test"', text)

    def test_what_cannot_be_shown_in_full_is_refused(self):
        for payload in (hook_event(command='x' * 200), hook_event(command='rm -rf ‮ ~'), hook_event(command='a\nb'),
                        {'hook_event_name': 'PreToolUse', 'tool_name': 'Bash', 'tool_input': {'command': 'ls'}},
                        {'hook_event_name': 'PermissionRequest', 'tool_name': 'Ba sh', 'tool_input': {'command': 'ls'}},
                        'not an object', None):
            with self.assertRaises(ValueError, msg=repr(payload)[:60]):
                permission.request_text(payload)

    def test_only_allow_and_deny_become_hook_output(self):
        self.assertEqual(permission.hook_output('deny')['hookSpecificOutput']['decision'], {'behavior': 'deny'})
        for nothing in (None, 'ask', 'ALLOW', ''):
            with self.assertRaises(ValueError):
                permission.hook_output(nothing)


def no_settle(case):
    patcher = patch.object(permission, 'SETTLE_SECONDS', 0)
    patcher.start()
    case.addCleanup(patcher.stop)


class DeskTests(unittest.TestCase):
    setUp = no_settle

    def ask_in_thread(self, desk, timeout=5.0):
        result = []
        thread = threading.Thread(target=lambda: result.append(desk.ask('claude', 'Bash: ls', lambda: True, timeout)))
        thread.start()
        for _ in range(200):
            if desk.current():
                break
            time.sleep(0.005)
        return thread, result

    def test_the_touch_is_the_answer(self):
        desk = permission.Desk()
        thread, result = self.ask_in_thread(desk)
        self.assertEqual(desk.current(), {'agent': 'claude', 'text': 'Bash: ls'})
        self.assertTrue(desk.answer('claude', 'allow'))
        thread.join(5)
        self.assertEqual(result, ['allow'])
        self.assertIsNone(desk.current())

    def test_nobody_answering_is_no_answer(self):
        desk = permission.Desk()
        self.assertIsNone(desk.ask('claude', 'Bash: ls', lambda: True, timeout=0.05))
        self.assertIsNone(desk.current())
        self.assertFalse(desk.answer('claude', 'allow'), 'a late touch must not answer a later question')

    def test_no_panel_a_second_question_or_a_wrong_button_gives_no_answer(self):
        desk = permission.Desk()
        self.assertIsNone(desk.ask('claude', 'Bash: ls', lambda: False))
        thread, result = self.ask_in_thread(desk)
        self.assertIsNone(desk.ask('claude', 'Bash: rm', lambda: True, timeout=0.05), 'one question at a time')
        self.assertFalse(desk.answer('codex', 'allow'))
        self.assertFalse(desk.answer('claude', 'open'))
        self.assertTrue(desk.answer('claude', 'deny'))
        thread.join(5)
        self.assertEqual(result, ['deny'])

    def test_a_touch_right_after_a_new_question_appears_is_no_answer(self):
        desk = permission.Desk()
        with patch.object(permission, 'SETTLE_SECONDS', 60):
            thread, result = self.ask_in_thread(desk, timeout=0.3)
            self.assertTrue(desk.answer('claude', 'allow'), 'the touch is taken, so it opens nothing else')
            thread.join(5)
        self.assertEqual(result, [None], 'a touch meant for the screen before the question must not allow')


class PanelQuestionTests(HostCase):
    def setUp(self):
        super().setUp()
        no_settle(self)

    def cockpit_daemon(self):
        daemon = self.daemon()
        daemon.device_info = {'protocol': 4}
        return daemon

    def test_an_open_question_is_the_agents_lane_and_brings_its_screen_forward(self):
        daemon = self.cockpit_daemon()
        with patch.object(daemon.permissions, 'current', return_value={'agent': 'claude', 'text': 'Bash: npm test'}):
            daemon.handle_job(('question',))
        sent = [call.args[0] for call in daemon.panel.send_line.call_args_list]
        self.assertIn('AD_VIEW agents', sent)
        # the lanes first: a panel that opened the screen before the question was there went straight back to the keys
        self.assertLess(next(index for index, line in enumerate(sent) if line.startswith('AD_AGENTS ')), sent.index('AD_VIEW agents'))
        lanes = json.loads(next(line for line in sent if line.startswith('AD_AGENTS ')).split(' ', 1)[1])['agents']
        self.assertEqual((lanes[0]['id'], lanes[0]['state'], lanes[0]['text']), ('claude', 'waiting', 'Bash: npm test'))

    def ask_in_thread(self, daemon, text, timeout=permission.WAIT_SECONDS):
        result = []
        thread = threading.Thread(target=lambda: result.append(
            daemon.permissions.ask('claude', text, daemon.panel_takes_questions, timeout)))
        thread.start()
        for _ in range(200):
            if daemon.permissions.current():
                break
            time.sleep(0.005)
        return thread, result

    def touch(self, daemon, do):
        daemon.panel.read_lines.side_effect = [[json.dumps({'type': 'agent', 'id': 'claude', 'do': do})], OSError('unplugged')]
        daemon.reader_loop(daemon.panel)
        daemon.connection_failed.clear()  # the fake unplug ended the reader, not the panel

    def test_allow_on_the_panel_answers_the_question_instead_of_opening_the_window(self):
        daemon = self.cockpit_daemon()
        import daemon_ticks
        thread, result = self.ask_in_thread(daemon, 'Bash: npm test')
        with patch.object(daemon_ticks, 'focus_existing_process') as focus:
            self.touch(daemon, 'allow')
            thread.join(5)
            self.assertEqual(result, ['allow'])
            queued = [daemon.jobs.get_nowait() for _ in range(daemon.jobs.qsize())]
            self.assertNotIn('agent', [job[0] for job in queued], 'answered at the touch: nothing waits in the queue')
        focus.assert_not_called()
        self.assertEqual(daemon.events.since(0, None)[-1]['action'], 'allow')

    def test_a_touch_that_waited_in_the_queue_never_answers_a_later_question(self):
        """Slow typing holds the worker: the Allow meant for an earlier screen must not approve what opened since."""
        daemon = self.cockpit_daemon()
        import daemon_ticks
        self.touch(daemon, 'allow')  # no question is open yet: the touch waits in the queue
        thread, result = self.ask_in_thread(daemon, 'Bash: rm -rf build', timeout=0.3)
        self.assertIsNotNone(daemon.permissions.current())
        with patch.object(daemon_ticks, 'focus_existing_process') as focus:
            daemon.handle_job(daemon.jobs.get_nowait())
        thread.join(5)
        self.assertEqual(result, [None])
        focus.assert_called_once_with('claude.exe')

    def test_an_older_panel_is_never_asked(self):
        daemon = self.daemon()
        daemon.device_info = {'protocol': 3}
        self.assertIsNone(daemon.ask_permission('claude', 'Bash: npm test'))

    def test_the_lane_text_of_a_question_is_not_shortened(self):
        text = 'Bash: ' + 'x' * (permission.MAX_TEXT - 6)
        lanes = json.loads(cockpit.agents_payload({}, {}, {'agent': 'claude', 'text': text}))['agents']
        self.assertEqual(lanes[0]['text'], text)


class HookTests(HostCase):
    def serve(self, decision):
        daemon = self.daemon()
        daemon.ask_permission = lambda agent, text: decision
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        api = ControlServer(daemon, Path(directory.name) / 'deck-api.local.json')
        api.start()
        self.addCleanup(api.stop)
        return api

    def run_hook(self, api, event):
        out = io.StringIO()
        self.assertEqual(deckctl.permission_hook(io.StringIO(json.dumps(event)), api.info_path, out), 0)
        return out.getvalue()

    def test_the_panels_answer_is_printed_the_way_claude_code_expects(self):
        printed = self.run_hook(self.serve('allow'), hook_event(command='npm test'))
        self.assertEqual(json.loads(printed), {'hookSpecificOutput': {'hookEventName': 'PermissionRequest',
                                                                      'decision': {'behavior': 'allow'}}})

    def test_no_answer_an_unshowable_request_or_a_stopped_host_prints_nothing(self):
        self.assertEqual(self.run_hook(self.serve(None), hook_event(command='npm test')), '')
        self.assertEqual(self.run_hook(self.serve('allow'), hook_event(command='x' * 500)), '')
        out = io.StringIO()
        self.assertEqual(deckctl.permission_hook(io.StringIO(json.dumps(hook_event(command='ls'))), Path('missing.json'), out), 0)
        self.assertEqual(out.getvalue(), '')
        self.assertEqual(deckctl.permission_hook(io.StringIO('{broken'), Path('missing.json'), out), 0)

    def write_info(self, port, pid=None):
        directory = tempfile.TemporaryDirectory()
        self.addCleanup(directory.cleanup)
        info = Path(directory.name) / 'deck-api.local.json'
        info.write_text(json.dumps({'pid': os.getpid() if pid is None else pid, 'port': port, 'token': 'stale'}))
        return info

    def test_a_process_that_took_the_port_of_a_crashed_host_cannot_allow(self):
        # Another account binds the port a dead host left in deck-api.local.json and answers "allow" to everything.
        class Squatter(BaseHTTPRequestHandler):
            def log_message(self, *_):
                pass

            def do_POST(self):
                self.rfile.read(int(self.headers.get('Content-Length', 0)))
                raw = b'{"ok": true, "decision": "allow"}'
                self.send_response(200)
                self.send_header('Content-Length', str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)

        squatter = ThreadingHTTPServer(('127.0.0.1', 0), Squatter)
        threading.Thread(target=squatter.serve_forever, daemon=True).start()
        self.addCleanup(squatter.server_close)
        self.addCleanup(squatter.shutdown)
        out = io.StringIO()
        # Even with a pid that does listen there (this test process), the reply lacks the token's proof.
        deckctl.permission_hook(io.StringIO(json.dumps(hook_event(command='rm -rf x'))),
                                self.write_info(squatter.server_port), out)
        self.assertEqual(out.getvalue(), '')

    def test_a_stale_info_file_is_not_trusted(self):
        with socket.socket() as probe:
            probe.bind(('127.0.0.1', 0))
            free = probe.getsockname()[1]
        with self.assertRaises(deckctl.DeckctlError):
            deckctl.load_info(self.write_info(free))  # the recorded process does not listen on that port
        with self.assertRaises(deckctl.DeckctlError):
            deckctl.load_info(self.write_info(free, pid=2 ** 31 - 1))  # no such process

    def test_a_plugin_token_may_not_ask(self):
        api = self.serve('allow')
        token = api.add_grant('demo', ('var', 'vars', 'press'))
        with self.assertRaises(deckctl.DeckctlError):
            deckctl.call({'port': api.server.server_port, 'token': token}, 'POST', '/v1/permission',
                         {'agent': 'claude', 'text': 'Bash: ls'})

    def test_the_settings_block_runs_the_hook_with_a_timeout_longer_than_the_wait(self):
        block = deckctl.hooks_block('claude-permission')['hooks']['PermissionRequest'][0]['hooks'][0]
        self.assertTrue(block['command'].endswith('permission'))
        self.assertGreater(block['timeout'], permission.WAIT_SECONDS)


if __name__ == '__main__':
    unittest.main()
