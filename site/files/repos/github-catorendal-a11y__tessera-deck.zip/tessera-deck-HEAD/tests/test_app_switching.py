"""Switching profiles by the program in front: shell surfaces are ignored, the view you left is restored, Store apps match."""
from pathlib import Path
import sys
import unittest
from unittest.mock import Mock, patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'host'))
import tesserad as deck
import host_support  # noqa: E402
from platform_windows.input import is_neutral_window as windows_neutral_window, real_app_exe as windows_real_app_exe
from platform_marks import windows_only
from system_stats import select_presentmon_fps


def context(exe, title=''):
    return {'exe': exe, 'title': title.lower(), 'processes': [exe]}


class FpsSensorTests(unittest.TestCase):
    def test_only_presentmon_presented_fps_is_used(self):
        readings = [
            {'sensor': 'Monitor', 'label': 'Framerate (Presented)', 'unit': 'FPS', 'value': 60},
            {'sensor': 'PresentMon [game.exe]', 'label': 'Frame Time', 'unit': 'ms', 'value': 8},
            {'sensor': 'PresentMon [game.exe]', 'label': 'Framerate Presented (avg)', 'unit': 'FPS', 'value': 144},
        ]
        self.assertEqual(select_presentmon_fps(readings), 144)
        self.assertIsNone(select_presentmon_fps(readings[:2]))

    def test_missing_fps_is_not_a_zero_gauge(self):
        from system_stats import gauge_state
        self.assertEqual(gauge_state({'key': 'fps', 'max': 240, 'unit': 'fps'}, {}, '#90A4AE')['t'], '--')
        self.assertEqual(gauge_state({'key': 'fps', 'max': 240, 'unit': 'fps'}, {'fps': 144}, '#90A4AE')['t'], '144fps')


class NeutralWindowTests(unittest.TestCase):
    def test_shell_surfaces_and_tessera_itself_are_neutral(self):
        for exe, title in (('searchhost.exe', 'search'), ('startmenuexperiencehost.exe', 'start'),
                           ('shellexperiencehost.exe', 'new notification'), ('lockapp.exe', ''),
                           ('explorer.exe', ''), ('explorer.exe', 'Task Switching'),
                           ('pythonw.exe', 'Tessera · main / main'), ('msedgewebview2.exe', 'Tessera')):
            with self.subTest(exe=exe, title=title):
                self.assertTrue(windows_neutral_window(context(exe, title)))

    def test_real_programs_are_not_neutral(self):
        for exe, title in (('explorer.exe', 'Documents'), ('pythonw.exe', 'my script'), ('chrome.exe', 'Tessera docs'),
                           ('code.exe', '')):
            with self.subTest(exe=exe, title=title):
                self.assertFalse(windows_neutral_window(context(exe, title)))


@windows_only
class StoreAppTests(unittest.TestCase):
    def test_a_frame_host_window_is_the_app_inside_it(self):
        self.assertEqual(windows_real_app_exe('applicationframehost.exe', ['applicationframehost.exe', '', 'calculatorapp.exe']),
                         'calculatorapp.exe')

    def test_a_frame_host_without_a_visible_app_stays_the_frame_host(self):
        self.assertEqual(windows_real_app_exe('applicationframehost.exe', ['applicationframehost.exe']),
                         'applicationframehost.exe')

    def test_other_programs_are_left_alone(self):
        self.assertEqual(windows_real_app_exe('chrome.exe', ['chrome.exe', 'other.exe']), 'chrome.exe')


class SwitchingTests(unittest.TestCase):
    def make_daemon(self):
        daemon = host_support.test_daemon(port='TEST', no_focus=False)
        daemon.panel, daemon.log, daemon.publish_runtime = Mock(), Mock(), Mock()
        daemon.panel.push_buttons = Mock()
        daemon.config['profiles']['coding']['match'] = ['code.exe']
        return daemon

    def tick(self, daemon, shown):
        with patch.object(deck, 'foreground_context', return_value=shown):
            daemon.focus_tick()
        while not daemon.jobs.empty():
            daemon.handle_job(daemon.jobs.get_nowait())

    def test_the_editors_page_switches_profile_and_page_in_one_job(self):
        daemon = self.make_daemon()
        pages = list(daemon.config['profiles']['coding']['pages'])
        seen = []
        daemon.events.add = lambda kind, **fields: seen.append((daemon.profile, daemon.page))
        daemon.handle_job(('show', 'coding', pages[-1]))
        self.assertEqual((daemon.profile, daemon.page), ('coding', pages[-1]))
        self.assertEqual(seen, [('coding', pages[-1])])  # the profile's first page is never sent in between
        self.assertIsNone(daemon.auto_profile)  # picked by hand: the focus rules do not switch straight back

    def test_the_windows_own_program_wins_over_a_child_process(self):
        daemon = self.make_daemon()
        daemon.config['profiles']['coding']['match'] = ['process:claude.exe']
        daemon.config['profiles'].pop('Chrome', None)
        daemon.config['profiles']['web'] = {'pages': {'main': []}, 'match': ['chrome.exe']}
        chrome = {'exe': 'chrome.exe', 'title': 'Docs - Google Chrome', 'processes': ['chrome.exe', 'claude.exe']}
        self.tick(daemon, chrome)  # Chrome's extension host runs claude.exe; the window is still Chrome
        self.assertEqual(daemon.profile, 'web')

    @patch.object(deck, 'is_neutral_window', windows_neutral_window)  # the shell windows of this test are the Windows ones
    def test_a_neutral_window_does_not_end_an_automatic_switch(self):
        daemon = self.make_daemon()
        self.tick(daemon, context('code.exe', 'editor'))
        self.assertEqual(daemon.profile, 'coding')
        for shell in (context('explorer.exe', 'Task Switching'), context('searchhost.exe', 'Search')):
            self.tick(daemon, shell)
            self.assertEqual((daemon.profile, daemon.auto_profile), ('coding', 'coding'))
        self.tick(daemon, context('notepad.exe', 'Notepad'))
        self.assertEqual(daemon.profile, 'main')

    def test_the_page_and_folder_you_left_come_back_with_the_profile(self):
        daemon = self.make_daemon()
        daemon.profile, daemon.page, daemon.folder_stack = 'main', 'system', ['main']
        self.tick(daemon, context('code.exe', 'editor'))
        self.assertEqual((daemon.profile, daemon.page), ('coding', 'main'))
        self.tick(daemon, context('notepad.exe', 'Notepad'))
        self.assertEqual((daemon.profile, daemon.page, daemon.folder_stack), ('main', 'system', ['main']))

    def test_a_page_that_no_longer_exists_falls_back_to_the_first_page(self):
        daemon = self.make_daemon()
        daemon.profile, daemon.page = 'main', 'system'
        self.tick(daemon, context('code.exe', 'editor'))
        del daemon.config['profiles']['main']['pages']['system']
        self.tick(daemon, context('notepad.exe', 'Notepad'))
        self.assertEqual((daemon.profile, daemon.page), ('main', 'main'))

    def test_the_remembered_view_is_used_once(self):
        daemon = self.make_daemon()
        daemon.profile, daemon.page = 'main', 'system'
        self.tick(daemon, context('code.exe', 'editor'))
        self.tick(daemon, context('notepad.exe', 'Notepad'))
        daemon.switch_profile('coding')  # a manual switch afterwards
        daemon.switch_profile('main')
        self.assertEqual(daemon.page, 'main')

    def test_profile_lock_pauses_and_resumes_following_the_active_program(self):
        daemon = self.make_daemon()
        self.tick(daemon, context('code.exe', 'editor'))
        daemon.run_action({'type': 'profile_lock'})
        self.assertEqual(daemon.variables()['profile_lock'], 'LOCKED')
        self.tick(daemon, context('notepad.exe', 'Notepad'))
        self.assertEqual(daemon.profile, 'coding')
        daemon.handle_job(('focus-profile', 'main'))  # A queued focus change cannot bypass the lock.
        self.assertEqual(daemon.profile, 'coding')
        daemon.run_action({'type': 'profile_lock'})
        self.assertEqual(daemon.variables()['profile_lock'], 'AUTO')
        self.tick(daemon, context('notepad.exe', 'Notepad'))
        self.assertEqual(daemon.profile, 'main')
        self.tick(daemon, context('code.exe', 'editor'))
        self.assertEqual(daemon.profile, 'coding')
        self.tick(daemon, context('notepad.exe', 'Notepad'))
        self.assertEqual(daemon.profile, 'main')
        self.tick(daemon, context('chrome.exe', 'browser'))
        self.assertEqual(daemon.profile, 'Chrome')

    def test_home_shows_lock_status_and_color(self):
        daemon = self.make_daemon()
        home = daemon.config['profiles']['main']['pinned'][0]
        home.update(label='Home $(profile_lock)', color='#64B5F6', hold_actions=[{'type': 'profile_lock'}])
        def shown():
            return next(button for button in daemon.current_buttons() if button['id'] == home['id'])
        self.assertEqual((shown()['label'], shown()['color']), ('Home AUTO', '#64B5F6'))
        daemon.run_action({'type': 'profile_lock'})
        self.assertEqual((shown()['label'], shown()['color']), ('Home LOCKED', '#FFB13B'))
        daemon.run_action({'type': 'profile_lock'})
        self.assertEqual((shown()['label'], shown()['color']), ('Home AUTO', '#64B5F6'))


if __name__ == '__main__':
    unittest.main()
